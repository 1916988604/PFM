/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef BOARD_H
#define BOARD_H

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//
// Included Files
//

#include "driverlib.h"
#include "device.h"

//*****************************************************************************
//
// PinMux Configurations
//
//*****************************************************************************

//
// ANALOG -> MOTOR_FEEDBACK Pinmux
//

//
// CANA -> myCAN0 Pinmux
//
//
// CANA_RX - GPIO Settings
//
#define GPIO_PIN_CANA_RX 12
#define myCAN0_CANRX_GPIO 12
#define myCAN0_CANRX_PIN_CONFIG GPIO_12_CANA_RX
//
// CANA_TX - GPIO Settings
//
#define GPIO_PIN_CANA_TX 13
#define myCAN0_CANTX_GPIO 13
#define myCAN0_CANTX_PIN_CONFIG GPIO_13_CANA_TX

//
// EPWM1 -> MTR1_PWM_U Pinmux
//
//
// EPWM1_A - GPIO Settings
//
#define GPIO_PIN_EPWM1_A 0
#define MTR1_PWM_U_EPWMA_GPIO 0
#define MTR1_PWM_U_EPWMA_PIN_CONFIG GPIO_0_EPWM1_A
//
// EPWM1_B - GPIO Settings
//
#define GPIO_PIN_EPWM1_B 1
#define MTR1_PWM_U_EPWMB_GPIO 1
#define MTR1_PWM_U_EPWMB_PIN_CONFIG GPIO_1_EPWM1_B

//
// EPWM2 -> MTR1_PWM_V Pinmux
//
//
// EPWM2_A - GPIO Settings
//
#define GPIO_PIN_EPWM2_A 2
#define MTR1_PWM_V_EPWMA_GPIO 2
#define MTR1_PWM_V_EPWMA_PIN_CONFIG GPIO_2_EPWM2_A
//
// EPWM2_B - GPIO Settings
//
#define GPIO_PIN_EPWM2_B 3
#define MTR1_PWM_V_EPWMB_GPIO 3
#define MTR1_PWM_V_EPWMB_PIN_CONFIG GPIO_3_EPWM2_B

//
// EPWM3 -> MTR1_PWM_W Pinmux
//
//
// EPWM3_A - GPIO Settings
//
#define GPIO_PIN_EPWM3_A 4
#define MTR1_PWM_W_EPWMA_GPIO 4
#define MTR1_PWM_W_EPWMA_PIN_CONFIG GPIO_4_EPWM3_A
//
// EPWM3_B - GPIO Settings
//
#define GPIO_PIN_EPWM3_B 5
#define MTR1_PWM_W_EPWMB_GPIO 5
#define MTR1_PWM_W_EPWMB_PIN_CONFIG GPIO_5_EPWM3_B

//
// EPWM4 -> myEPWM0 Pinmux
//
//
// EPWM4_B - GPIO Settings
//
#define GPIO_PIN_EPWM4_B 7
#define myEPWM0_EPWMB_GPIO 7
#define myEPWM0_EPWMB_PIN_CONFIG GPIO_7_EPWM4_B
//
// GPIO227 - GPIO Settings
//
#define Relay1_IO_GPIO_PIN_CONFIG GPIO_227_GPIO227
//
// GPIO24 - GPIO Settings
//
#define GPIO_SYS_DIS_FET_SUPPLY_GPIO_PIN_CONFIG GPIO_24_GPIO24
//
// GPIO32 - GPIO Settings
//
#define LED2_GPIO_GPIO_PIN_CONFIG GPIO_32_GPIO32
//
// GPIO230 - GPIO Settings
//
#define PFC_Ctrl_IO_GPIO_PIN_CONFIG GPIO_230_GPIO230
//
// GPIO16 - GPIO Settings
//
#define myGPIO16_GPIO_PIN_CONFIG GPIO_16_GPIO16
//
// GPIO33 - GPIO Settings
//
#define myGPIO33_GPIO_PIN_CONFIG GPIO_33_GPIO33

//
// SCIA -> SCIA_IO Pinmux
//
//
// SCIA_RX - GPIO Settings
//
#define GPIO_PIN_SCIA_RX 28
#define SCIA_IO_SCIRX_GPIO 28
#define SCIA_IO_SCIRX_PIN_CONFIG GPIO_28_SCIA_RX
//
// SCIA_TX - GPIO Settings
//
#define GPIO_PIN_SCIA_TX 29
#define SCIA_IO_SCITX_GPIO 29
#define SCIA_IO_SCITX_PIN_CONFIG GPIO_29_SCIA_TX
//
// SCIC -> mySCIC Pinmux
//
//
// SCIC_RX - GPIO Settings
//
#define GPIO_PIN_SCIC_RX 226
#define mySCIC_SCIRX_GPIO 226
#define mySCIC_SCIRX_PIN_CONFIG GPIO_226_SCIC_RX
//
// SCIC_TX - GPIO Settings
//
#define GPIO_PIN_SCIC_TX 20
#define mySCIC_SCITX_GPIO 20
#define mySCIC_SCITX_PIN_CONFIG GPIO_20_SCIC_TX

//*****************************************************************************
//
// ADC Configurations
//
//*****************************************************************************
#define MTR1_ADCA_BASE ADCA_BASE
#define MTR1_ADCA_RESULT_BASE ADCARESULT_BASE
#define MTR1_IU_SOC ADC_SOC_NUMBER0
#define MTR1_IU_SOC_FORCE ADC_FORCE_SOC0
#define MTR1_IU_SOC_ADC_BASE ADCA_BASE
#define MTR1_IU_SOC_RESULT_BASE ADCARESULT_BASE
#define MTR1_IU_SOC_SAMPLE_WINDOW 150
#define MTR1_IU_SOC_TRIGGER_SOURCE ADC_TRIGGER_EPWM1_SOCA
#define MTR1_IU_SOC_CHANNEL ADC_CH_ADCIN11
#define MTR1_IV_SOC ADC_SOC_NUMBER1
#define MTR1_IV_SOC_FORCE ADC_FORCE_SOC1
#define MTR1_IV_SOC_ADC_BASE ADCA_BASE
#define MTR1_IV_SOC_RESULT_BASE ADCARESULT_BASE
#define MTR1_IV_SOC_SAMPLE_WINDOW 150
#define MTR1_IV_SOC_TRIGGER_SOURCE ADC_TRIGGER_EPWM1_SOCA
#define MTR1_IV_SOC_CHANNEL ADC_CH_ADCIN5
#define MTR1_VU_SOC ADC_SOC_NUMBER2
#define MTR1_VU_SOC_FORCE ADC_FORCE_SOC2
#define MTR1_VU_SOC_ADC_BASE ADCA_BASE
#define MTR1_VU_SOC_RESULT_BASE ADCARESULT_BASE
#define MTR1_VU_SOC_SAMPLE_WINDOW 150
#define MTR1_VU_SOC_TRIGGER_SOURCE ADC_TRIGGER_EPWM1_SOCA
#define MTR1_VU_SOC_CHANNEL ADC_CH_ADCIN3
#define MTR1_VDC_SOC ADC_SOC_NUMBER3
#define MTR1_VDC_SOC_FORCE ADC_FORCE_SOC3
#define MTR1_VDC_SOC_ADC_BASE ADCA_BASE
#define MTR1_VDC_SOC_RESULT_BASE ADCARESULT_BASE
#define MTR1_VDC_SOC_SAMPLE_WINDOW 150
#define MTR1_VDC_SOC_TRIGGER_SOURCE ADC_TRIGGER_EPWM1_SOCA
#define MTR1_VDC_SOC_CHANNEL ADC_CH_ADCIN12
#define MTR1_NTC1_SOC ADC_SOC_NUMBER4
#define MTR1_NTC1_SOC_FORCE ADC_FORCE_SOC4
#define MTR1_NTC1_SOC_ADC_BASE ADCA_BASE
#define MTR1_NTC1_SOC_RESULT_BASE ADCARESULT_BASE
#define MTR1_NTC1_SOC_SAMPLE_WINDOW 150
#define MTR1_NTC1_SOC_TRIGGER_SOURCE ADC_TRIGGER_EPWM1_SOCA
#define MTR1_NTC1_SOC_CHANNEL ADC_CH_ADCIN0
#define MTR1_IU_PPB ADC_PPB_NUMBER1
#define MTR1_IU_PPB_SOC ADC_SOC_NUMBER0
#define MTR1_IV_PPB ADC_PPB_NUMBER2
#define MTR1_IV_PPB_SOC ADC_SOC_NUMBER1
void MTR1_ADCA_init();

#define MTR1_ADCC_BASE ADCC_BASE
#define MTR1_ADCC_RESULT_BASE ADCCRESULT_BASE
#define MTR1_IW_SOC ADC_SOC_NUMBER0
#define MTR1_IW_SOC_FORCE ADC_FORCE_SOC0
#define MTR1_IW_SOC_ADC_BASE ADCC_BASE
#define MTR1_IW_SOC_RESULT_BASE ADCCRESULT_BASE
#define MTR1_IW_SOC_SAMPLE_WINDOW 150
#define MTR1_IW_SOC_TRIGGER_SOURCE ADC_TRIGGER_EPWM1_SOCA
#define MTR1_IW_SOC_CHANNEL ADC_CH_ADCIN3
#define MTR1_VV_SOC ADC_SOC_NUMBER1
#define MTR1_VV_SOC_FORCE ADC_FORCE_SOC1
#define MTR1_VV_SOC_ADC_BASE ADCC_BASE
#define MTR1_VV_SOC_RESULT_BASE ADCCRESULT_BASE
#define MTR1_VV_SOC_SAMPLE_WINDOW 150
#define MTR1_VV_SOC_TRIGGER_SOURCE ADC_TRIGGER_EPWM1_SOCA
#define MTR1_VV_SOC_CHANNEL ADC_CH_ADCIN9
#define MTR1_VW_SOC ADC_SOC_NUMBER2
#define MTR1_VW_SOC_FORCE ADC_FORCE_SOC2
#define MTR1_VW_SOC_ADC_BASE ADCC_BASE
#define MTR1_VW_SOC_RESULT_BASE ADCCRESULT_BASE
#define MTR1_VW_SOC_SAMPLE_WINDOW 150
#define MTR1_VW_SOC_TRIGGER_SOURCE ADC_TRIGGER_EPWM1_SOCA
#define MTR1_VW_SOC_CHANNEL ADC_CH_ADCIN7
#define MTR1_ULN_SOC ADC_SOC_NUMBER3
#define MTR1_ULN_SOC_FORCE ADC_FORCE_SOC3
#define MTR1_ULN_SOC_ADC_BASE ADCC_BASE
#define MTR1_ULN_SOC_RESULT_BASE ADCCRESULT_BASE
#define MTR1_ULN_SOC_SAMPLE_WINDOW 150
#define MTR1_ULN_SOC_TRIGGER_SOURCE ADC_TRIGGER_EPWM1_SOCA
#define MTR1_ULN_SOC_CHANNEL ADC_CH_ADCIN11
#define MTR1_IW_PPB ADC_PPB_NUMBER1
#define MTR1_IW_PPB_SOC ADC_SOC_NUMBER0
void MTR1_ADCC_init();


//*****************************************************************************
//
// ASYSCTL Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// CAN Configurations
//
//*****************************************************************************
#define myCAN0_BASE CANA_BASE

#define myCAN0_MessageObj30_ID DSP_ID       //2024
#define myCAN0_MessageObj31_ID MODBUS_ID    //2016
void myCAN0_init();


//*****************************************************************************
//
// CMPSS Configurations
//
//*****************************************************************************
#define MTR1_CMPSS_IU_IV_BASE CMPSS1_BASE
#define MTR1_CMPSS_IU_BASE CMPSS1_BASE    
#define MTR1_CMPSS_IU_BASE CMPSS1_BASE    
void MTR1_CMPSS_IU_IV_init();

//*****************************************************************************
//
// CMPSS-LITE Configurations
//
//*****************************************************************************
#define MTR1_CMPSS_IW_BASE CMPSSLITE4_BASE
void MTR1_CMPSS_IW_init();
#define MTR1_CMPSS_IV_BASE CMPSSLITE3_BASE
void MTR1_CMPSS_IV_init();
#define MTR1_CMPSS_UDC_ULN_BASE CMPSSLITE2_BASE
void MTR1_CMPSS_UDC_ULN_init();

//*****************************************************************************
//
// CPUTIMER Configurations
//
//*****************************************************************************
#define TIMEBASE_TIMER_BASE CPUTIMER0_BASE
void TIMEBASE_TIMER_init();

//*****************************************************************************
//
// ECAP Configurations
//
//*****************************************************************************
#define myECAP0_BASE ECAP1_BASE
#define myECAP0_SIGNAL_MUNIT_BASE ECAP1SIGNALMONITORING_BASE
void myECAP0_init();

//*****************************************************************************
//
// EPWM Configurations
//
//*****************************************************************************
#define MTR1_PWM_U_BASE EPWM1_BASE
#define MTR1_PWM_U_TBPRD 0
#define MTR1_PWM_U_COUNTER_MODE EPWM_COUNTER_MODE_UP_DOWN
#define MTR1_PWM_U_TBPHS 0
#define MTR1_PWM_U_CMPA 0
#define MTR1_PWM_U_CMPB 0
#define MTR1_PWM_U_CMPC 0
#define MTR1_PWM_U_CMPD 0
#define MTR1_PWM_U_DBRED 10
#define MTR1_PWM_U_DBFED 10
#define MTR1_PWM_U_TZA_ACTION EPWM_TZ_ACTION_LOW
#define MTR1_PWM_U_TZB_ACTION EPWM_TZ_ACTION_LOW
#define MTR1_PWM_U_OSHT_SOURCES (EPWM_TZ_SIGNAL_DCAEVT1 | EPWM_TZ_SIGNAL_DCBEVT1)
#define MTR1_PWM_U_CBC_SOURCES EPWM_TZ_SIGNAL_CBC6
#define MTR1_PWM_U_INTERRUPT_SOURCE EPWM_INT_TBCTR_ZERO
#define MTR1_PWM_V_BASE EPWM2_BASE
#define MTR1_PWM_V_TBPRD 0
#define MTR1_PWM_V_COUNTER_MODE EPWM_COUNTER_MODE_UP_DOWN
#define MTR1_PWM_V_TBPHS 0
#define MTR1_PWM_V_CMPA 0
#define MTR1_PWM_V_CMPB 0
#define MTR1_PWM_V_CMPC 0
#define MTR1_PWM_V_CMPD 0
#define MTR1_PWM_V_DBRED 10
#define MTR1_PWM_V_DBFED 10
#define MTR1_PWM_V_TZA_ACTION EPWM_TZ_ACTION_LOW
#define MTR1_PWM_V_TZB_ACTION EPWM_TZ_ACTION_LOW
#define MTR1_PWM_V_OSHT_SOURCES (EPWM_TZ_SIGNAL_DCAEVT1 | EPWM_TZ_SIGNAL_DCBEVT1)
#define MTR1_PWM_V_CBC_SOURCES EPWM_TZ_SIGNAL_CBC6
#define MTR1_PWM_V_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define MTR1_PWM_W_BASE EPWM3_BASE
#define MTR1_PWM_W_TBPRD 0
#define MTR1_PWM_W_COUNTER_MODE EPWM_COUNTER_MODE_UP_DOWN
#define MTR1_PWM_W_TBPHS 0
#define MTR1_PWM_W_CMPA 0
#define MTR1_PWM_W_CMPB 0
#define MTR1_PWM_W_CMPC 0
#define MTR1_PWM_W_CMPD 0
#define MTR1_PWM_W_DBRED 10
#define MTR1_PWM_W_DBFED 10
#define MTR1_PWM_W_TZA_ACTION EPWM_TZ_ACTION_LOW
#define MTR1_PWM_W_TZB_ACTION EPWM_TZ_ACTION_LOW
#define MTR1_PWM_W_OSHT_SOURCES (EPWM_TZ_SIGNAL_DCAEVT1 | EPWM_TZ_SIGNAL_DCBEVT1)
#define MTR1_PWM_W_CBC_SOURCES EPWM_TZ_SIGNAL_CBC6
#define MTR1_PWM_W_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define myEPWM0_BASE EPWM4_BASE
#define myEPWM0_TBPRD 41666
#define myEPWM0_COUNTER_MODE EPWM_COUNTER_MODE_UP
#define myEPWM0_TBPHS 0
#define myEPWM0_CMPA 3000
#define myEPWM0_CMPB 0
#define myEPWM0_CMPC 0
#define myEPWM0_CMPD 0
#define myEPWM0_DBRED 0
#define myEPWM0_DBFED 0
#define myEPWM0_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define myEPWM0_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define myEPWM0_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED

//*****************************************************************************
//
// EPWMXBAR Configurations
//
//*****************************************************************************
void MTR1_IS_XBAR_EPWM_MUX_init();
#define MTR1_IS_XBAR_EPWM_MUX XBAR_TRIP7
#define MTR1_IS_XBAR_EPWM_MUX_ENABLED_MUXES (XBAR_MUX00 | XBAR_MUX02 | XBAR_MUX04 | XBAR_MUX06 | XBAR_MUX07 | XBAR_MUX09)

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
#define Relay3_IO 227
void Relay3_IO_init();
#define GPIO_SYS_DIS_FET_SUPPLY 24
void GPIO_SYS_DIS_FET_SUPPLY_init();
#define LED2_GPIO 32
void LED2_GPIO_init();
#define PFC_Ctrl_IO 230
void PFC_Ctrl_IO_init();
#define myGPIO16 16
void myGPIO16_init();
#define myGPIO33 33
void myGPIO33_init();

//*****************************************************************************
//
// INPUTXBAR Configurations
//
//*****************************************************************************
#define myINPUTXBARINPUT0_SOURCE 16
#define myINPUTXBARINPUT0_INPUT XBAR_INPUT4
void myINPUTXBARINPUT0_init();
#define myINPUTXBARINPUT1_SOURCE 33
#define myINPUTXBARINPUT1_INPUT XBAR_INPUT5
void myINPUTXBARINPUT1_init();
#define myINPUTXBARINPUT2_SOURCE 16
#define myINPUTXBARINPUT2_INPUT XBAR_INPUT3
void myINPUTXBARINPUT2_init();

//*****************************************************************************
//
// INTERRUPT Configurations
//
//*****************************************************************************

// Interrupt Settings for INT_MTR1_ADCA_1
#define INT_MTR1_ADCA_1 INT_ADCA1
#define INT_MTR1_ADCA_1_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void motor1CtrlISR(void);

// Interrupt Settings for INT_myECAP0
#define INT_myECAP0 INT_ECAP1
#define INT_myECAP0_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP4
extern __interrupt void INT_myECAP0_ISR(void);

//*****************************************************************************
//
// SCI Configurations
//
//*****************************************************************************
#define SCIA_IO_BASE SCIA_BASE
#define SCIA_IO_BAUDRATE 9600
#define SCIA_IO_CONFIG_WLEN SCI_CONFIG_WLEN_8
#define SCIA_IO_CONFIG_STOP SCI_CONFIG_STOP_ONE
#define SCIA_IO_CONFIG_PAR SCI_CONFIG_PAR_NONE
void SCIA_IO_init();
#define mySCIC_BASE SCIC_BASE
#define mySCIC_BAUDRATE 9600
#define mySCIC_CONFIG_WLEN SCI_CONFIG_WLEN_8
#define mySCIC_CONFIG_STOP SCI_CONFIG_STOP_ONE
#define mySCIC_CONFIG_PAR SCI_CONFIG_PAR_NONE
void mySCIC_init();

//*****************************************************************************
//
// SYNC Scheme Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// SYSCTL Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// Board Configurations
//
//*****************************************************************************
void	Board_init();
void	ADC_init();
void	ASYSCTL_init();
void	CAN_init();
void	CMPSS_init();
void	CMPSSLITE_init();
void	CPUTIMER_init();
void	ECAP_init();
void	EPWM_init();
void	EPWMXBAR_init();
void	GPIO_init();
void	INPUTXBAR_init();
void	INTERRUPT_init();
void	SCI_init();
void	SYNC_init();
void	SYSCTL_init();
void	PinMux_init();

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif  // end of BOARD_H definition
