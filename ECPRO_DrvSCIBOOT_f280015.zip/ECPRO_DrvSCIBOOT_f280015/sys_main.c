#include "app_include.h"
#include "user.h"
#include "sys_settings.h"
#include "sys_main.h"


#pragma DATA_SECTION(mcu_typeSel, "prg_data_flg")
#pragma RETAIN (mcu_typeSel)
    //0x0080010: BIT0-7(BOOT�汾); BIT8(0:500K,1:250K)
    //0x0080011: ����ID
    //0x0080012: ����ID
    //0x0080013: BIT16-31(��)
    //0x0080014: BIT8-15(��)��BIT0-7(��)
#if controller==0
    const uint16_t mcu_typeSel[2] = {0x1010,0x2030};
#elif controller==1
    const uint16_t mcu_typeSel[2] = {0x1010,0x2031};
#elif controller==2
    const uint16_t mcu_typeSel[2] = {0x1010,0x2032};
#elif controller==3
    const uint16_t mcu_typeSel[2] = {0x1010,0x2033};
#elif controller==4
    const uint16_t mcu_typeSel[2] = {0x1010,0x2034};
#else
    const uint16_t mcu_typeSel[2] = {0x1010,0x2030};
#endif


volatile SYSTEM_Vars_t systemVars;
#pragma DATA_SECTION(systemVars,"sys_data");

#if defined(DAC128S_ENABLE)
DAC128S_Handle   dac128sHandle;        //!< the DAC128S interface handle
DAC128S_Obj      dac128s;              //!< the DAC128S interface object
#pragma DATA_SECTION(dac128sHandle,"sys_data");
#pragma DATA_SECTION(dac128s,"sys_data");
#endif  // DAC128S_ENABLE

// **************************************************************************
// the functions
// !!! Please make sure that you have gone through the design guide and followed the
// !!! guide to set up the kit and load the right code
void main(void)
{
    //Clear memory for system and controller
    // The variables must be assigned to these sector if need to be cleared to zero
    HAL_clearDataRAM((void *)ctrlVarsLoadStart,  (uint16_t)ctrlVarsLoadSize);
    HAL_clearDataRAM((void *)motorVarsLoadStart, (uint16_t)motorVarsLoadSize);
    HAL_clearDataRAM((void *)extVarsLoadStart,   (uint16_t)extVarsLoadSize);

#if defined(MOTOR1_OVM) && defined(MOTOR1_DCLINKSS)
#error Don't enable OVM if single shunt is enabled
#endif  // MOTOR1_OVM & MOTOR1_DCLINKSS

#if defined(MOTOR1_VIBCOMPT) && defined(MOTOR1_VIBCOMPA)
#error Don't enable both VIBCOMP methods at the same time
#endif  // MOTOR1_VIBCOMPT & MOTOR1_VIBCOMPA

    // initialize the driver
    halHandle = HAL_init(&hal, sizeof(hal));

    // set the driver parameters
    HAL_setParams(halHandle);

    // set the control parameters for motor 1
    motorHandle_M1 = (MOTOR_Handle)(&motorVars_M1);

    // set the reference speed, this can be replaced or removed
    motorVars_M1.speedRef_Hz = 40.0f;

    // false - enables identification, true - disables identification
#if MOTOR_IDENT
    userParams_M1.flag_bypassMotorId = false;
#else
    userParams_M1.flag_bypassMotorId = true;
#endif

    initMotor1Handles(motorHandle_M1);

    // initialize motor control parameters
    initMotor1CtrlParameters(motorHandle_M1);

#if defined(DATALOGF2_EN)
    //
    // Note that some devices may not support datalog because of lack of
    // DMA and memory size
    //
#if defined(_F280015x)
#error F280015x can't support the DATALOGF2_EN option
#endif  // _F280015x

    // Initialize Datalog
    datalogHandle = DATALOGIF_init(&datalog, sizeof(datalog));
    DATALOG_Obj *datalogObj = (DATALOG_Obj *)datalogHandle;

    HAL_setupDMAforDLOG(halHandle, 0, &datalogBuff1[0], &datalogBuff1[1]);
    HAL_setupDMAforDLOG(halHandle, 1, &datalogBuff2[0], &datalogBuff2[1]);

#if (DMC_BUILDLEVEL <= DMC_LEVEL_2)
    // set datalog parameters
    datalogObj->iptr[0] = &motorVars_M1.adcData.I_A.value[0];
    datalogObj->iptr[1] = &motorVars_M1.adcData.I_A.value[1];
#elif (DMC_BUILDLEVEL == DMC_LEVEL_3)
    datalogObj->iptr[0] = &motorVars_M1.adcData.V_V.value[0];
    datalogObj->iptr[1] = &motorVars_M1.adcData.V_V.value[1];
#elif (DMC_BUILDLEVEL == DMC_LEVEL_4)
    datalogObj->iptr[0] = &motorVars_M1.angleFOC_rad;
    datalogObj->iptr[1] = &motorVars_M1.adcData.I_A.value[0];
#endif  // DMC_BUILDLEVEL = DMC_LEVEL_1/2/3/4
#endif  // DATALOGF2_EN

#if defined(DAC128S_ENABLE)
    //
    // Initialize the DAC128S
    // Note that if you want to change SPI instances (default is SPI A), you'll
    // need to change the DAC128S_SPIx predefined symbol
    //
    dac128sHandle = DAC128S_init(&dac128s);
    DAC128S_setupSPI(dac128sHandle);

    //
    // Comment/uncomment the values you want to send to the DAC
    //
    //************************************************************************
    //************************************************************************
    dac128s.ptrData[0] = &motorVars_M1.angleFOC_rad;                // CH_A
    dac128s.ptrData[1] = &motorVars_M1.adcData.I_A.value[0];        // CH_B
    dac128s.ptrData[2] = &motorVars_M1.adcData.I_A.value[1];        // CH_C
    dac128s.ptrData[3] = &motorVars_M1.adcData.I_A.value[2];        // CH_D

    dac128s.gain[0] = 4096.0f / MATH_TWO_PI;
    dac128s.gain[1] = 2.0f * 4096.0f / USER_M1_DAC_FULL_SCALE_CURRENT_A;
    dac128s.gain[2] = 2.0f * 4096.0f / USER_M1_DAC_FULL_SCALE_CURRENT_A;
    dac128s.gain[3] = 2.0f * 4096.0f / USER_M1_DAC_FULL_SCALE_CURRENT_A;

    dac128s.offset[0] = (uint16_t)(0.5f * 4096.0f);
    dac128s.offset[1] = (uint16_t)(0.5f * 4096.0f);
    dac128s.offset[2] = (uint16_t)(0.5f * 4096.0f);
    dac128s.offset[3] = (uint16_t)(0.5f * 4096.0f);

    DAC128S_writeCommand(dac128sHandle);
#endif  // DAC128S_ENABLE

    systemVars.flagEnableSystem = true;

#if defined(CMD_CAN_EN)
    // setup the CAN interrupt
    CANCOM_enableCANInts(halHandle);

    // initialize the CANCOM
    CANCOM_init();

    motorVars_M1.cmdCAN.speedSet_Hz = 40.0f;

    motorVars_M1.cmdCAN.flagEnableCmd = false;
    motorVars_M1.cmdCAN.flagEnableSyncLead = false;
#endif // CMD_CAN_EN

    motorVars_M1.flagEnableOffsetCalc = true;

    // run offset calibration for motor 1
    runMotor1OffsetsCalculation(motorHandle_M1);

    // enable global interrupts
    HAL_enableGlobalInts(halHandle);

    // enable debug interrupts
    HAL_enableDebugInt(halHandle);

    //CANͨѶ������ʼ��
    J1939_Common_Data_Init();
    //���ϱ���������ʼ��
    f_faultCheck_Init();
    timer_task_init();
    f_pressCtrl_Init();
    //BOOT���ݶ�ȡ
    boot_ver    = (*(uint8 *)0x80008);
    boot_Baud   = ((*(uint8 *)0x80008)&0xFF00)>>8;
    boot_RevID  = (*(uint8 *)0x80009);
    boot_SendID = (*(uint8 *)0x8000A);
    boot_Year   = (*(uint8 *)0x8000B);
    boot_Month  = ((*(uint8 *)0x8000C)&0xFF00)>>8;
    boot_Day    = (*(uint8 *)0x8000C)&0x0FF;

    systemVars.powerRelayWaitTime_ms = POWER_RELAY_WAIT_TIME_ms;

    //��ʼ��ʱ��0����,�ػ�����OST����������
    /*HWREG(XBAR_BASE + XBAR_O_CLR1) = 0xFFFFFFFF;
    HWREG(XBAR_BASE + XBAR_O_CLR2) = 0xFFFFFFFF;
    CMPSS_clearFilterLatchHigh(CMPSS1_BASE);
    CMPSS_clearFilterLatchLow(CMPSS1_BASE);

    CMPSS_clearFilterLatchHigh(CMPSSLITE3_BASE);
    CMPSS_clearFilterLatchLow(CMPSSLITE3_BASE);

    CMPSS_clearFilterLatchHigh(CMPSSLITE4_BASE);
    CMPSS_clearFilterLatchLow(CMPSSLITE4_BASE);

    CMPSS_clearFilterLatchHigh(CMPSSLITE2_BASE);
    CMPSS_clearFilterLatchLow(CMPSSLITE2_BASE);

    EPWM_clearTripZoneFlag(EPWM1_BASE, HAL_TZFLAG_INTERRUPT_ALL);
    EPWM_clearTripZoneFlag(EPWM2_BASE, HAL_TZFLAG_INTERRUPT_ALL);
    EPWM_clearTripZoneFlag(EPWM3_BASE, HAL_TZFLAG_INTERRUPT_ALL);*/
    // Waiting for enable system flag to be set
    while(systemVars.flagEnableSystem == false)
    {
        if(HAL_getCPUTimerStatus(halHandle, HAL_CPU_TIMER_TIMEBASE))
        {
            HAL_clearCPUTimerFlag(halHandle, HAL_CPU_TIMER_TIMEBASE);

            systemVars.timerBase_1ms++;

            if(systemVars.timerBase_1ms > systemVars.powerRelayWaitTime_ms)
            {
                systemVars.flagEnableSystem = true;
                systemVars.timerBase_1ms = 0;
            }
        }
    }

    motorVars_M1.flagInitializeDone = true;

    while(systemVars.flagEnableSystem == true)
    {
        // loop while the enable system flag is true
        systemVars.mainLoopCnt++;
        Cana_Process();

        // 1ms time base
        if(HAL_getCPUTimerStatus(halHandle, HAL_CPU_TIMER_TIMEBASE))
        {
            HAL_clearCPUTimerFlag(halHandle, HAL_CPU_TIMER_TIMEBASE);

            // toggle status LED
            systemVars.counterLED++;
            Time_Count();
            Mot_Send_To_Evcu();

            if(systemVars.counterLED > (uint16_t)(LED_BLINK_FREQ_Hz * 1000))
            {
                HAL_toggleLED(halHandle, LED2_GPIO);

                systemVars.counterLED = 0;
            }

            systemVars.timerBase_1ms++;

            switch(systemVars.timerBase_1ms)
            {
                case 1:     // motor 1 protection check
                    runMotorMonitor(motorHandle_M1);
                    break;
                case 2:
                    calculateRMSData(motorHandle_M1);
                    break;
                case 3:
                    break;
                case 4:     // calculate motor protection value
                    calcMotorOverCurrentThreshold(motorHandle_M1);
                    break;
                case 5:     // system control
                    systemVars.timerBase_1ms = 0;
                    systemVars.timerCnt_5ms++;
                    break;
                default:
                    break;
            }
            timeTask_cnt++;
            timer_task();
            Mot_Receive_From_Evcu();
            Evcu_Receive_Process();
            if(CanA_BusoffFlg()){   //CAN�ָ�
                CanA_Restart();
            }
#if defined(CMD_CAN_EN)
            CANCOM_updateCANCmdFreq(motorHandle_M1);

            if((motorVars_M1.cmdCAN.flagEnableCmd == true) && (motorVars_M1.faultMtrUse.all == 0))
            {
                canComVars.flagCmdTxRun = motorVars_M1.cmdCAN.flagCmdRun;
                canComVars.speedSet_Hz = motorVars_M1.cmdCAN.speedSet_Hz;

                if(motorVars_M1.cmdCAN.flagEnableSyncLead == true)
                {
                    motorVars_M1.flagEnableRunAndIdentify = motorVars_M1.cmdCAN.flagCmdRun;
                    motorVars_M1.speedRef_Hz = motorVars_M1.cmdCAN.speedSet_Hz;
                }
                else
                {
                    motorVars_M1.flagEnableRunAndIdentify = canComVars.flagCmdRxRun;
                    motorVars_M1.speedRef_Hz = canComVars.speedRef_Hz;
                }
            }
#endif // CMD_CAN_EN
        }       // 1ms Timer

        // run control for motor 1
        runMotor1Control(motorHandle_M1);

    } // end of while() loop

    // disable the PWM
    HAL_disablePWM(motorHandle_M1->halMtrHandle);

} // end of main() function

//
//-- end of this file ----------------------------------------------------------
//
