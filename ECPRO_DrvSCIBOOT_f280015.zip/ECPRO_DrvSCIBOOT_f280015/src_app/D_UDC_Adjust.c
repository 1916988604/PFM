#ifndef	APP_UDCT_ADJUST_C
#define	APP_UDCT_ADJUST_C

#include <D_UDC_Adjust.h>


void f_udcAdjust_init(void)
{
    udcAdjustTempBase = 0;
    udcAdjEnd = 0;
    udcAdjOut = 0;
}


void  f_udcAdjust_k(void)		//100ms
{
	/***UDC ADJ*******************************************************************/
	float temp,tempT1,tempT2,tempT1_U1,tempT2_U1,deltaU,tempK;
	int i,j;
	float deltaT;
	float udcAdjK=10000; //udc adjust constant
	float udcAdj[5][3]={{10000,	10000,	10000},\
						{10000,	10000,	10000},\
						{10000,	10000,	10000},\
						{10000,	10000,	10000},\
						{10000,	10000,	10000}	};


	//udcAdjustTempBase:�¶Ȼ�׼;
	if(udcAdjustTempBase< -45){
		i = 0;
		deltaT= 75;
	}else if(udcAdjustTempBase < 30){
		i = 0;
		deltaT= 30 - udcAdjustTempBase;
	}else if(udcAdjustTempBase > 105){
		i = 1;
		deltaT= 0;
	}else{
		i = 1;
		deltaT= 105 - udcAdjustTempBase;
	}

	if(udcAdjEnd < 100){			//100
		j = 0;
		deltaU = 50;
	}else if(udcAdjEnd < 150){		//150
		j = 0;
		deltaU = 150 - udcAdjEnd;
	}else if(udcAdjEnd < 200){		//200
		j = 1;
		deltaU = 200 -  udcAdjEnd;
	}else if(udcAdjEnd < 250){		//250
		j = 2;
		deltaU = 250 - udcAdjEnd;
	}else if(udcAdjEnd > 300){		//300
		j = 3;
		deltaU = 0;		//0V
	}else{
		j = 3;
		deltaU = 300 - udcAdjEnd;
	}
	tempT1 = udcAdj[j][i+1] - udcAdj[j][i];
	tempT2 = udcAdj[j+1][i+1] - udcAdj[j+1][i];

	tempT1_U1 = udcAdj[j][i+1] - tempT1*deltaT*0.013333;     //75;		//tempT1���435
	tempT2_U1 = udcAdj[j+1][i+1] - tempT2*deltaT*0.013333;   //75;

	tempK = tempT2_U1;
	tempK = tempK - tempT1_U1;
	udcAdjK = tempT2_U1 - (deltaU*tempK)*0.02;      //50;

	temp = udcAdjEnd;
	temp = temp * udcAdjK;
	temp = temp*0.0001; //  /10000;
	udcAdjOut=temp;
	/*********************************************************************************/
}


#endif



