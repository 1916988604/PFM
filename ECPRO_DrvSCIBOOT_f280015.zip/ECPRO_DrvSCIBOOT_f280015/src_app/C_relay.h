
#ifndef SRC_APP_C_RELAY_H_
#define SRC_APP_C_RELAY_H_

#include "f280015x_device.h"

typedef enum
{
    ERR_SCI_STA=0,
    READY_SCI_STA=1,
    RUN_SCI_STA=2
} RELAY_MODE;

#ifdef SRC_APP_RELAY_C_
    #define SRC_APP_RELAY
#else
    #define SRC_APP_RELAY  extern
#endif

SRC_APP_RELAY uint16_t relay1OutMode,relay2OutMode;
SRC_APP_RELAY uint16_t motor_err_sci,motor_runFlg_sci,motor_readyFlg_sci,motor_warnStop_sci,motor_warnFlg_sci;
SRC_APP_RELAY void relay_init(void);
SRC_APP_RELAY void relay_ctrl(void);


#endif /* SRC_APP_C_RELAY_H_ */
