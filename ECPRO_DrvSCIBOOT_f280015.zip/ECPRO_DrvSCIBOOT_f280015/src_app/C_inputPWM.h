
#ifndef SRC_APP_C_INPUTPWM_H_
#define SRC_APP_C_INPUTPWM_H_

#include "f280015x_device.h"

#define PWM_IN_SEL      1   //0:MegaS;  1:EPA25-40

#define PWM_PRD_VALID   1   //0:pwmƵ����Ч���䱣���ϴμ�⣻   1:PWMƵ����Ч����Ϊ100%;   2:PWMƵ����Ч����Ϊ0%

#if XTAL_PLL_FREQ==0 || XTAL_PLL_FREQ==2
    #define PERIOD_MIN      29268       //120000000/4100
    #define PERIOD_MAX      2400000       //120000000/50
#else
    #define PERIOD_MIN      25000     //100000000/4100=24390 100000000/4000=25000
    #define PERIOD_MAX      1000000   //100000000/50=2000000 100000000/100=1000000
#endif

#if PWM_IN_SEL==0
    #define     SPD_MAX_PWMIN     1000     //100.0%, 0.1�ֱ���
    #define     SPD_MIN_PWMIN     200
#else
    #define     SPD_MAX_PWMIN     1000     //100.0%, 0.1�ֱ���
    #define     SPD_MIN_PWMIN     150
#endif

typedef enum
{
    PWMIN_A=0,
    PWMIN_B=1,
    PWMIN_C=2,
    PWMIN_D=3,
    PWMIN_E=4
} PWMIN_MODE;


#ifdef  SRC_APP_INPUTPWM_C_
    #define SRC_APP_INPUTPWM
#else
    #define SRC_APP_INPUTPWM  extern
#endif

SRC_APP_INPUTPWM Uint16 pwmInSpdRef;
SRC_APP_INPUTPWM Uint16 pwmInEnable;
SRC_APP_INPUTPWM Uint16 pwmInMode;
SRC_APP_INPUTPWM Uint16 captureTicker;
SRC_APP_INPUTPWM float pwmDuTy;
SRC_APP_INPUTPWM float pwmDataH,period,period_old;

SRC_APP_INPUTPWM void PulseInCalc(void);
SRC_APP_INPUTPWM void eCap_Init(void);

#endif /* SRC_APP_C_INPUTPWM_H_ */
