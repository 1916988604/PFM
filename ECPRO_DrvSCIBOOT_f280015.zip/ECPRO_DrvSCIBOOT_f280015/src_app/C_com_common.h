
#ifndef SRC_APP_C_COM_COMMON_H_
#define SRC_APP_C_COM_COMMON_H_

#define MCU_PAKAGE  0   //0:48pin;  1:80pin


#define MODBUS                        0
#define PROFIBUS                      1
#define CAN_OPEN                      2
#define CANLINK                       3
#define EXTEND_COM_CAR                1         // ͨ����չ��

#define SCI_WRITE_NO_EEPROM         0
#define SCI_WRITE_WITH_EEPROM       1

#define SCI_CMD_READ                0x03
#define SCI_CMD_WRITE               0x06
#define SCI_CMD_WRITE_RAM           0x07        //δ��
#define SCI_CMD_WRITE_MORE          0x10

#define COMM_ERR_NONE               0   //
#define COMM_ERR_PWD                1   // �������
#define COMM_ERR_CMD                2   // ��д�������
#define COMM_ERR_CRC                3   // CRCУ�����
#define COMM_ERR_ADDR               4   // ��Ч��ַ
#define COMM_ERR_PARA               5   // ��Ч����
#define COMM_ERR_READ_ONLY          6   // ����������Ч
#define COMM_ERR_SYSTEM_LOCKED      7   // ϵͳ����
#define COMM_ERR_SAVE_FUNCCODE_BUSY 8   // ���ڴ洢����

#define         DP              1
#define         MD              2

#ifdef  SRC_APP_C_COM_COMMON_C_
    #define SRC_APP_C_COM_COMMON
#else
    #define SRC_APP_C_COM_COMMON  extern
#endif


SRC_APP_C_COM_COMMON Uint16 CrcValueByteCalc(Uint16 *data, Uint16 length);
SRC_APP_C_COM_COMMON void sci_comm_init();

#endif /* SRC_APP_C_COM_COMMON_H_ */
