
#ifndef APP_PRESSCTRL_C
#define APP_PRESSCTRL_C

#include <app_include.h>

#define SELF_PRIME_MAXTIME  (unsigned long)15*60*1000/250 //15MIN

unsigned int leakErr_time;
unsigned int leakErr_5stime;

void  f_pressCtrl_Init(void)
{
    u16_runPressOLcnt=0;
    u16_pressCtrlEn=0;
    u16_SCI_FreezeEn=0;
    u16_runSelfPrimecnt=0;
    u16_runStopCnt=0;
    u16_runStop2Cnt=0;
    su_distDir=0;
    su_distCnt=0;
    PID_Ctrl_int();
    u16_StopCtrlFlg=0;
    u16_SelPrimeFlg=0;
    u16_tmpSensorErrFlg=0;
    leakErr_time=0;
    leakErr_5stime=0;
    fault_cnt.inclose_errCnt=0;
}

//250ms
void  f_pressCtrl(void)
{
    float f_temp;
    float f_spd_temp,f_pwr_temp;

    static Uint16 u16_pressSave=0;
    static Uint16 u16_press_bak=0;
    static Uint16 u16_press_1sbak=0;

    static float u16_runCnt=0,u16_self_overFlg=0;
    static unsigned int u16_runRecCnt=0;
    static unsigned int u16_stopPressSaveFlg=0;
    static unsigned long u16_antiFreezeTime=0;
    //static unsigned int u16_antiFreezeFlg=0;

    float f_headSetMax,f_headSetMin,f_headUpStep,f_headDownStep;
    static unsigned int b_startFlg=0,u16_pressOK_cnt=0;
    static unsigned int u16_pressCmd_bak=0;
    static unsigned int u16_dist_2minCnt=0;
    static unsigned int b_accDecFlg=0,u16_stopCnt=0,u16_stopCnt2=0;
    static float f_f_pressRamp=1200;
    static float f_pressRef=1200;
    static unsigned int power_over_cnt=0;

    static unsigned int press_roll_time=40;        //120*250/1000=30s
    static unsigned int leakErr_cnt=0,leakErr_1scnt=0;
    static unsigned long u16_leakErr20minTime=0,u16_run2minTime=0;
    static float f_press_save_stop=0;
    static float f_pwrBak_save=0,f_spdBak_save=0;

    f_spd_temp = fabsf(motorSpd);
    f_pwr_temp = fabsf(motorPwr_f);//motorPwr_Lpf);

    //��������
    if(u_enable_HandC==1){
        if(u16_press>=(u16_pressCmd+500)){          //���Źص���ѹ��һֱ��������
           u16_runPressOLcnt++;
           if(u16_runPressOLcnt>20){     //5s
             u16_runPressOLcnt = 20;
             u16_pressCtrlEn=0;
             u16_stopPressSaveFlg=0;
           }
         }else if((u16_press+400) <= u16_pressCmd){//ʵ��ѹ���½�2.0�ף���������,΢©�½�2.0m��ʱ��
             if(u16_stopPressSaveFlg==1){
                if(u16_pressSave<1200){
                    u16_pressSave=1200;
                }
                if((u16_press+400) <= u16_pressSave){
                    u16_pressCtrlEn=1;
                    u16_stopPressSaveFlg=0;
                    u16_StopCtrlFlg=0;
                }
            }else{
                u16_stopPressSaveFlg=0;
                u16_pressCtrlEn=1;
                u16_StopCtrlFlg=0;
            }
           u16_runPressOLcnt = 0;
         }else{
           u16_runPressOLcnt=0;
         }
    }else{
        u16_runPressOLcnt=0;
        u16_pressCtrlEn=0;
        u16_stopPressSaveFlg=0;
    }

    //E03�������ϣ��Զ���������
    if((u16_press < 200) && ((f_spd_temp+150) > SPEED_MAX)){//powerLmt.Max)){   //15����δ���ϱ�E03
        if( u16_press < 200 ){
           u16_runSelfPrimecnt++;
            if(u16_runSelfPrimecnt>SELF_PRIME_MAXTIME){
                u16_runSelfPrimecnt=SELF_PRIME_MAXTIME;
                u_fault_sta.bit.SelfPrimErr = 1;
            }
            u16_SelPrimeFlg=1;
       }else if(u_fault_sta.bit.SelfPrimErr == 0){
           u16_runSelfPrimecnt = 0;
       }
    }else{
        u16_runSelfPrimecnt = 0;
        u16_SelPrimeFlg=0;
    }

    //����ʱ�ط���
    if(motorVars_M1.flagEnableRunAndIdentify==1){
        if(u16_self_overFlg==0){
            if(u16_press > 200){
                u16_runCnt++;
                if(u16_runCnt>20){  //5s
                    u16_self_overFlg=1;
                    u16_runCnt=0;
                }
            }else{
                u16_runCnt=0;
            }
        }
        if(u16_self_overFlg==1){
            if((u16_press < 200) && ((f_spd_temp+150) > SPEED_MAX)){
                u16_runCnt++;
                if(u16_runCnt>80){  //20s*1000/250=80
                    u_fault_sta.bit.inCloseErr=1;
                    u16_runCnt = 0;
                }
            }else{
               u16_runCnt=0;
            }
        }
    }else{
        u16_runCnt=0;
        //u16_self_overFlg=0;
    }
    static unsigned long zeroSpd_clr_cnt=0;
    static unsigned long u16_24h_timecnt=0;
    /*if((fault_cnt.inclose_errCnt>0)&&(fault_cnt.inclose_errCnt<8)){
        zeroSpd_clr_cnt++;
        if(zeroSpd_clr_cnt>240){       //1min*60*1000/250=240
            zeroSpd_clr_cnt=0;
            fault_cnt.inclose_errCnt=0;
        }
    }else*/ if(fault_cnt.inclose_errCnt > 7){
        u16_24h_timecnt++;
        if(u16_24h_timecnt > 345600){     //24h*60*60*1000/250=345600
            u16_24h_timecnt=0;
            u_fault_sta.bit.inCloseErr=0;
            fault_cnt.inclose_errCnt=0;
        }
    }else{
        u16_24h_timecnt=0;
        zeroSpd_clr_cnt=0;
    }
    if(sys_param.errRstEn==1){
        fault_cnt.inclose_errCnt=0;
        u_fault_sta.bit.inCloseErr=0;
    }
    if(u_fault_sta.bit.inCloseErr==1){
        if(fault_cnt.inclose_errCnt<8){      //8��
            u16_runRecCnt++;
            if(u16_runRecCnt>32){    //8.0s
                fault_cnt.inclose_errCnt++;
                u16_runRecCnt=0;
                u_fault_sta.bit.inCloseErr=0;
            }
        }
    }else{
        u16_runRecCnt=0;
    }

    //�����ж�
    if((u16_SCI_FreezeEn==1)&&(s16_temper_medium<5)&&(u16_antiFreezeFlg==0)&&(motorVars_M1.flagEnableRunAndIdentify==0)){
        u16_antiFreezeTime++;
        if(u16_antiFreezeTime>80){     //20s*1000/250=80
            u16_antiFreezeTime=0;
            u16_antiFreezeFlg=1;
        }
    }else if(u16_pressCtrlEn==1){
        u16_antiFreezeTime=0;
        u16_antiFreezeFlg=0;
    }else{
        if(u16_antiFreezeFlg==0){
            u16_antiFreezeTime=0;
        }
    }

//******************й¶����****************************************************************/
    static float f_press_5ssave_stop=0;
    static unsigned int leakErr_5scnt=0,leakErr_5sChkcnt=0;
    static unsigned long u16_leakErr40minTime=0;
    if(sys_param.errRstEn==1){
        u16_leakErr20minTime=0;
        leakErr_time=0;
        u_fault_sta.bit.leakErr = 0;
        u16_run2minTime = 0;
        leakErr_5stime=0;
        u16_leakErr40minTime=0;
        leakErr_cnt=0;
        leakErr_5sChkcnt=0;
    }
    u16_leakErr20minTime++;
    u16_leakErr40minTime++;
    if(u16_pressCtrlEn==0){
        u16_run2minTime=0;
        leakErr_1scnt++;
        if(leakErr_1scnt>4){        //1s�ж�һ��
            leakErr_1scnt=0;
            if((u16_press+10)<f_press_save_stop){       //0.1m/s; ����>5s
                leakErr_cnt++;
                f_press_save_stop = u16_press;
            }else if(leakErr_cnt>0){
                leakErr_cnt--;
            }
        }

        leakErr_5scnt++;
        if(leakErr_5scnt>20){        //5s�ж�һ��
            leakErr_5scnt=0;
            if((u16_press+10)<f_press_5ssave_stop){       //0.1m/5s; ����>5s
                leakErr_5sChkcnt++;
                f_press_5ssave_stop = u16_press;
            }/*else if(leakErr_5sChkcnt>0){
                leakErr_5sChkcnt--;
            }*/
        }
    }else{
        f_press_save_stop = u16_press;
        f_press_5ssave_stop = u16_press;
        if(leakErr_cnt>5){
            leakErr_time++;
        }

        if(leakErr_5sChkcnt>5){
            leakErr_5stime++;
        }

        leakErr_cnt=0;
        leakErr_5sChkcnt=0;
        u16_run2minTime++;
        if(u16_run2minTime > 480){     //2min*60*1000/250=480
          u16_leakErr20minTime = 0;
          u_fault_sta.bit.leakErr = 0;
          u16_run2minTime = 0;
          leakErr_time = 0;
        }
    }
    if(leakErr_time>15){       //10min,15��
        if(u16_leakErr20minTime<2400){  //10min*60*1000/250=2400
            u_fault_sta.bit.leakErr = 1;
            u16_leakErr20minTime = 2000;
        }else{
            leakErr_time=0;
            u16_leakErr20minTime=0;
        }
    }
    if(leakErr_5stime>4){       //70����5��
        if(u16_leakErr40minTime<16800){  //70min*60*1000/250=9600
            u_fault_sta.bit.leakErr = 1;
            u16_leakErr40minTime = 4000;
        }else{
            leakErr_5stime=0;
            u16_leakErr40minTime=0;
        }
    }
/************************************************************************************/
    static float f_press_1ssave_cnt=0;
/**��ͣ�߼�**********************************************************************************************************/
    if(u16_pressCtrlEn==1){
        if( (f_pressRef < (f_f_pressRamp+5)) && (f_pressRef > (f_f_pressRamp-5)) ){     //Ŀ��ѹ��ֵ����
            if(u16_dist_2minCnt>(press_roll_time)){
                if(u16_press>(f_pressRef+500)){
                    u16_stopCnt=0;
                }
                if(u16_press>(f_pressRef+50)){      //���Źر�ʱ��70ֵ��й¶���й�
                    u16_stopCnt++;
                    if(u16_stopCnt>16){   //4s=4*1000/250=16
                        u16_pressCtrlEn=0;
                        u16_stopCnt=0;
                        power_over_cnt=0;
                        u16_dist_2minCnt=0;
                        u16_stopPressSaveFlg=1;
                        u16_pressSave=u16_press;
                    }
                }else{
                    //if(u16_dist_2minCnt>(press_roll_time+20)){
                    u16_stopCnt =0;
                    u16_dist_2minCnt = u16_dist_2minCnt-press_roll_time;
                }
            }else{
                /*if(u16_press > (f_pressRef+100)){
                    u16_stopCnt2++;
                    if(u16_stopCnt2>20){
                        u16_pressCtrlEn=0;
                        u16_stopCnt2=0;
                        power_over_cnt=0;
                        u16_dist_2minCnt=0;
                        u16_stopPressSaveFlg=1;
                        u16_pressSave=u16_press;
                    }
                }else{
                    u16_stopCnt2=0;
                }*/
                u16_stopCnt=0;
            }

            if( (u16_press > (f_pressRef+150)) && (u16_press < (u16_press_1sbak+30)) && ((u16_press+30) > u16_press_1sbak) ){
                if(pressCtrlLmt.Out < ((f_spd_temp*1000)/powerLmt.Max+30)){
                    u16_stopCnt2++;
                    if(u16_stopCnt2>12){    //3s
                        u16_pressCtrlEn=0;
                        u16_stopPressSaveFlg=1;
                        u16_pressSave=u16_press;
                        u16_stopCnt2=0;
                    }
                }else{
                    u16_stopCnt2=0;
                }
            }else{
                u16_stopCnt2=0;
            }

            if( ((u16_press+200)>u16_press_bak) && (u16_press<(u16_press_bak+400)) ){
            }else{
                u16_stopCnt=0;
                u16_dist_2minCnt=0;
            }
            u16_press_bak=u16_press;
            f_press_1ssave_cnt++;
            if(f_press_1ssave_cnt>4){
                f_press_1ssave_cnt=0;
                if((u16_press+40) < u16_press_1sbak){
                    u16_stopCnt=0;
                    u16_dist_2minCnt=0;
                }
                u16_press_1sbak = u16_press;
            }
            if(f_spd_temp > (f_spdBak_save+500)){
                u16_stopCnt=0;
                u16_dist_2minCnt=0;
            }
            f_spdBak_save = f_spd_temp;
        }else{
            u16_stopCnt=0;
            //u16_dist_2minCnt=0;
            u16_stopCnt2=0;
            f_press_1ssave_cnt=0;
            u16_press_bak=u16_press;
            f_spdBak_save = f_spd_temp;
            u16_press_1sbak = u16_press;
        }

        //����ͻ����ɼ�����
        if((f_pwr_temp > (f_pwrBak_save+50)) || (f_pwr_temp < (f_pwrBak_save-50))){
            u16_stopCnt=0;
            u16_dist_2minCnt=0;
        }
        f_pwrBak_save = f_pwr_temp;

        //ѹ������
        f_headSetMax = HD_HEAD_MAX*100;
        f_headSetMin = 1300;//HD_HEAD_MIN*100;
        f_headUpStep = 250;     //1.0bar/s
        f_headDownStep = 250;   //1.0bar/s

        if(b_startFlg==0){      //����ʱ�̣�ֱ�ӹ̶�һ��ѹ��ֵ
            f_f_pressRamp = 1200;   //1.2bar,����ǰ���ֵ�ѹ���󣬴�ˮ���ڲ��ȶ�
            if(u16_press<1150){
                u16_pressOK_cnt++;
                if(u16_pressOK_cnt>8){      //2s
                    b_startFlg=1;
                    u16_pressOK_cnt=0;
                }
            }else{
                u16_pressOK_cnt=0;
                b_startFlg=1;
            }
            u16_stopCnt=0;
        }else{
            static unsigned int b_pressCmdChangeFlg=0,u16_pressCmdChangeCnt=0;
            if(u16_pressCmd_bak != u16_pressCmd){       //Ŀ��ֵ�仯�������ж�
                u16_dist_2minCnt=0;
                u16_stopCnt=0;
                b_pressCmdChangeFlg=1;
            }
            u16_pressCmd_bak = u16_pressCmd;
            if(b_pressCmdChangeFlg==1){
                u16_pressCmdChangeCnt++;
                if(u16_pressCmdChangeCnt<12){   //
                    u16_dist_2minCnt=0;
                    u16_stopCnt=0;
                    u16_pressCmdChangeCnt=0;
                    b_pressCmdChangeFlg=0;
                    u16_runPressOLcnt=0;
                }
            }

            f_temp = u16_pressCmd;
            static unsigned int b_roll_pressFlg=0;
            //30s�Ŷ�
            u16_dist_2minCnt++;
            if(u16_dist_2minCnt>(press_roll_time+30)){        //30*250/1000=7.5s
                f_f_pressRamp = f_temp;
                b_roll_pressFlg=0;
            }else if(u16_dist_2minCnt>press_roll_time){   //30s*1000/250ms=120
                //�޹��ʣ��ﲻ��Ŀ��ѹ��ʱ���Ե�ǰѹ��ΪĿ��ѹ��ֵ
                //f_f_pressRamp = f_temp-150;
                float f_spdpervar=0;

                f_spdpervar = f_spd_temp*1000/SPEED_MAX;
                f_spdpervar = f_spdpervar+100;
                if(f_spdpervar>1000){
                    f_spdpervar=1000;
                }
                //if( (pressCtrlLmt.Out >990) && ((f_spd_temp+50) < SPEED_MAX)){// &&(b_roll_pressFlg==0)){
                if( (pressCtrlLmt.Out >990) && ((f_spd_temp+50) < SPEED_MAX)){
                    u16_dist_2minCnt=0;
                    u16_stopCnt=0;
                    f_f_pressRamp = f_temp;
                    b_roll_pressFlg=0;
                }else{
                    f_f_pressRamp = f_temp-150;
                    b_roll_pressFlg=1;
                }
            }else{
                f_f_pressRamp = f_temp;
                b_roll_pressFlg=0;
            }

            //��Ŀ��ѹ��1mʱ����С�½�б��
            /*if( ((f_f_pressRamp+100) > f_pressRef) && ((f_f_pressRamp-100) < f_pressRef) ){   //ѹ���½����ӽ�Ŀ��ֵʱ���¶ȱ���
                f_headDownStep = 20;        //1m@1.25s
                f_headUpStep = 20;        //1m@1.25s
            }*/
        }

        //Ŀ��ѹ��PI����
        LinearRamp(f_f_pressRamp,&f_pressRef,f_headUpStep,f_headDownStep,f_headSetMax,f_headSetMin);
        pressCtrlLmt.Deta = f_pressRef - u16_press;
        PID((PID_STRUCT *)&pressCtrlLmt);
        f_temp = pressCtrlLmt.Out;

        if(CANtest_flg==1){
        }else{
      #if HMI_CONTROL_EN==3
             u_sci_enable.bit.can_enable = u16_pressCtrlEn;
      #endif
        }
    }else if((u16_antiFreezeFlg==1)||(u16_tmpSensorErrFlg==1)){    //��ʾ���������Ϳ�������
        f_temp = 500;   //50%
        PID_Ctrl_int();
        u16_runStopCnt = 0;
        u16_runStop2Cnt=0;
        su_distDir=0;
        su_distCnt=0;
        if(CANtest_flg==1){
        }else{
    #if HMI_CONTROL_EN==3
            if(u16_tmpSensorErrFlg==1){
                u_sci_enable.bit.can_enable=1;
            }else if(u_enable_HandC==1){
                u_sci_enable.bit.can_enable=1;
            }else{
                if(u16_antiFreezeFlg==1){
                    u16_antiFreezeTime++;
                    if(u16_antiFreezeTime>9600){     //40min*60*1000/250=9600
                       u_sci_enable.bit.can_enable=0;
                       u16_antiFreezeFlg=0;
                       u16_antiFreezeTime=0;
                    }else{
                       u_sci_enable.bit.can_enable=1;
                    }
                }else{
                    u_sci_enable.bit.can_enable=0;
                }
            }
    #endif
        }
        //u16_pressCtrlEn=1;
        if(motorVars_M1.flagEnableRunAndIdentify==0){
            b_startFlg=0;
        }
        u16_pressOK_cnt=0;
        u16_pressCmd_bak=0;
        u16_dist_2minCnt=0;
        u16_stopCnt=0;
    }else{
        if(motorVars_M1.flagEnableRunAndIdentify==0){
            b_startFlg=0;
        }
        u16_pressOK_cnt=0;
        u16_pressCmd_bak=0;
        u16_dist_2minCnt=0;
        u16_stopCnt=0;

        PID_Ctrl_int();
        f_temp = 0;
        u16_runStopCnt = 0;

        //u16_stopPressSaveFlg=0;

        if(CANtest_flg==1){
        }else{
    #if HMI_CONTROL_EN==3
            u_sci_enable.bit.can_enable = u16_pressCtrlEn;
    #endif
        }
    }
/***********************************************************************************************************/

    if(CANtest_flg==1){ //ͨѶ����ʱ��Ч
        PID_Ctrl_int();
        f_temp = 0;
        u16_runStopCnt = 0;
    }else{
#if HMI_CONTROL_EN==3
        //PI���ڸ�ֵ
        u_speed_HandC = (unsigned int)f_temp;
        u_speed_can = u_speed_HandC;
        //u_sci_enable.bit.can_enable = u16_pressCtrlEn;
#endif
    }
}

void PID_Ctrl_int(void)
{
    pressCtrlLmt.KP = 0.06;
    pressCtrlLmt.KI = 0.03;
    pressCtrlLmt.KD = 0;
    pressCtrlLmt.Max = 1000;    //���ת��100.0%
    pressCtrlLmt.Min = 50;
    pressCtrlLmt.Total = 200;
    pressCtrlLmt.Out = 200;
    pressCtrlLmt.Deta = 0;
    pressCtrlLmt.Flag = 0;
    pressCtrlLmt.OutFlag = 0;
}

#endif
