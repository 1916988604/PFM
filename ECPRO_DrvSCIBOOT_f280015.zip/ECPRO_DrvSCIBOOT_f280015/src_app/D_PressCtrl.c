
#ifndef APP_PRESSCTRL_C
#define APP_PRESSCTRL_C

#include <app_include.h>

#define SPD_NUM_PWR    11
//EC PRO
//0.5m^3/hʱ�Ĺ���:1000RPM,1500RPM,2000RPM,2500RPM,30000RPM,3500RPM,4000RPM,4500RPM��5000��5500
//4.0���
//unsigned int  u16_liquid_sps_min_pwr[SPD_NUM_PWR]      ={20,50,65,110,166,250,395,514, 514, 514, 514};  //��λW

//4.2���
unsigned int  u16_liquid_sps_min_pwr[SPD_NUM_PWR]      ={20,55,78,115,175,267,380,500, 500, 500, 500};  //��λW

#define SELF_PRIME_MAXPWR   400 //W
#define SELF_PRIME_MAXTIME  (unsigned long)15*60*1000/250 //15MIN

void  f_pressCtrl_Init(void)
{
    u16_runPressOLcnt=0;
    u16_pressCtrlEn=0;
    u16_SCI_FreezeEn=0;
    u16_runSelfPrimecnt=0;
    u16_runStopCnt=0;
    u16_runStop2Cnt=0;
    su_distDir=0;
    su_distCnt=0;
    PID_Ctrl_int();
    u16_StopCtrlFlg=0;
    u16_SelPrimeFlg=0;
    u16_tmpSensorErrFlg=0;
    u16_antiFreezeFlg=0;
    fault_cnt.inclose_errCnt=0;
}

//250ms
void  f_pressCtrl(void)
{
    float f_temp,f_temp1;
    float f_spd_temp,f_pwr_temp;
    unsigned int    u16_temp;
    static unsigned int cntPwrLimit=0;
    static unsigned int press_set=0;
    static unsigned int start_flg=0,start_cnt=0;
    static Uint16 u16_pressSave=0,u16_pressScnt=0,u16_pressFlg=0;
    static float u16_SpdSet=0;
    static float u16_runCnt=0,u16_self_overFlg=0;
    static  unsigned int u16_satStopCnt=0,u16_satStopAlltime=0;
    static unsigned int u16_runRecCnt=0;
    static unsigned int u16_stopPressSaveFlg=0;
    static unsigned long u16_antiFreezeTime=0;

    static unsigned int b_freezeFlgFirst=0;
    static unsigned long u16_24h_timecnt=0;

    f_spd_temp = fabsf(motorSpd);
    f_pwr_temp = fabsf(motorPwr_f);//motorPwr_Lpf);

    //��������
    if(u_enable_HandC==1){
        if(u16_press>=(u16_pressCmd+500)){          //���Źص���ѹ��һֱ��������
           u16_runPressOLcnt++;
           if(u16_runPressOLcnt>12){     //3s
             u16_runPressOLcnt = 12;
             u16_pressCtrlEn=0;
             u16_stopPressSaveFlg=0;
           }
         }else if((u16_press+400) <= u16_pressCmd){     //ʵ��ѹ���½�4.0�ף���������,΢©�½�4.0m��ʱ��
                if((u16_stopPressSaveFlg==1)){
                   if(u16_pressSave<1500){
                       u16_pressSave=1500;
                   }
                   if((u16_press+400) <= u16_pressSave){
                       u16_pressCtrlEn=1;
                       u16_stopPressSaveFlg=0;
                       u16_StopCtrlFlg=0;
                   }
               }else{
                   u16_stopPressSaveFlg=0;
                   u16_pressCtrlEn=1;
                   u16_StopCtrlFlg=0;
               }
           u16_runPressOLcnt = 0;
         }else{
           u16_runPressOLcnt=0;
         }
    }else{
        u16_runPressOLcnt=0;
        u16_pressCtrlEn=0;
        u16_stopPressSaveFlg=0;
    }

    //E03�������ϣ��Զ���������
    //if((f_pwr_temp < SELF_PRIME_MAXPWR) && ((f_spd_temp+150) > SPEED_MAX)){     //15����δ���ϱ�E03
    if((u16_press < 200) && ((f_spd_temp+150) > SPEED_MAX)){     //15����δ���ϱ�E03
       if( u16_press < 200 ){
           u16_runSelfPrimecnt++;
            if(u16_runSelfPrimecnt>SELF_PRIME_MAXTIME){
                u16_runSelfPrimecnt=SELF_PRIME_MAXTIME;
                //u16_pressCtrlEn=0;
                u_fault_sta.bit.SelfPrimErr = 1;
            }
            u16_SelPrimeFlg=1;
       }else if(u_fault_sta.bit.SelfPrimErr == 0){
           u16_runSelfPrimecnt = 0;
       }
    }else{
        u16_runSelfPrimecnt = 0;
        u16_SelPrimeFlg=0;
    }

    //����ʱ�ط���
    if(motorVars_M1.flagEnableRunAndIdentify==1){
        if(u16_self_overFlg==0){
            if(u16_press > 200){//SPEED_MAX){
                u16_runCnt++;
                if(u16_runCnt>20){  //5s
                    u16_self_overFlg=1;
                    u16_runCnt=0;
                }
            }else{
                u16_runCnt=0;
            }
        }
        if(u16_self_overFlg==1){
            if((u16_press < 200) && ((f_spd_temp+150) > SPEED_MAX)){
                u16_runCnt++;
                if(u16_runCnt>80){  //20s
                    u_fault_sta.bit.inCloseErr=1;
                    u16_runCnt = 0;
                }
            }else{
               u16_runCnt=0;
            }
        }
    }else{
        u16_runCnt=0;
        u16_self_overFlg=0;
    }

    static unsigned long zeroSpd_clr_cnt=0;
    if((fault_cnt.inclose_errCnt>0)&&(fault_cnt.inclose_errCnt<8)){
        zeroSpd_clr_cnt++;
        if(zeroSpd_clr_cnt>1200){       //5min*60*1000/250=1200
            zeroSpd_clr_cnt=0;
            fault_cnt.inclose_errCnt=0;
        }
    }else{
        zeroSpd_clr_cnt=0;
    }
    if(u_fault_sta.bit.inCloseErr==1){
        u16_runRecCnt++;
        if(u16_runRecCnt>27){    //7.0s+0.5s
            fault_cnt.inclose_errCnt++;
            u16_runRecCnt=28;
            if(sys_param.errRstEn==1){
                fault_cnt.inclose_errCnt=0;
                u_fault_sta.bit.inCloseErr=0;
                u16_runRecCnt=0;
                zeroSpd_clr_cnt=0;
            }
            if(fault_cnt.inclose_errCnt<8){      //8��
                u16_runRecCnt=0;
                u_fault_sta.bit.inCloseErr=0;
                zeroSpd_clr_cnt=0;
            }
        }
    }else{
        u16_runRecCnt=0;
    }

    if(fault_cnt.inclose_errCnt > 7){
        u16_24h_timecnt++;
        if(u16_24h_timecnt > 345600){     //24*60*60*1000/250=345600
            u16_24h_timecnt=0;
            u_fault_sta.bit.inCloseErr=0;
            fault_cnt.inclose_errCnt=0;
        }
    }else{
        u16_24h_timecnt=0;
    }


    //�����ж�
    if(u16_pressCtrlEn==1){
        u16_antiFreezeFlg=0;
        u16_antiFreezeTime=0;
    }else if(u16_SCI_FreezeEn==1){      //����ʹ��
        if((s16_temper_medium<5)&&(u16_antiFreezeFlg==0)&&(motorVars_M1.flagEnableRunAndIdentify==0)){
            u16_antiFreezeTime++;
            if(u16_antiFreezeTime>80){     //20s*1000/250=80
               u16_antiFreezeTime=0;
               u16_antiFreezeFlg=1;
            }
        }
    }else{
        u16_antiFreezeFlg=0;
        u16_antiFreezeTime=0;
    }

    //����PI����
    if((u16_pressCtrlEn==1)){
        if(su_distDir==1){
            pressCtrlLmt.Deta = u16_pressCmd + 300; //�Ŷ�3m
        }else{
            pressCtrlLmt.Deta = u16_pressCmd;
        }
        press_set= (unsigned int)pressCtrlLmt.Deta;
        //pressCtrlLmt.Deta = u16_pressCmd;
        pressCtrlLmt.Deta = pressCtrlLmt.Deta - u16_press;
        if(f_pwr_temp > (powerLmt.targetMax-20)){
            f_temp1 = f_spd_temp;
            f_temp1 = f_temp1*1000/SPEED_MAX;
            if(pressCtrlLmt.Out > (f_temp1+30)){
                cntPwrLimit++;
                if(cntPwrLimit>2){
                    cntPwrLimit=2;
                    pressCtrlLmt.Max = f_temp1+20;
                }
            }
        }else{
            cntPwrLimit=0;
            pressCtrlLmt.Max = 1000;
        }
        if(u16_StopCtrlFlg==0){
            PID((PID_STRUCT *)&pressCtrlLmt);
        }
        f_temp = pressCtrlLmt.Out;

        LINE_STRUCT pwr_spd_min = LINE_STRTUCT_DEFALUTS;
        //***����1��
        if(f_spd_temp < 1000){
            f_temp1 = u16_liquid_sps_min_pwr[0];
        }else if(f_spd_temp>5500){
            f_temp1 = u16_liquid_sps_min_pwr[SPD_NUM_PWR-1];
        }else{
            u16_temp = (f_spd_temp-1000)/500;
            if(u16_temp>(SPD_NUM_PWR-1)){
                u16_temp = SPD_NUM_PWR-1;
            }
            pwr_spd_min.x1 = u16_temp*500+1000;
            pwr_spd_min.x2 = pwr_spd_min.x1 + 500;
            pwr_spd_min.y1 = u16_liquid_sps_min_pwr[u16_temp];
            pwr_spd_min.y2 = u16_liquid_sps_min_pwr[u16_temp+1];
            pwr_spd_min.x =  f_spd_temp;
            pwr_spd_min.calc(&pwr_spd_min);
            f_temp1 = pwr_spd_min.y;    //ֵ��Ĳ���
        }
        //���п�ʼʱ����ʱ
        if(motorVars_M1.flagEnableRunAndIdentify==1){
            start_flg=1;
        }else{
            start_flg=0;
        }
        if(start_flg==0){
            u16_runStopCnt = 0;
            u16_runStop2Cnt=0;
            su_distDir=0;
            su_distCnt=0;
            start_cnt=0;
        }else if(start_flg==1){
            start_cnt++;
            if(start_cnt<4){    //1s
                u16_runStopCnt = 0;
                u16_runStop2Cnt=0;
                su_distDir=0;
                su_distCnt=0;
            }else{
                start_cnt = 17;
            }
        }

        //����ʱ���ж�
        if( (u16_press < 150 ) && ((f_spd_temp+150) > powerLmt.Max)){//SPEED_MAX)){
            u16_runStopCnt = 0;
            u16_runStop2Cnt=0;
            su_distDir=0;
            su_distCnt=0;
        }
        static unsigned int lowSPdCnt=0;
        //�����Ŷ�
        if(f_spd_temp < 2600){
            if(su_distDir==0){
                if( (u16_press < (press_set+100)) && ((u16_press+100) > press_set) ){
                    u16_runStop2Cnt=0;
                }else{
                    u16_runStop2Cnt++;
                }
            }else{
                u16_runStop2Cnt=0;
            }

            if(u16_runStop2Cnt>16){         //16*250=4s������δ������ѹ���仯ֵ��ͣ����
                u16_runStop2Cnt = 0;
                u16_pressCtrlEn=0;
                f_temp = 0;
            }
            su_distCnt++;
            if(su_distCnt>40){ //10s�Ŷ�һ��
              if( (u16_press < (press_set+100)) && ((u16_press+100) > press_set) ){
                if(su_distDir==0){
                     su_distDir=1;
                }else{
                     su_distDir=0;
                }
                su_distCnt = 0;
              }
            }
            u16_runStopCnt=0;
            lowSPdCnt=0;
        }else{
            //su_distCnt=0;
            lowSPdCnt++;
            if(lowSPdCnt>12){
                lowSPdCnt=0;
                u16_runStop2Cnt=0;
                su_distDir=0;
            }

            if((f_pwr_temp < f_temp1)&&(u16_StopCtrlFlg==0)){
                u16_runStopCnt++;
                if(u16_runStopCnt > 8){   //2s
                    u16_runStopCnt = 0;
                    u16_pressCtrlEn=0;
                    f_temp = 0;
                    u16_StopCtrlFlg=1;
                }
            }else{
               u16_runStopCnt = 0;
            }
            f_temp1 = f_temp1+15;
            if(f_pwr_temp>f_temp1){
                //u16_StopCtrlFlg=0;
            }
        }
        /*if((u16_StopCtrlFlg==0)&&(u16_satStopCnt==0)){
            u16_satStopAlltime=0;
        }
        if(u16_satStopAlltime>100){
            u16_satStopAlltime=0;
        }
        u16_satStopAlltime++;
        if(u16_satStopAlltime<50){
            if(u16_satStopCnt>1){
                u16_pressCtrlEn=0;
                u16_StopCtrlFlg=0;
                u16_satStopAlltime=0;
                u16_satStopCnt=0;
            }
        }*/
        static unsigned int time_cnt=0;
        if(u16_StopCtrlFlg==1){
            if(u16_pressFlg==0){
                f_temp = fabsf(motorSpd)/powerLmt.Max;
                /*if(fabsf(motorSpd)>4500){
                    f_temp = f_temp*1000-46;
                }else{
                    f_temp = f_temp*1000-46;
                }*/
                f_temp = f_temp*1000-46;  //46=207/4500;
                u16_SpdSet = f_temp;
                u16_pressFlg=1;
                u16_pressCtrlEn=1;
                u16_pressSave = u16_press;
                u16_pressScnt=0;
                u16_satStopCnt++;
            }else{
                u16_pressScnt++;
                time_cnt++;
                if(time_cnt<4){
                    f_temp = u16_SpdSet+34;
                }else if(time_cnt<8){
                    f_temp = u16_SpdSet+22;
                }else if(time_cnt<12){
                    f_temp = u16_SpdSet+10;
                }else if(time_cnt<16){
                    f_temp = u16_SpdSet;
                    time_cnt=14;
                }
                if(u16_pressScnt>12){   //3s
                    u16_StopCtrlFlg=0;
                    u16_pressScnt=0;
                    time_cnt=0;
                    if(u16_pressSave<(u16_press+150)){      //����150������ͣ����й¶��
                        u16_pressCtrlEn=0;
                        u16_satStopCnt=0;
                        u16_stopPressSaveFlg=1;
                    }
                    else{
                        u16_stopPressSaveFlg=0;
                        u16_pressCtrlEn=1;
                    }
                }else{
                    u16_pressCtrlEn=1;
                }
            }
        }else{
            u16_pressFlg=0;
            u16_pressScnt=0;
        }
        if(CANtest_flg==1){
        }else{
      #if HMI_CONTROL_EN==3
             u_sci_enable.bit.can_enable = u16_pressCtrlEn;
      #endif
        }
    }else if((u16_antiFreezeFlg==1)||(u16_tmpSensorErrFlg==1)){//��ʾ���������Ϳ�������
        f_temp = 500;   //50%
        PID_Ctrl_int();
        u16_runStopCnt = 0;
        u16_runStop2Cnt=0;
        su_distDir=0;
        su_distCnt=0;
        if(CANtest_flg==1){
        }else{
    #if HMI_CONTROL_EN==3
            if(u16_tmpSensorErrFlg==1){
                u_sci_enable.bit.can_enable=1;
            }else if(u_enable_HandC==1){
                u_sci_enable.bit.can_enable=1;
            }else{
                if((u16_antiFreezeFlg==1)&&(u16_SCI_FreezeEn==1)){
                    u16_antiFreezeTime++;
                    if(u16_antiFreezeTime>9600){     //40min*60*1000/250=9600
                       u_sci_enable.bit.can_enable=0;
                       u16_antiFreezeFlg=0;
                       u16_antiFreezeTime=0;
                    }else{
                       u_sci_enable.bit.can_enable=1;
                    }
                }else{
                    u_sci_enable.bit.can_enable=0;
                }
            }
    #endif
        }
        //u16_pressCtrlEn=1;
        u16_StopCtrlFlg=0;
        u16_satStopCnt=0;
        u16_satStopAlltime=0;
        u16_stopPressSaveFlg=0;
    }else{
        if(u16_StopCtrlFlg==0){
            PID_Ctrl_int();
            f_temp = 0;
            u16_runStopCnt = 0;
            u16_runStop2Cnt=0;
            su_distDir=0;
            su_distCnt=0;

            u16_pressFlg=0;
            u16_pressScnt=0;
        }else{
            f_temp=f_spd_temp*1000.0f;
            f_temp=f_temp/powerLmt.Max;
        }
        u16_satStopCnt=0;
        u16_satStopAlltime=0;
        if(CANtest_flg==1){
        }else{
    #if HMI_CONTROL_EN==3
            u_sci_enable.bit.can_enable = u16_pressCtrlEn;
    #endif
        }
    }

    if(CANtest_flg==1){ //ͨѶ����ʱ��Ч
        PID_Ctrl_int();
        f_temp = 0;
        u16_runStopCnt = 0;
    }else{
#if HMI_CONTROL_EN==3
        //PI���ڸ�ֵ
        u_speed_HandC = (unsigned int)f_temp;
        u_speed_can = u_speed_HandC;
        //u_sci_enable.bit.can_enable = u16_pressCtrlEn;
#endif
    }

}

void PID_Ctrl_int(void)
{
    pressCtrlLmt.KP = 0.08;
    pressCtrlLmt.KI = 0.03;
    pressCtrlLmt.KD = 0;
    pressCtrlLmt.Max = 1000;    //���ת��100.0%
    pressCtrlLmt.Min = 200;
    pressCtrlLmt.Total = 200;
    pressCtrlLmt.Out = 200;
    pressCtrlLmt.Deta = 0;
    pressCtrlLmt.Flag = 0;
    pressCtrlLmt.OutFlag = 0;
}

#endif
