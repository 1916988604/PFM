#ifndef	APP_FAULTDEBUG_C
#define	APP_FAULTDEBUG_C

#include "app_include.h"


#if (PMSM_DEBUG == 0)

extern volatile MOTOR_Vars_t motorVars_M1;
uint16_t motor_tripFLG=0;
uint16_t lv_data=0;
uint16_t ov_data=0;

#define	UDC_OVerr	450     //v
#define	UDC_OVrec	420     //v
#define ULN_OVerr   280     //vac
#define ULN_OVrec   260     //vac
#if test_drvboard==1
    #define	UDC_LVerr	10//150     //v 220
    #define	UDC_LVrec	12//200     //v 250
    #define ULN_LVerr   10//165     //vac
    #define ULN_LVrec   20//185     //vac
#else
    #define UDC_LVerr   150     //106ac
    #define UDC_LVrec   200     //141ac
    #define ULN_LVerr   165     //vac
    #define ULN_LVrec   185     //vac
#endif

#define	OUTCURerr	8//6      //A

#define	SPEED_noLoadErr		3500    //RPM;	//��ת�����ʼ�ٶ�
#define	CUR_noLoadErr		0.4//0.35     //A
#define	ROTORLock_cCUR	    0.8       //A
#define	ROTORLock_speed		300     //RPM	//��ת�����жϵ�

#define	IGBT_OTerr		110		//IGBT���µ�,��
#define	IGBT_OTwarn		105		//IGBT���±�����,��
#define	IGBT_OTrec		100		//IGBT���»ָ���,��

#define RESTART_TIME  800    //800*10=8.0S
#define ERRRESET_1MINTIME  6000  //1MIN*60*1000/10=6000

//��ʼ��
void  f_faultCheck_Init(void)
{
    unsigned long u32_temp;

	fault_cnt.canErr_cnt = 0;
    fault_cnt.os_cnt = 0;
    fault_cnt.recSpd_cnt = 0;
    fault_cnt.udcoc_cnt = 0;
    fault_cnt.pfc_cnt = 0;

	fault_cnt.igbt_OT_cnt = 0;
	fault_cnt.load_no_cnt = 0;
	fault_cnt.oc_cnt = 0;
	fault_cnt.ol_cnt = 0;
	fault_cnt.udc_lv_cnt = 0;
	fault_cnt.udc_ov_cnt = 0;
	fault_cnt.zeroSpd_cnt = 0;
	fault_cnt.phaseCnc_cnt = 0;
    fault_cnt.uln_ov_cnt = 0;
    fault_cnt.uln_lv_cnt = 0;
    fault_cnt.loadNcWarn_cnt = 0;
    fault_cnt.zero_spdErrCnt = 0;

    fault_cnt.udc_errChk = 0;
    fault_cnt.spd_errChk = 0;
    fault_cnt.is_errChk = 0;
    fault_cnt.Vln_errChk = 0;

    u_motor_ctrl.all = 0;
    u_fault_sta.all = 0;
    motorVars_M1.lostPhaseTimeCnt = 0;
    motorVars_M1.faultMtrNow.bit.motorLostPhase = 0;
    fault_cnt.phaseCnc_cnt2 = 0;
    fault_cnt.phaseCnc_cnt3 = 0;
    fault_cnt.phaseCnc_cnt4 = 0;
    fault_cnt.phaseCnc_cnt5 = 0;
    fault_cnt.phaseCnc_errCnt=0;

    sciErrTime = 0;
    motor_tripFLG=0;
    u_fault_sta.bit.zeroSpd=0;
    u_fault_sta.bit.SelfPrimErr=0;

    u32_temp = ULN_LVrec;
    u32_temp = u32_temp*128+(ULN_LVerr>>1);
    lv_data=u32_temp;
    u32_temp = ULN_OVrec;
    u32_temp = u32_temp*128+(ULN_OVerr>>1);
    ov_data=u32_temp;
}

void  f_faultPhaseNC_Check(void)
{
    //ȱ��
    if((fabsf(iq_ref_f) > 1.5)&&(u_fault_sta.bit.os==0)){// && (fault_cnt.spd_errChk>500)){
        if((motorVars_M1.adcData.I_A.value[0] < 0.8)&&(motorVars_M1.adcData.I_A.value[0] > -0.8)){
            fault_cnt.phaseCnc_cnt++;
            if(fault_cnt.phaseCnc_cnt>16000){ //1s*1000*1000/62.5=
                fault_cnt.phaseCnc_cnt=0;
                //motorVars_M1.faultMtrNow.bit.motorLostPhase = 1;
                u_fault_sta.bit.os = 1;
            }
        }else{
            if(u_fault_sta.bit.os==0){
                fault_cnt.phaseCnc_cnt=0;
            }
        }

        if((motorVars_M1.adcData.I_A.value[1] < 0.8)&&(motorVars_M1.adcData.I_A.value[1] > -0.8)){
            fault_cnt.phaseCnc_cnt2++;
            if(fault_cnt.phaseCnc_cnt2>16000){ //1s
                fault_cnt.phaseCnc_cnt2=0;
                u_fault_sta.bit.os = 1;
            }
        }else{
            if(u_fault_sta.bit.os==0){
                fault_cnt.phaseCnc_cnt2=0;
            }
        }

        if((motorVars_M1.adcData.I_A.value[2] < 0.8)&&(motorVars_M1.adcData.I_A.value[2] > -0.8)){
            fault_cnt.phaseCnc_cnt3++;
            if(fault_cnt.phaseCnc_cnt3>16000){ //1s
                fault_cnt.phaseCnc_cnt3=0;
                u_fault_sta.bit.os = 1;
            }
        }else{
            if(u_fault_sta.bit.os==0){
                fault_cnt.phaseCnc_cnt3=0;
            }
        }
        fault_cnt.phaseCnc_cnt5=0;
        fault_cnt.phaseCnc_cnt4=0;
        if(u_fault_sta.bit.os==1){
            fault_cnt.phaseCnc_errCnt++;
        }
    }else{
        if(u_fault_sta.bit.os==0){
            fault_cnt.phaseCnc_cnt=0;
            fault_cnt.phaseCnc_cnt2=0;
            fault_cnt.phaseCnc_cnt3=0;
            fault_cnt.phaseCnc_cnt4=0;
            fault_cnt.phaseCnc_cnt5=0;
        }else{
        }
    }
}

//���ϼ��,10ms
void  f_faultCheck(void)
{
	long u32_temp;
	float f_temp;

	static unsigned int udcLvFlgt=0;
	//static float f_is_chk=0;
#if 1
	//�������,ֻҪ�������
	/*if( (sys_param.errRstEn==1) && ((motorVars_M1.faultMtrNow.all != 0)||(u_fault_sta.all != 0)) ){
	    f_faultCheck_Init();    //��λ
	    motorVars_M1.flagClearFaults = 1;
	}*/

	fault_cnt.udc_errChk = motorVars_M1.adcData.VdcBus_V;
    fault_cnt.spd_errChk = fabsf(motorSpd);
    f_temp = fabsf(motorVars_M1.Is_A);
    fault_cnt.is_errChk = f_temp*0.05 + fault_cnt.is_errChk*0.95;
#if test_drvboard==1
    fault_cnt.Vln_errChk = motorVars_M1.adcData.VdcBus_V;
#else
    fault_cnt.Vln_errChk = Temp_IGBT.V_LN_Lpf;
#endif

    //ȱ��ָ�
    static unsigned long phaseNC_clr_cnt=0;
    static unsigned int err_cnt_pha=0,err_cnt_pha2=0;
    if((sys_param.errRstEn==1)&&(u_fault_sta.bit.os!=0)){
        fault_cnt.phaseCnc_errCnt=0;
        phaseNC_clr_cnt=0;
        fault_cnt.phaseCnc_cnt4=0;
        fault_cnt.phaseCnc_cnt=0;
        fault_cnt.phaseCnc_cnt2=0;
        fault_cnt.phaseCnc_cnt3=0;
        fault_cnt.phaseCnc_cnt5=0;
        motorVars_M1.faultMtrNow.bit.motorLostPhase=0;
        err_cnt_pha=0;
        err_cnt_pha2=0;
        u_fault_sta.bit.os=0;
    }
    if((fault_cnt.phaseCnc_errCnt>0)&&(fault_cnt.phaseCnc_errCnt<5)){
        phaseNC_clr_cnt++;
        if(phaseNC_clr_cnt>ERRRESET_1MINTIME){       //5min*60*1000/10=30000
            phaseNC_clr_cnt=0;
            fault_cnt.phaseCnc_errCnt=0;
        }
    }

    /*if((fabsf(iq_ref_f) > 0.8)&&(motorVars_M1.unbalanceRatio > motorSetVars_M1.unbalanceRatioSet) &&(u_fault_sta.bit.os==0))
    {
        if(err_cnt_pha > 200)   //2s
        {
            //motorVars_M1->faultMtrNow.bit.currentUnbalance = 1;
            u_fault_sta.bit.os=1;
            err_cnt_pha = 0;
        }
        else
        {
            err_cnt_pha++;
        }
    }
    else if(err_cnt_pha > 0)
    {
        err_cnt_pha--;
    }*/
    /*if((fabsf(iq_ref_f) > 0.8)&&(u_fault_sta.bit.os==0) && (fault_cnt.spd_errChk>500)){
        if((motorVars_M1.Irms_A[0] < 0.2) ||\
                      (motorVars_M1.Irms_A[1] < 0.2) ||\
                      (motorVars_M1.Irms_A[2] < 0.2))
        {
            err_cnt_pha2++;
            if(err_cnt_pha2>200){ //2s*1000*1000/62.5=
                err_cnt_pha2=0;
                u_fault_sta.bit.os = 1;
            }
        }else{
            if(u_fault_sta.bit.os==0){
                err_cnt_pha2=0;
            }
        }
    }else{
        err_cnt_pha2=0;
    }*/

    /*f_temp = iq_ref_f;
    f_temp = f_temp - iq_fbk_f;
    if((f_temp <  0.2) && (f_temp > -0.2)){
        err_cnt_pha3++;
        if(err_cnt_pha3>200){
            err_cnt_pha3=0;
            u_fault_sta.bit.os = 1 ;
        }
    }else{
        err_cnt_pha3=0;
    }*/


    if(u_fault_sta.bit.os==1){
        fault_cnt.phaseCnc_cnt4++;
        if(fault_cnt.phaseCnc_cnt4>RESTART_TIME){
            fault_cnt.phaseCnc_cnt=0;
            fault_cnt.phaseCnc_cnt2=0;
            fault_cnt.phaseCnc_cnt3=0;
            fault_cnt.phaseCnc_cnt5=0;
            fault_cnt.phaseCnc_cnt4=RESTART_TIME;
            if(fault_cnt.phaseCnc_errCnt<5){
                u_fault_sta.bit.os = 0;
                fault_cnt.phaseCnc_cnt4=0;
            }
        }
    }

    //���뽻����ѹ
    if(fault_cnt.Vln_errChk  > ULN_OVerr){
        fault_cnt.uln_ov_cnt++;
        if(fault_cnt.uln_ov_cnt > 200){
            u_fault_sta.bit.udc_ov2 = 1;    //�ߵ�ѹ��ѹ����
            fault_cnt.uln_ov_cnt = 200;
        }
    }else if(fault_cnt.Vln_errChk  < ULN_OVrec){
        if(u_fault_sta.bit.udc_ov2 == 1){
            fault_cnt.uln_ov_cnt++;
            if(fault_cnt.uln_ov_cnt > 300){     //1s recover
                fault_cnt.uln_ov_cnt = 0;
                u_fault_sta.bit.udc_ov2 = 0;
            }
        }else{
            fault_cnt.uln_ov_cnt = 0;
        }
    }else{
        if(u_fault_sta.bit.udc_ov2 == 0){
            fault_cnt.uln_ov_cnt = 0;
        }
    }

    //���뽻��Ƿѹ
    if(fault_cnt.Vln_errChk  < ULN_LVerr){
        fault_cnt.uln_lv_cnt++;
        if(fault_cnt.uln_lv_cnt > 200){
            u_fault_sta.bit.udc_lv2 = 1;    //�ߵ�ѹǷѹ����
            fault_cnt.uln_lv_cnt = 200;
        }
    }else if(fault_cnt.Vln_errChk  > ULN_LVrec){
        if(u_fault_sta.bit.udc_lv2 == 1){
            fault_cnt.uln_lv_cnt++;
            if(fault_cnt.uln_lv_cnt > 300){     //1s recover
                fault_cnt.uln_lv_cnt = 0;
                u_fault_sta.bit.udc_lv2 = 0;
            }
        }else{
            fault_cnt.uln_lv_cnt = 0;
        }
    }else{
        if(u_fault_sta.bit.udc_lv2 == 0){
            fault_cnt.uln_lv_cnt = 0;
        }
    }

	//ĸ�߹�ѹ
	if(fault_cnt.udc_errChk  > UDC_OVerr){
		fault_cnt.udc_ov_cnt++;
		if(fault_cnt.udc_ov_cnt > 3){
			u_fault_sta.bit.udc_ov = 1;
			fault_cnt.udc_ov_cnt = 4;
		}
	}else if(fault_cnt.udc_errChk  < UDC_OVrec){
		if(u_fault_sta.bit.udc_ov == 1){
			fault_cnt.udc_ov_cnt++;
			if(fault_cnt.udc_ov_cnt > 304){		//3s recover
				fault_cnt.udc_ov_cnt = 0;
				u_fault_sta.bit.udc_ov = 0;
			}
		}else{
			fault_cnt.udc_ov_cnt = 0;
			u_fault_sta.bit.udc_ov = 0;
		}
	}else{
        if(u_fault_sta.bit.udc_ov == 0){
            fault_cnt.udc_ov_cnt = 0;
        }
	}

	//ĸ��Ƿѹ
	if(fault_cnt.udc_errChk  > UDC_LVerr){
		udcLvFlgt = 1;
	}
	if((udcLvFlgt==1)){//&&(gMotorVars.Flag_Run_Identify==1)){
		if(fault_cnt.udc_errChk  < UDC_LVerr){
			fault_cnt.udc_lv_cnt++;
			if(fault_cnt.udc_lv_cnt > 3){
				u_fault_sta.bit.udc_lv = 1;
				fault_cnt.udc_lv_cnt = 4;
			}
		}else if(fault_cnt.udc_errChk  > UDC_LVrec){
			if(u_fault_sta.bit.udc_lv){
				fault_cnt.udc_lv_cnt++;
				if(fault_cnt.udc_lv_cnt > 304){		//3s recover
					fault_cnt.udc_lv_cnt = 0;
					u_fault_sta.bit.udc_lv = 0;
				}
			}else{
				fault_cnt.udc_lv_cnt = 0;
				u_fault_sta.bit.udc_lv = 0;
			}
		}else{
	        if(u_fault_sta.bit.udc_lv == 0){
	            fault_cnt.udc_lv_cnt = 0;
	        }
		}
	}else{
		if(u_fault_sta.bit.udc_lv == 1){
			if(fault_cnt.udc_errChk  > UDC_LVrec){
				fault_cnt.udc_lv_cnt++;
				if(fault_cnt.udc_lv_cnt > 304){		//3s recover
					fault_cnt.udc_lv_cnt = 0;
					u_fault_sta.bit.udc_lv = 0;
				}
			}
		}else{
			fault_cnt.udc_lv_cnt = 0;
			u_fault_sta.bit.udc_lv = 0;
		}
	}

	//��ת����
    static unsigned long zeroSpd_clr_cnt=0;
    if((fault_cnt.zero_spdErrCnt>0)&&(fault_cnt.zero_spdErrCnt<5)){
        zeroSpd_clr_cnt++;
        if(zeroSpd_clr_cnt>ERRRESET_1MINTIME){       //1min*60*1000/10=6000
            zeroSpd_clr_cnt=0;
            fault_cnt.zero_spdErrCnt=0;
        }
    }
    if((sys_param.errRstEn==1)&&(u_fault_sta.bit.zeroSpd!=0)){
        fault_cnt.zero_spdErrCnt=0;
        zeroSpd_clr_cnt=0;
        u_fault_sta.bit.zeroSpd=0;
        fault_cnt.zeroSpd_cnt=0;
    }
	if((fabsf(fault_cnt.spd_errChk) < ROTORLock_speed)&&(fault_cnt.is_errChk > ROTORLock_cCUR)&&(u_fault_sta.bit.zeroSpd==0)){
		fault_cnt.zeroSpd_cnt++;
		if(fault_cnt.zeroSpd_cnt > 270){    //ʵ��100:1.5s
			u_fault_sta.bit.zeroSpd = 1;
			fault_cnt.zeroSpd_cnt = RESTART_TIME;
			fault_cnt.zero_spdErrCnt++;
		}
	}else{
	    if(u_fault_sta.bit.zeroSpd==0){
	        fault_cnt.zeroSpd_cnt = 0;
	    }else{
            if(fault_cnt.zeroSpd_cnt > 0){
                fault_cnt.zeroSpd_cnt--;
            }else{
                if(fault_cnt.zero_spdErrCnt<5){
                    u_fault_sta.bit.zeroSpd = 0;
                }
                //u_fault_sta.bit.zeroSpd = 0;
            }
	    }
	}

	//��ת
    static unsigned long loadno_clr_cnt=0;
    /*if((fault_cnt.loadNcWarn_cnt>0)&&(fault_cnt.loadNcWarn_cnt<5)){
        loadno_clr_cnt++;
        if(loadno_clr_cnt>ERRRESET_1MINTIME){       //5min*60*1000/10=30000
            loadno_clr_cnt=0;
            fault_cnt.loadNcWarn_cnt=0;
        }
    }*/
    if(fault_cnt.spd_errChk>500){
        loadno_clr_cnt++;
        if(loadno_clr_cnt>ERRRESET_1MINTIME){       //1min*60*1000/10=6000
            loadno_clr_cnt=0;
            fault_cnt.loadNcWarn_cnt=0;
            fault_cnt.inclose_errCnt=0;
        }
    }else if(fault_cnt.spd_errChk<300){
        loadno_clr_cnt=0;
    }


    if((sys_param.errRstEn==1)&&(u_fault_sta.bit.load_no!=0)){
        fault_cnt.loadNcWarn_cnt=0;
        loadno_clr_cnt=0;
        u_fault_sta.bit.load_no=0;
        fault_cnt.load_no_cnt=0;
    }
	if((fabsf(fault_cnt.spd_errChk) > 4350)&&(motorPwr_Lpf>150)&&(u_fault_sta.bit.load_no==0)){
        fault_cnt.load_no_cnt = 0;
        u_fault_sta.bit.load_no = 0;
	}else if((fabsf(fault_cnt.spd_errChk) > SPEED_noLoadErr)&&(fault_cnt.is_errChk < CUR_noLoadErr)&&(u_fault_sta.bit.load_no==0)){
		fault_cnt.load_no_cnt++;
		if(fault_cnt.load_no_cnt > 2000){   //2000-22s; 20S
			u_fault_sta.bit.load_no = 1;
			fault_cnt.load_no_cnt = RESTART_TIME;    //8S
			fault_cnt.loadNcWarn_cnt++;
		}
	}else{
	    /*if(u_fault_sta.bit.load_no==0){
	        fault_cnt.load_no_cnt = 0;
	    }else*/{
            if(fault_cnt.load_no_cnt > 0){
                fault_cnt.load_no_cnt--;
            }else{

                if(fault_cnt.loadNcWarn_cnt<5){
                    u_fault_sta.bit.load_no = 0;
                }
                //u_fault_sta.bit.load_no = 0;
            }
	    }
	}

	//IGBT����
	if(Temp_IGBT.igbtTemp > IGBT_OTerr){
		fault_cnt.igbt_OT_cnt++;
		if(fault_cnt.igbt_OT_cnt>100){
			u_fault_sta.bit.igbt_OT = 1;
			//u_fault_sta.bit.igbt_OTwarn = 1;
		}
	}else{
	    if(u_fault_sta.bit.igbt_OT==0){
	        fault_cnt.igbt_OT_cnt=0;
	    }
	    if(Temp_IGBT.igbtTemp < IGBT_OTrec){
	        fault_cnt.igbt_OT_cnt = 0;
	        u_fault_sta.bit.igbt_OT = 0;
	    }
	}/*else if(Temp_IGBT.igbtTemp > IGBT_OTwarn){
		fault_cnt.igbt_OT_cnt++;
		if(fault_cnt.igbt_OT_cnt>100){
			u_fault_sta.bit.igbt_OTwarn = 1;
		}
	}else if(Temp_IGBT.igbtTemp < IGBT_OTrec){
		fault_cnt.igbt_OT_cnt = 0;
		u_fault_sta.bit.igbt_OT = 0;
		u_fault_sta.bit.igbt_OTwarn = 0;
	}else{
		fault_cnt.igbt_OT_cnt = 0;
	}*/

	//����
	static unsigned long oc_clr_cnt=0;
	if((fault_cnt.oc_cnt>0)&&(fault_cnt.oc_cnt<5)){
	    oc_clr_cnt++;
	    if(oc_clr_cnt>ERRRESET_1MINTIME){    //5min51*60*1000/10=6000
	        oc_clr_cnt=0;
	        fault_cnt.oc_cnt=0;
	    }
	}
    if((sys_param.errRstEn==1)&&(u_fault_sta.bit.oc!=0)){
        u_fault_sta.bit.oc = 0;
        motorVars_M1.faultMtrNow.bit.moduleOverCurrent = 0;
        motorVars_M1.flagClearFaults = 1;
        motor_tripFLG = 0;
        fault_cnt.oc_cnt=0;
        oc_clr_cnt=0;
        fault_cnt.oc_warn_cnt=0;
    }
	if((motor_tripFLG==1)&&(u_fault_sta.bit.oc==0)){
        u_fault_sta.bit.oc = 1;
        fault_cnt.oc_warn_cnt = RESTART_TIME;
        motor_tripFLG = 2;
        fault_cnt.oc_cnt++;
	}else if((motorVars_M1.faultMtrNow.bit.moduleOverCurrent==1)&&(motor_tripFLG != 2)&&(u_fault_sta.bit.oc==0)){
        u_fault_sta.bit.oc = 1;
        fault_cnt.oc_warn_cnt = RESTART_TIME;
        motor_tripFLG = 2;
        fault_cnt.oc_cnt++;
    }/*if((motorVars_M1.faultMtrNow.bit.moduleOverCurrent==1)&&(u_fault_sta.bit.oc==0)){
        u_fault_sta.bit.oc = 1;
        fault_cnt.oc_warn_cnt = RESTART_TIME;
    }*/else if( (fault_cnt.is_errChk > OUTCURerr)&&(u_fault_sta.bit.oc==0)){
		fault_cnt.oc_warn_cnt++;
		if(fault_cnt.oc_warn_cnt > 3){
			u_fault_sta.bit.oc = 1;
			fault_cnt.oc_warn_cnt = RESTART_TIME;
			fault_cnt.oc_cnt++;
		}
	}else{
	    if(u_fault_sta.bit.oc==0){
	        fault_cnt.oc_warn_cnt = 0;
	    }else{
            if(fault_cnt.oc_warn_cnt>0){
                fault_cnt.oc_warn_cnt--;
            }else{
                /*(if(sys_param.errRstEn==1){
                    u_fault_sta.bit.oc = 0;
                    motorVars_M1.faultMtrNow.bit.moduleOverCurrent = 0;
                    motorVars_M1.flagClearFaults = 1;
                    motor_tripFLG = 0;
                    fault_cnt.oc_cnt=0;
                    oc_clr_cnt=0;
                }else*/{
                    if(fault_cnt.oc_cnt<5)
                    {
                        /*if(motorVars_M1.faultMtrNow.bit.moduleOverCurrent==1){
                            motorVars_M1.flagClearFaults = 1;
                            u_fault_sta.bit.oc = 0;
                        }else{
                            motor_tripFLG = 0;
                            u_fault_sta.bit.oc = 0;
                        }*/
                        u_fault_sta.bit.oc = 0;
                        motorVars_M1.faultMtrNow.bit.moduleOverCurrent = 0;
                        motorVars_M1.flagClearFaults = 1;
                        motor_tripFLG = 0;
                        //oc_clr_cnt=0;
                    }
                }
            }
	    }
	}

#endif

#if    HMI_CONTROL_EN==1  || HMI_CONTROL_EN==3   //�������԰��߼�ʱ��Ч
    sciErrTime++;
    if(sciErrTime>1000){     //10s
        sciErrTime = 1000;
        u_fault_sta.bit.canwarn=1;
    }else{
        u_fault_sta.bit.canwarn=0;
    }
#endif

	f_temp = 2000;
#if MOTOR_DIR==1
	f_temp = -f_temp;
#endif

    static unsigned int err_stopCnt=0;
	if((u_fault_sta.bit.udc_lv) || (u_fault_sta.bit.udc_ov) || (u_fault_sta.bit.ol) || (u_fault_sta.bit.igbt_OT) \
	        || (u_fault_sta.bit.zeroSpd) || (u_fault_sta.bit.os) || (u_fault_sta.bit.oc) || (u_fault_sta.bit.pfcErr) \
	        || (udcLvFlgt==0) || (motorVars_M1.faultMtrNow.all !=0) || (u_fault_sta.bit.udc_lv2) || (u_fault_sta.bit.udc_ov2)\
	        || (u_fault_sta.bit.load_no) || (u_fault_sta.bit.SelfPrimErr)||(u_fault_sta.bit.inCloseErr)){
	        u_motor_ctrl.bit.run_enable = 0;
	        motorVars_M1.flagEnableRunAndIdentify=0;
			vcu_speedRampCmd = 0;
			f_pressCtrl_Init();
			liquidLmtInit();
            err_stopCnt=0;
	}else if(u_fault_sta.bit.canwarn){
	    if((u16_antiFreezeFlg==1)||(u16_tmpSensorErrFlg==1)){
	         vcu_speedRampCmd = speed_ramp_cmd;
            u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
	    }else{
	        u_motor_ctrl.bit.run_enable = 0;
            motorVars_M1.flagEnableRunAndIdentify=0;
            vcu_speedRampCmd = 0;
            f_pressCtrl_Init();
            liquidLmtInit();
            err_stopCnt=0;
	    }
	}/*else if(u_fault_sta.bit.igbt_OTwarn == 1){
		vcu_speedRampCmd = f_temp;		//2000RPM
        u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
	}*/else{
         vcu_speedRampCmd = speed_ramp_cmd;
         if(sys_param.errRstEn==1){
             err_stopCnt++;
             if(err_stopCnt>150){
                 err_stopCnt=150;
                 u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
             }else{
                 u_motor_ctrl.bit.run_enable = 0;
             }
         }else{
             err_stopCnt=150;   //���Ӵ�������ʾ��ͨѶ����ʱ�����ʵ��£�������1.5s��ͣ��
             u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
         }
	}
}

#endif
#endif





