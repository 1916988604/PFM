#ifndef	APP_CANSHINHOO_C
#define	APP_CANSHINHOO_C

#include "app_include.h"

#define	motor2	0	//0:��׼Э�飻1:��׼Э��2��2:��׼Э��3; 3:��׼Э��4/�������ܣ� 4::0x342/0x347/0x442

#define	SPD_MAXSEL	1	//0:6700; 1:6400		//����4.5KW����6400

extern volatile MOTOR_Vars_t motorVars_M1;

//��׼CAN��Ϣ
#if (PMSM_DEBUG == 10)||(PMSM_DEBUG == 20)||(PMSM_DEBUG == 27)

#if (PMSM_DEBUG == 10) || (PMSM_DEBUG == 27)
	#if motor2==0
	const Uint32 mail_id[32] = {0x341,0x4179,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,
								0x346,0x441,0x4191,0x4192,0x4193,0x4194,0x4195,0x4196,0x4197,0x4198,
								0x4199,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,
								0x4200,0x4200};
	#elif motor2==2
	const Uint32 mail_id[32] = {0x118,0x4179,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,
								0x230,0x330,0x4191,0x4192,0x4193,0x4194,0x4195,0x4196,0x4197,0x4198,
								0x4199,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,
								0x4200,0x4200};
	#elif motor2==3
	const Uint32 mail_id[32] = {0x351,0x4179,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,
								0x356,0x451,0x4191,0x4192,0x4193,0x4194,0x4195,0x4196,0x4197,0x4198,
								0x4199,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,
								0x4200,0x4200};
	#elif motor2==4
	const Uint32 mail_id[32] = {0x342,0x4179,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,
								0x347,0x442,0x4191,0x4192,0x4193,0x4194,0x4195,0x4196,0x4197,0x4198,
								0x4199,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,
								0x4200,0x4200};
	#else
	const Uint32 mail_id[32] = {0x140,0x4179,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,
								0x310,0x311,0x4191,0x4192,0x4193,0x4194,0x4195,0x4196,0x4197,0x4198,
								0x4199,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,
								0x4200,0x4200};
	#endif
#else
const Uint32 mail_id[32] = {0x747,0x4179,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,
                            0x787,0x767,0x4191,0x4192,0x4193,0x4194,0x4195,0x4196,0x4197,0x4198,
                            0x4199,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,
                            0x4200,0x4200};
#endif


/****************************************************************************************
** ��������:  mbox1-10������;  mbox10-20������;  30:UDS BOOT rx; 31:UDS BOOT tx; 32:����
****************************************************************************************/
void  J1939_Module_Mailbox_Config(void)
{
    CAN_setupMessageObject(myCAN0_BASE, 1, mail_id[0], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_RX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 2, mail_id[1], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_RX, 0, 0,8);

    CAN_setupMessageObject(myCAN0_BASE, 11, mail_id[10], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 12, mail_id[11], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 13, mail_id[12], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 14, mail_id[13], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 15, mail_id[14], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
}

/****************************************************************************************
** �����������ʼ��
****************************************************************************************/
void J1939_Common_Data_Init(void)
{
    unsigned int i;

    J1939_Module.u16_send_count1 = 0;  //����֡1������
    J1939_Module.u16_send_count1_flag  = 0;
    J1939_Module.u16_send_count2 = 0;   //����֡2������
    J1939_Module.u16_send_count2_flag  = 0;

    J1939_Module.flag_rece1 = 0;

    Agreement_data.MOT_SEND_CNT1 = 100 ;  //100ms
    Agreement_data.MOT_SEND_CNT2 = 100 ;  //100ms

    for(i=0;i<8;i++){
        ReceiveFrame.CANData[i]=0;
        ReceiveFrame1.CANData[i]=0;
        SendFrame.CANData[i]=0;
    }
}

void Time_Count(void)       //10ms os
{
    if(J1939_Module.u16_send_count1 < Agreement_data.MOT_SEND_CNT1)
    {
        J1939_Module.u16_send_count1++;
        if(J1939_Module.u16_send_count1 == Agreement_data.MOT_SEND_CNT1)
        {
            J1939_Module.u16_send_count1 = 0;
            J1939_Module.u16_send_count1_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count2 < Agreement_data.MOT_SEND_CNT2)
    {
        J1939_Module.u16_send_count2++;
        if(J1939_Module.u16_send_count2 == Agreement_data.MOT_SEND_CNT2)
        {
            J1939_Module.u16_send_count2 = 0;
            J1939_Module.u16_send_count2_flag = 1;
        }
    }
}

/****************************************************************************************
** ��������:  MOT��EVCU����
****************************************************************************************/
void Mot_Send_To_Evcu(void)   //10ms os
{
    if(J1939_Module.u16_send_count1_flag == 1)
    {
        J1939_Module.u16_send_count1_flag = 0;
        SysCanSendData(11);
    }
    if(J1939_Module.u16_send_count2_flag == 1)
    {
        J1939_Module.u16_send_count2_flag = 0;
        SysCanSendData(12);
    }
}

void SysCanSendData(Uint16 num)
{
	unsigned long  uIntTemp;
	Uint16 errRank,errType,errExtend,stateBase;
	static	int rollcnt346=0,rollcnt441=0;
    float   f_temp;

    if(num == 11)
    {
        f_temp = fabs(motorSpd);
        if(motorVars_M1.motorState<MOTOR_SEEK_POS){
            f_temp = 0;
        }
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[1] = uIntTemp & 0x0FF;		    //speed
        SendFrame.CANData[0] = (uIntTemp >> 8)& 0x0FF;

        if(motorVars_M1.adcData.VdcBus_V < 35)		//35V
        {
        	uIntTemp = 0;
        }else{
            uIntTemp = (Uint16)(motorVars_M1.adcData.VdcBus_V *0.5);	//udc,//2v�ֱ���
        }
        SendFrame.CANData[3] = uIntTemp & 0x0FF;
        SendFrame.CANData[2] = (uIntTemp >> 8)&0x0FF;

        if(u_fault_sta.all & 0x4FFF3){	//���Ӹ�ѹ��������
        	stateBase = 5;
        }else if(motorVars_M1.motorState>=MOTOR_SEEK_POS){		//>50V��Ϊ��ѹ����
        	stateBase = 2;
        }

#if ((MOTOR_NUMBER==2)&&(UDC_RANK!=545))||(MOTOR_NUMBER==7)||(UDC_RANK==345)||((MOTOR_NUMBER==0)&&(UDC_PCBA==1))
        else if(motorVars_M1.adcData.VdcBus_V > 200){		//>200V��Ϊ��ѹ����
        	stateBase = 0;
        }
#else
        else if(motorVars_M1.adcData.VdcBus_V > 400){		//>400V��Ϊ��ѹ����
        	stateBase = 0;
        }
#endif
        else{
        	stateBase = 4;
        }

        if(stateBase == 5){
        	if(u_fault_sta.bit.oc){
        		errRank = 3;
        		errExtend = 0;
        	}else if(u_fault_sta.bit.load_no){
        		errRank = 3;
        		errExtend = 5;
        	}else if(u_fault_sta.bit.zeroSpd){
        		errRank = 3;
        		errExtend = 6;
        	}else if(u_fault_sta.bit.tz){
        		errRank = 3;
        		errExtend = 7;
        	}else if(u_fault_sta.bit.udc_ov){
        		errRank = 2;
        		errExtend = 0;
        	}else if(u_fault_sta.bit.udc_oc){
        		errRank = 2;
        		errExtend = 2;
        	}else if(u_fault_sta.bit.checkErr){
        		errRank = 2;
        		errExtend = 3;
        	}else if(u_fault_sta.bit.udc_lv){
        		errRank = 1;
        		errExtend = 1;
        	}else if(u_fault_sta.bit.igbt_OTwarn){
        		errRank = 1;
        		errExtend = 2;
        	}else if(u_fault_sta.bit.canErr){
        		errRank = 1;
        		errExtend = 3;
        	}else if(u_fault_sta.bit.os){
        		errRank = 1;
        		errExtend = 5;
        	}else if(u_fault_sta.bit.ol){
        		errRank = 1;
        		errExtend = 6;
        	}else if(u_fault_sta.bit.revSpd){
        		errRank = 1;
        		errExtend = 7;
        	}else if(u_fault_sta.bit.hilErr){	//���ӻ����źŹ���
				errRank = 1;
				errExtend = 4;
			}
        	else{
        		errRank = 3;
        		errExtend = 1;
        	}
        }else{
        	errRank = 0;
        	errExtend = 0;
        }
        if(motorVars_M1.motorState>=MOTOR_SEEK_POS){
        	if(Temp_IGBT.idc < 10){
        		SendFrame.CANData[4] = 1;
        	}else{
                SendFrame.CANData[4] = fabsf(Temp_IGBT.idc/10);
        	}
        }else{
            SendFrame.CANData[4] = 0;
        }

        SendFrame.CANData[5] = errRank + (errExtend << 2) + (stateBase<<5);

        SendFrame.CANData[6] = (rollcnt346 << 4) + (u_fault_sta.bit.canErr<<3);
        rollcnt346++;
        if(rollcnt346>15){
        	rollcnt346 = 0;
        }
        uIntTemp = SendFrame.CANData[0] ^ SendFrame.CANData[1] ^ SendFrame.CANData[2] ^ SendFrame.CANData[3] ^ \
        		   SendFrame.CANData[4] ^ SendFrame.CANData[5] ^ SendFrame.CANData[6];
        SendFrame.CANData[7] = uIntTemp;

        CAN_sendMessage(myCAN0_BASE, 11, 8, SendFrame.CANData);
    }
    else if(num == 12)
    {
        SendFrame.CANData[0] = Temp_IGBT.igbtTemp + 40;		//ctrl TEMPE
        SendFrame.CANData[1] = Temp_IGBT.ntcTemp + 40;		//NTC TEMPE

        if(u_fault_sta.all & 0x08002){
        	errType = 2;
        }else if(u_fault_sta.all & 0x07FF1){
        	errType = 1;
        }else{
        	errType = 0;
        }
        SendFrame.CANData[2] = u_fault_sta.bit.udc_lv + (u_fault_sta.bit.udc_ov<<1) +\
        					   (u_fault_sta.bit.oc<<2)+ (u_fault_sta.bit.igbt_OT<<3) +\
        					   (errType<<4);

        SendFrame.CANData[3] = (rollcnt441 << 4);
        rollcnt441++;
        if(rollcnt441>15){
        	rollcnt441 = 0;
        }

#if MOTOR_NUMBER==1		//Y2
	#if PMSM410_NEW==0
		#if motor2==2
        	SendFrame.CANData[5] = 101;
        	SendFrame.CANData[6] = 221;
		#else
			#if CRC_FLG==0
					SendFrame.CANData[5] = 101;//203;		//101,��ҵ�汾���Ͱ汾��201������CRC��202����CRC
			#else
					SendFrame.CANData[5] = 205;
			#endif
			#if	CAN_PWM_MODE==1
					SendFrame.CANData[6] = 219;
			#elif VOL_HIGH_VER==2	//800V��ѹ��
					SendFrame.CANData[6] = 224;
			#elif PMSM_IDCFLG==4
					SendFrame.CANData[6] = 221;
			#else
					SendFrame.CANData[6] = 220;
			#endif
			//SendFrame.CANData[6] = 220;		//0x72:114��210��EVI�汾��220:410�汾��230:710�汾
		#endif
	#elif PMSM410_NEW==3
		SendFrame.CANData[5] = 101;
		SendFrame.CANData[6] = 223;
	#else
		SendFrame.CANData[5] = 101;
		SendFrame.CANData[6] = 222;
	#endif
#elif MOTOR_NUMBER==3		//710
		#if CRC_FLG==0
			#if COMM_TIME==1
				SendFrame.CANData[5] = 151;	//151:100msͨѶ����
			#else
				SendFrame.CANData[5] = 103;	//101��10k�����һ���ȣ�103��100ŷ���輰ǧһ����
			#endif
		#else
				SendFrame.CANData[5] = 205;
		#endif
        SendFrame.CANData[6] = 231;	//emc:231����EMC��230
#elif MOTOR_NUMBER==4		//710Pro
		#if (PMSM_DEBUG == 27)
        		SendFrame.CANData[5] = 4;	//���ܰ汾
		#elif CRC_FLG==0
				SendFrame.CANData[5] = 101;	//203����Ϊ101
		#else
				SendFrame.CANData[5] = 204;
		#endif
		#if PMSM710_NEW==1
				SendFrame.CANData[6] = 242;
		#elif PMSM710_NEW==2
				SendFrame.CANData[6] = 244;
		#elif PMSM_IDCFLG==4
				SendFrame.CANData[6] = 241;
		#else
				SendFrame.CANData[6] = 240;
		#endif
#elif MOTOR_NUMBER==2		//δ��345���
	#if CRC_FLG==0
			SendFrame.CANData[5] = 102;	//20231107����	//101;
	#else
			SendFrame.CANData[5] = 204;
	#endif
	#if PMSM302_NEW==0
		#if MOTOR_DIR==0
			SendFrame.CANData[6] = 213;
		#elif UDC_RANK==545
			SendFrame.CANData[6] = 211;
		#else
			SendFrame.CANData[6] = 212;
		#endif
	#else	//1:�������
		#if MOTOR_DIR==0
			SendFrame.CANData[6] = 216;
		#elif UDC_RANK==545
			SendFrame.CANData[6] = 214;
		#else
			SendFrame.CANData[6] = 215;
		#endif
	#endif
#elif MOTOR_NUMBER==5		//eph5500���
	#if	PMSM5500_NEW==0
		SendFrame.CANData[5] = 101;
        SendFrame.CANData[6] = 250;
	#elif	PMSM5500_NEW==2
		#if SPD_MAXSEL==1		//����
			SendFrame.CANData[5] = 104;	//103-����ĸ�ߵ������¾���
		#else
			SendFrame.CANData[5] = 103;	//103-����ĸ�ߵ������¾���
		#endif
        SendFrame.CANData[6] = 10;
	#else
		SendFrame.CANData[5] = 101;
        SendFrame.CANData[6] = 251;
	#endif
#elif MOTOR_NUMBER==7		//eph1500l���
	#if	PMSM410_NEW==1
		SendFrame.CANData[5] = 101;
		SendFrame.CANData[6] = 192;
	#else
		SendFrame.CANData[5] = 101;
		SendFrame.CANData[6] = 190;
	#endif
#else
		#if CRC_FLG==0
				SendFrame.CANData[5] = 101;
		#else
				SendFrame.CANData[5] = 204;
		#endif
        SendFrame.CANData[6] = 210;
#endif
#if (PMSM_DEBUG == 27)
        SendFrame.CANData[7] = 0;
        uIntTemp = SendFrame.CANData[0] ^ SendFrame.CANData[1] ^ SendFrame.CANData[2] ^ SendFrame.CANData[3]^\
        		   SendFrame.CANData[5] ^ SendFrame.CANData[6] ^ SendFrame.CANData[7];
#else
        uIntTemp = SendFrame.CANData[0] ^ SendFrame.CANData[1] ^ SendFrame.CANData[2] ^ SendFrame.CANData[3]^ SendFrame.CANData[5] ^ SendFrame.CANData[6];
#endif
        SendFrame.CANData[4] = uIntTemp;

        CAN_sendMessage(myCAN0_BASE, 12, 8, SendFrame.CANData);
    }
}

//���մ���
void  Mot_Receive_From_Evcu(void)   //200us
{
    unsigned int i;
    if( (CAN_readMessage(myCAN0_BASE, 1, rxMsgData)) && (J1939_Module.flag_rece1 == 0) )
	 {
        for(i=0;i<8;i++){
            ReceiveFrame.CANData[i] = rxMsgData[i];
        }
		J1939_Module.flag_rece1 = 1;
	 }
	 if( (CAN_readMessage(myCAN0_BASE, 2, rxMsgData)) && (J1939_Module.flag_rece2 == 0) )
	 {
        for(i=0;i<8;i++){
            ReceiveFrame1.CANData[i] = rxMsgData[i];
        }
		J1939_Module.flag_rece2 = 1;
	 }
}

void Evcu_Receive_Process(void) 	//10ms os
{
    float f_temp;
	long u32_temp;
	static int rollcntbak=0;
	static int rollcntFlg=0;
	int rollcntOK;

	static int canErrtime=0;
	static int canErrRectime=0;
	static int checkErrCnt=0;
	static long spd500Cnt=0;
	static int canErrCNT_CMP=500;

#if	CAN_PWM_MODE==1
	static unsigned int powerONFlg=0;
	static unsigned long powerONcnt=0;

	#if MOTOR_NUMBER==50
	    u_speed_can = -4500;	//4500RPM
	#elif MOTOR_DIR==1		//310
	    u_speed_can = -4750;
	#else
	    u_speed_can = 2600;
	#endif

 #if MOTOR_NUMBER==50
	if((motorVars_M1.adcData.VdcBus_V > 410)&&(u16_PreRelaySta.bit.preRelayOn)){	//>410v
 #else
 	if(motorVars_M1.adcData.VdcBus_V > 410){	//>410v
 #endif
		powerONcnt++;
		if(powerONcnt>100){		//1S
			powerONFlg=1;
			powerONcnt = 100;
		}
	}
	if((u_fault_sta.all & 0x07EFC)||(powerONFlg==0)){		//<430V������
		u_motor_ctrl.bit.enableCAN = 0;
	}else{
		if(motorVars_M1.adcData.VdcBus_V > 430){		//>430V
			u_motor_ctrl.bit.enableCAN = 1;
		}else if(motorVars_M1.adcData.VdcBus_V < 410){	//<410v
			u_motor_ctrl.bit.enableCAN = 0;
		}
	}
#else
	#if (PMSM_DEBUG == 27)
		canErrtime++;
		if(u_fault_sta.bit.canErr == 0){		//�޹���ʱ���Ƚ�ֵ��ֵ
			if((motorVars_M1.flagEnableRunAndIdentify==1)&&(u_motor_ctrl.bit.enableCAN==1)){		//���������ͨѶ�ж�
				canErrCNT_CMP = 100;	//1s
			}else{
				canErrCNT_CMP = 500;	//5s		//ͨѶ�жϳ��ϵ磻�����������ͨѶ�жϣ�ͨѶ�жϺ�����10S��ͣ����
			}
		}else{
			canErrCNT_CMP = 500;	//5s
		}
		if(canErrtime > canErrCNT_CMP){
			u_fault_sta.bit.canErr = 1;
			canErrtime = 500;		//ͨѶ���Ϻ�����10s����Զ�ͣ�����������ֵ���㡣ֻ��ͨѶ�ָ���ſɽ���ELSE�߼�
			canErrRectime = 0;
		}else{
			if(u_fault_sta.bit.canErr == 1){		//>200ms��ͨѶ��Ч�󣬹��ϻָ�
				canErrRectime++;
				if(canErrRectime>20){
					canErrRectime=0;
					u_fault_sta.bit.canErr = 0;
				}
			}
		}

	#else
		canErrtime++;
		if(canErrtime>100){		//1s
			canErrtime = 100;
			u_fault_sta.bit.canErr = 1;
		}else{
			u_fault_sta.bit.canErr = 0;
		}
	#endif

	spd500Cnt++;
    if(J1939_Module.flag_rece1 == TRUE)
    {
    	canErrtime = 0;
    	if(rollcntFlg == 0){
        	rollcntbak = ReceiveFrame.CANData[2] >> 4;
        	rollcntOK = 1;
        	rollcntFlg = 1;
    	}else{
    		rollcntFlg = 1;
			u32_temp = ReceiveFrame.CANData[2] >> 4;
			if((u32_temp == (rollcntbak + 1)) || (rollcntbak == 15)&&(u32_temp==0)){
				rollcntOK = 1;
			}else{
				rollcntOK = 0;
			}
			rollcntbak = ReceiveFrame.CANData[2] >> 4;
    	}

    	u32_temp = (ReceiveFrame.CANData[0]) ^ (ReceiveFrame.CANData[1]) ^ (ReceiveFrame.CANData[2]);
#if CRC_FLG==0
    	if(1){
#else
    	if((u32_temp == ReceiveFrame.CANData[3])&&(rollcntOK==1)){
#endif
			u32_temp=(ReceiveFrame.CANData[0] << 8) + ReceiveFrame.CANData[1];
			if((((ReceiveFrame.CANData[2])&0x03) == 2) || (((ReceiveFrame.CANData[2])&0x03) == 3)){
				u_motor_ctrl.bit.enableCAN = 1;
			}else{
				u32_temp = 0;
				u_motor_ctrl.bit.enableCAN = 0;
			}

			if(u32_temp>97){
				u32_temp = 97;		//4850
			}
			else if(u32_temp<4){
				u32_temp = 4;
			}
            f_temp = u32_temp;
            f_temp = f_temp * 0.103092783505; //1/97*1000

			u32_temp = (Uint16)f_temp;
#if MOTOR_DIR==1		//310
            vcu_speedDirCmd = -1;
#else
            vcu_speedDirCmd = 1;
#endif
            vcu_speedCmd = u32_temp;
	    	u_speed_can = vcu_speedCmd;
	        u_sci_enable.bit.can_enable = u_motor_ctrl.bit.enableCAN ;

			if(checkErrCnt>0){
				checkErrCnt--;
			}else{
				u_fault_sta.bit.checkErr = 0;
			}
    	}else{
    		checkErrCnt++;
    		if(checkErrCnt > 10){
				u_fault_sta.bit.checkErr = 1;
				checkErrCnt = 10;
    		}else{
    		}
    	}

        J1939_Module.flag_rece1 = 0;
    }
#endif
}

#endif

#endif


