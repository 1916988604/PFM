#ifndef	APP_DEBUGCAN_C
#define	APP_DEBUGCAN_C

#include "app_include.h"

//̨�ܼ�����������CAN��Ϣ
#if (PMSM_DEBUG == 0)

extern volatile MOTOR_Vars_t motorVars_M1;
extern MOTOR_SetVars_t motorSetVars_M1;
extern USER_Params userParams_M1;

#if  (PCBA_TYPE==driverES_PCBA) || (PCBA_TYPE==driverMegaS_PCBA)
const Uint32 mail_id[32] = {0x4180,0x4179,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,
                            0x4189,0x4190,0x4191,0x4192,0x4193,0x4194,0x4195,0x4196,0x4197,0x4289,
                            0x4290,0x4291,0x4292,0x4293,0x4294,0x4295,0x4296,0x4297,0x4298,0x4200,
                            0x4200,0x4200};
#else
const Uint32 mail_id[32] = {0x4280,0x4179,0x4280,0x4280,0x4280,0x4280,0x4280,0x4280,0x4280,0x4280,
                            0x4289,0x4290,0x4291,0x4292,0x4293,0x4294,0x4295,0x4296,0x4297,0x4298,
                            0x4299,0x4300,0x4300,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,
                            0x4200,0x4200};
#endif

/****************************************************************************************
** ��������:  mbox1-10������;  mbox10-20������;  30:UDS BOOT rx; 31:UDS BOOT tx; 32:����
****************************************************************************************/
void  J1939_Module_Mailbox_Config(void)
{
    CAN_setupMessageObject(myCAN0_BASE, 1, mail_id[0], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_RX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 2, mail_id[1], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_RX, 0, 0,8);

    CAN_setupMessageObject(myCAN0_BASE, 11, mail_id[10], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 12, mail_id[11], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 13, mail_id[12], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 14, mail_id[13], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 15, mail_id[14], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 16, mail_id[15], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 17, mail_id[16], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 18, mail_id[17], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 19, mail_id[18], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    //���ư�
    CAN_setupMessageObject(myCAN0_BASE, 20, mail_id[19], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 21, mail_id[20], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 22, mail_id[21], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 23, mail_id[22], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 24, mail_id[23], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 25, mail_id[24], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 26, mail_id[25], CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
}

/****************************************************************************************
** �����������ʼ��
****************************************************************************************/
void J1939_Common_Data_Init(void)
{
    unsigned int i;

    J1939_Module.u16_send_count1 = 0;  //����֡1������
    J1939_Module.u16_send_count1_flag  = 0;
    J1939_Module.u16_send_count2 = 0;   //����֡2������
    J1939_Module.u16_send_count2_flag  = 0;
    J1939_Module.u16_send_count3 = 0;  //����֡3������
    J1939_Module.u16_send_count3_flag  = 0;
    J1939_Module.u16_send_count4 = 0;  //����֡4������
    J1939_Module.u16_send_count4_flag  = 0;
    J1939_Module.u16_send_count5 = 0;  //����֡5������
    J1939_Module.u16_send_count5_flag  = 0;
    J1939_Module.u16_send_count6 = 0;  //����֡6������
    J1939_Module.u16_send_count6_flag  = 0;
    J1939_Module.u16_send_count7 = 0;  //����֡7������
    J1939_Module.u16_send_count7_flag  = 0;
    J1939_Module.u16_send_count8 = 0;  //����֡8������
    J1939_Module.u16_send_count8_flag  = 0;
    J1939_Module.u16_send_count9 = 0;  //����֡9������
    J1939_Module.u16_send_count9_flag  = 0;
    J1939_Module.u16_send_count10 = 0;  //����֡10������
    J1939_Module.u16_send_count10_flag  = 0;
    J1939_Module.u16_send_count11 = 0;  //����֡11������
    J1939_Module.u16_send_count11_flag  = 0;
    J1939_Module.u16_send_count12 = 0;  //����֡12������
    J1939_Module.u16_send_count12_flag  = 0;
    J1939_Module.u16_send_count13 = 0;  //����֡13������
    J1939_Module.u16_send_count13_flag  = 0;
    J1939_Module.u16_send_count14 = 0;  //����֡14������
    J1939_Module.u16_send_count14_flag  = 0;
    J1939_Module.u16_send_count15 = 0;  //����֡15������
    J1939_Module.u16_send_count15_flag  = 0;
    J1939_Module.u16_send_count16 = 0;  //����֡16������
    J1939_Module.u16_send_count16_flag  = 0;

    J1939_Module.flag_rece1 = 0;
    J1939_Module.flag_rece2 = 0;
    J1939_Module.flag_rece3 = 0;

    Agreement_data.MOT_SEND_CNT1 = 200 ;  //200ms
    Agreement_data.MOT_SEND_CNT2 = 200 ;  //200ms
    Agreement_data.MOT_SEND_CNT3 = 200 ;  //200ms
    Agreement_data.MOT_SEND_CNT4 = 200 ;  //200ms
    Agreement_data.MOT_SEND_CNT5 = 200 ;  //200ms
    Agreement_data.MOT_SEND_CNT6 = 200 ;  //200ms
    Agreement_data.MOT_SEND_CNT7 = 200 ;  //200ms
    Agreement_data.MOT_SEND_CNT8 = 200 ;  //200ms
    Agreement_data.MOT_SEND_CNT9 = 200 ;  //200ms
    Agreement_data.MOT_SEND_CNT10 = 500 ;  //500ms
    Agreement_data.MOT_SEND_CNT11 = 500 ;  //500ms
    Agreement_data.MOT_SEND_CNT12 = 500 ;  //500ms
    Agreement_data.MOT_SEND_CNT13 = 500 ;  //500ms
    Agreement_data.MOT_SEND_CNT14 = 500 ;  //500ms
    Agreement_data.MOT_SEND_CNT15 = 500 ;  //500ms
    Agreement_data.MOT_SEND_CNT16 = 500 ;  //500ms

    for(i=0;i<8;i++){
        ReceiveFrame.CANData[i]=0;
        ReceiveFrame1.CANData[i]=0;
        SendFrame.CANData[i]=0;
    }
    id_ref_can=0;
    iq_ref_can=0;
    id_ref_f=0;
    iq_ref_f=0;
    id_fbk_f=0;
    iq_fbk_f=0;
    vd_fbk_f=0;
    vq_fbk_f=0;
    motorPwr_f=0;
    motorSpd=0;
    motorTor=0;
    vd_ref_can=0;
    vq_ref_can=0;
    f_theta_delta=0.01;
    debug_cmd.resol_zero_adj=0;

    udata_test1 = 0;
    udata_test2 = 0;
    idata_test1 = 0;
    idata_test2 = 0;
    CANtest_flg=0;
}

void Time_Count(void)       //1ms os
{
    if(J1939_Module.u16_send_count1 < Agreement_data.MOT_SEND_CNT1)
    {
        J1939_Module.u16_send_count1++;
        if(J1939_Module.u16_send_count1 == Agreement_data.MOT_SEND_CNT1)
        {
            J1939_Module.u16_send_count1 = 0;
            J1939_Module.u16_send_count1_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count2 < Agreement_data.MOT_SEND_CNT2)
    {
        J1939_Module.u16_send_count2++;
        if(J1939_Module.u16_send_count2 == Agreement_data.MOT_SEND_CNT2)
        {
            J1939_Module.u16_send_count2 = 0;
            J1939_Module.u16_send_count2_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count3 < Agreement_data.MOT_SEND_CNT3)
    {
        J1939_Module.u16_send_count3++;
        if(J1939_Module.u16_send_count3 == Agreement_data.MOT_SEND_CNT3)
        {
            J1939_Module.u16_send_count3 = 0;
            J1939_Module.u16_send_count3_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count4 < Agreement_data.MOT_SEND_CNT4)
    {
        J1939_Module.u16_send_count4++;
        if(J1939_Module.u16_send_count4 == Agreement_data.MOT_SEND_CNT4)
        {
            J1939_Module.u16_send_count4 = 0;
            J1939_Module.u16_send_count4_flag = 1;
        }
    }

    if(J1939_Module.u16_send_count5 < Agreement_data.MOT_SEND_CNT5)
    {
        J1939_Module.u16_send_count5++;
        if(J1939_Module.u16_send_count5 == Agreement_data.MOT_SEND_CNT5)
        {
            J1939_Module.u16_send_count5 = 0;
            J1939_Module.u16_send_count5_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count6 < Agreement_data.MOT_SEND_CNT6)
    {
        J1939_Module.u16_send_count6++;
        if(J1939_Module.u16_send_count6 == Agreement_data.MOT_SEND_CNT6)
        {
            J1939_Module.u16_send_count6 = 0;
            J1939_Module.u16_send_count6_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count7 < Agreement_data.MOT_SEND_CNT7)
    {
        J1939_Module.u16_send_count7++;
        if(J1939_Module.u16_send_count7 == Agreement_data.MOT_SEND_CNT7)
        {
            J1939_Module.u16_send_count7 = 0;
            J1939_Module.u16_send_count7_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count8 < Agreement_data.MOT_SEND_CNT8)
    {
        J1939_Module.u16_send_count8++;
        if(J1939_Module.u16_send_count8 == Agreement_data.MOT_SEND_CNT8)
        {
            J1939_Module.u16_send_count8 = 0;
            J1939_Module.u16_send_count8_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count9 < Agreement_data.MOT_SEND_CNT9)
    {
        J1939_Module.u16_send_count9++;
        if(J1939_Module.u16_send_count9 == Agreement_data.MOT_SEND_CNT9)
        {
            J1939_Module.u16_send_count9 = 0;
            J1939_Module.u16_send_count9_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count10 < Agreement_data.MOT_SEND_CNT10)
    {
        J1939_Module.u16_send_count10++;
        if(J1939_Module.u16_send_count10 == Agreement_data.MOT_SEND_CNT10)
        {
            J1939_Module.u16_send_count10 = 0;
            J1939_Module.u16_send_count10_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count11 < Agreement_data.MOT_SEND_CNT11)
    {
        J1939_Module.u16_send_count11++;
        if(J1939_Module.u16_send_count11 == Agreement_data.MOT_SEND_CNT11)
        {
            J1939_Module.u16_send_count11 = 0;
            J1939_Module.u16_send_count11_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count12 < Agreement_data.MOT_SEND_CNT12)
    {
        J1939_Module.u16_send_count12++;
        if(J1939_Module.u16_send_count12 == Agreement_data.MOT_SEND_CNT12)
        {
            J1939_Module.u16_send_count12 = 0;
            J1939_Module.u16_send_count12_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count13 < Agreement_data.MOT_SEND_CNT13)
    {
        J1939_Module.u16_send_count13++;
        if(J1939_Module.u16_send_count13 == Agreement_data.MOT_SEND_CNT13)
        {
            J1939_Module.u16_send_count13 = 0;
            J1939_Module.u16_send_count13_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count14 < Agreement_data.MOT_SEND_CNT14)
    {
        J1939_Module.u16_send_count14++;
        if(J1939_Module.u16_send_count14 == Agreement_data.MOT_SEND_CNT14)
        {
            J1939_Module.u16_send_count14 = 0;
            J1939_Module.u16_send_count14_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count15 < Agreement_data.MOT_SEND_CNT15)
    {
        J1939_Module.u16_send_count15++;
        if(J1939_Module.u16_send_count15 == Agreement_data.MOT_SEND_CNT15)
        {
            J1939_Module.u16_send_count15 = 0;
            J1939_Module.u16_send_count15_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count16 < Agreement_data.MOT_SEND_CNT16)
    {
        J1939_Module.u16_send_count16++;
        if(J1939_Module.u16_send_count16 == Agreement_data.MOT_SEND_CNT16)
        {
            J1939_Module.u16_send_count16 = 0;
            J1939_Module.u16_send_count16_flag = 1;
        }
    }
}

/****************************************************************************************
** ��������:  MOT��EVCU����
****************************************************************************************/
void Mot_Send_To_Evcu(void)   //2ms os
{
    if(J1939_Module.u16_send_count1_flag == 1)
    {
        J1939_Module.u16_send_count1_flag = 0;
        SysCanSendData(11);
    }
    if(J1939_Module.u16_send_count2_flag == 1)
    {
        J1939_Module.u16_send_count2_flag = 0;
        SysCanSendData(12);
    }
    if(J1939_Module.u16_send_count3_flag == 1)
    {
        J1939_Module.u16_send_count3_flag = 0;
        SysCanSendData(13);
    }
    if(J1939_Module.u16_send_count4_flag == 1)
    {
        J1939_Module.u16_send_count4_flag = 0;
        SysCanSendData(14);
    }
    if(J1939_Module.u16_send_count5_flag == 1)
    {
        J1939_Module.u16_send_count5_flag = 0;
        SysCanSendData(15);
    }
    if(J1939_Module.u16_send_count6_flag == 1)
    {
        J1939_Module.u16_send_count6_flag = 0;
        SysCanSendData(16);
    }
    if(J1939_Module.u16_send_count7_flag == 1)
    {
        J1939_Module.u16_send_count7_flag = 0;
        SysCanSendData(17);
    }
    if(J1939_Module.u16_send_count8_flag == 1)
    {
        J1939_Module.u16_send_count8_flag = 0;
        SysCanSendData(18);
    }
    if(J1939_Module.u16_send_count9_flag == 1)
    {
        J1939_Module.u16_send_count9_flag = 0;
        SysCanSendData(19);
    }
#if  (PCBA_TYPE==driverES_PCBA)
    if(J1939_Module.u16_send_count10_flag == 1)
    {
        J1939_Module.u16_send_count10_flag = 0;
        SysCanSendData(20);
    }
    if(J1939_Module.u16_send_count11_flag == 1)
    {
        J1939_Module.u16_send_count11_flag = 0;
        SysCanSendData(21);
    }
    if(J1939_Module.u16_send_count12_flag == 1)
    {
        J1939_Module.u16_send_count12_flag = 0;
        SysCanSendData(22);
    }
    if(J1939_Module.u16_send_count13_flag == 1)
    {
        J1939_Module.u16_send_count13_flag = 0;
        SysCanSendData(23);
    }
    if(J1939_Module.u16_send_count14_flag == 1)
    {
        J1939_Module.u16_send_count14_flag = 0;
        SysCanSendData(24);
    }
    if(J1939_Module.u16_send_count15_flag == 1)
    {
        J1939_Module.u16_send_count15_flag = 0;
        SysCanSendData(25);
    }
#endif

    if(J1939_Module.u16_send_count16_flag == 1)
    {
        J1939_Module.u16_send_count16_flag = 0;
        SysCanSendData(26);
    }
}

#if  PCBA_TYPE==driverES_PCBA
void SysCanSendData(Uint16 num)
{
    Uint16 uIntTemp,uIntTemp2;
	long    Int_temp;
	float   f_temp;

    if(num == 11)       //0x4189
    {
        /*motorVars_M1.IdqRef_A.value[0] = 0.5;
        motorVars_M1.IdqRef_A.value[1] = -10.6;
        motorVars_M1.Idq_in_A.value[0] = 50.55;
        motorVars_M1.Idq_in_A.value[1] = -100.65;*/
        f_temp = id_ref_f;//motorVars_M1.IdqRef_A.value[0];
        f_temp = f_temp*100;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[0] = Int_temp & 0x0FF;		//idref
        SendFrame.CANData[1] = (Int_temp >> 8)& 0x0FF;

        f_temp = id_fbk_f;//objMtr->Idq_in_A.value[0];      //�ж�������ֵ������ֱ�ӵ��á�
        f_temp = f_temp*100;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[2] = Int_temp & 0x0FF;		//idfbk
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;

        f_temp = iq_ref_f;//motorVars_M1.IdqRef_A.value[1];
        f_temp = f_temp*100;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[4] = Int_temp & 0x0FF;		//iqref
        SendFrame.CANData[5] = (Int_temp >> 8)& 0x0FF;

        f_temp = iq_fbk_f;//motorVars_M1.Idq_in_A.value[1];
        f_temp = f_temp*100;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[6] = Int_temp & 0x0FF;		//iqfbk
        SendFrame.CANData[7] = (Int_temp >> 8)& 0x0FF;

        CAN_sendMessage(myCAN0_BASE, 11, 8, SendFrame.CANData);
    }
    else if(num == 12)       //0x4190
    {
        f_temp = motorSpd;//motorVars_M1.speedFilter_Hz;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[6] = Int_temp & 0x0FF;		//speed
        SendFrame.CANData[7] = (Int_temp >> 8)& 0x0FF;

        f_temp = motorSetVars_M1.overModulation;
        Int_temp = (int16)(f_temp*1000);
        SendFrame.CANData[0] = Int_temp & 0x0FF;		//vs_max
        SendFrame.CANData[1] = (Int_temp >> 8)& 0x0FF;
        uIntTemp = u_fault_sta.all;
        SendFrame.CANData[2] = uIntTemp & 0x0FF;		//err
        SendFrame.CANData[3] = (uIntTemp >> 8)& 0x0FF;

        f_temp = motorVars_M1.Vs_V;
        Int_temp = (int16)f_temp*10;
        SendFrame.CANData[4] = Int_temp & 0x0FF;		//vs
        SendFrame.CANData[5] = (Int_temp >> 8)& 0x0FF;

        CAN_sendMessage(myCAN0_BASE, 12, 8, SendFrame.CANData);
    }
    else if(num == 13)       //0x4191
    {
        f_temp = Temp_IGBT.V_LN_Lpf;       //�ߵ�ѹ
        uIntTemp = (Uint16)(f_temp*0.5);
        SendFrame.CANData[0] = uIntTemp;

        f_temp = 0;
        uIntTemp = (int16)(f_temp*100);
        SendFrame.CANData[1] = uIntTemp & 0x0FF;		//������ϵ��

        f_temp =  motorTor;//motorVars_M1.torque_Nm;
        f_temp = f_temp*100;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[2] = Int_temp & 0x0FF;		//torque
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;

        uIntTemp = motorVars_M1.faultMtrNow.all;
        SendFrame.CANData[4] = uIntTemp & 0x0FF;		//error
        SendFrame.CANData[5] = (uIntTemp >> 8)& 0x0FF;

        Int_temp = Temp_IGBT.igbtTemp;
        SendFrame.CANData[6] = Int_temp & 0x0FF;		//IGBT TEMPE
        SendFrame.CANData[7] = (Int_temp >> 8)& 0x0FF;

        CAN_sendMessage(myCAN0_BASE, 13, 8, SendFrame.CANData);
    }
    else if(num == 14)       //0x4192
    {
        f_temp = motorPwr_f;//motorPwr_Lpf;//motorPwr_f;//motorVars_M1.powerActive_W;//outpower;powerInvtOut_W
        Int_temp = (int16)(f_temp*10);
        SendFrame.CANData[0] = Int_temp & 0x0FF;
        SendFrame.CANData[1] = (Int_temp >> 8)& 0x0FF;
        f_temp = vd_fbk_f;//motorVars_M1.Vdq_out_V.value[0];
        Int_temp = (int16)(f_temp*10);
        SendFrame.CANData[2] = Int_temp & 0x0FF;		//vd
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;
        f_temp = vq_fbk_f;//motorVars_M1.Vdq_out_V.value[1];
        Int_temp = (int16)(f_temp*10);
        SendFrame.CANData[4] = Int_temp & 0x0FF;		//vq
        SendFrame.CANData[5] = (Int_temp >> 8)& 0x0FF;
        f_temp = motorVars_M1.adcData.VdcBus_V ;        //udc
        uIntTemp = (int16)(f_temp*10);
        SendFrame.CANData[6] = uIntTemp & 0x0FF;
        SendFrame.CANData[7] = (uIntTemp >> 8)&0x0FF;

        CAN_sendMessage(myCAN0_BASE, 14, 8, SendFrame.CANData);
    }
    else if(num == 15)       //0x4193
    {
        static	float isBak=0;

        SendFrame.CANData[0] = HW_VER_NUMBER;		//hardware version
        SendFrame.CANData[1] = SW_VER_NUMBER;		//software version

        f_temp = motorVars_M1.Is_A;
        f_temp = f_temp*10;
        f_temp = fabsf(isBak*0.9) + fabsf(f_temp*(0.1));
        isBak = f_temp;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[2] = Int_temp & 0x0FF;		//is
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;
        Int_temp = Temp_IGBT.idc;
        SendFrame.CANData[4] = Int_temp & 0x0FF;;		//idc
        SendFrame.CANData[5] = (Int_temp >> 8)& 0x0FF;
        Int_temp = Temp_IGBT.ntcTemp;
        SendFrame.CANData[6] = Int_temp & 0x0FF;		//ntc tempe
        SendFrame.CANData[7] = (Int_temp >> 8)& 0x0FF;

        CAN_sendMessage(myCAN0_BASE, 15, 8, SendFrame.CANData);
    }
    else if(num == 16)       //0x4194
    {
        SendFrame.CANData[0] = motorVars_M1.trajState + (motorVars_M1.estState<<4);
        SendFrame.CANData[1] = userParams_M1.motor_numPolePairs;
        SendFrame.CANData[2] = motorSetVars_M1.flux_Wb *100;
        SendFrame.CANData[3] = motorSetVars_M1.Ls_q_H * 10000;
        SendFrame.CANData[4] = motorSetVars_M1.Ls_d_H  * 10000;
        SendFrame.CANData[5] = motorSetVars_M1.Rr_Ohm *100;
        SendFrame.CANData[6] = motorSetVars_M1.RsOnLine_Ohm * 100;
        SendFrame.CANData[7] = motorSetVars_M1.Rs_Ohm * 100;

        CAN_sendMessage(myCAN0_BASE, 16, 8, SendFrame.CANData);
    }
    else if(num == 17)       //0x4195
    {
        f_temp = motorSetVars_M1.Kp_Id;
        uIntTemp = (int16)(f_temp*10000);
        SendFrame.CANData[0] = uIntTemp & 0x0FF;
        SendFrame.CANData[1] = (uIntTemp >> 8)& 0x0FF;
        f_temp = motorSetVars_M1.Kp_spd;
        uIntTemp = (int16)(f_temp*10000);
        SendFrame.CANData[2] = uIntTemp & 0x0FF;
        SendFrame.CANData[3] = (uIntTemp >> 8)& 0x0FF;
        f_temp =  motorSetVars_M1.Ki_Id;
        uIntTemp = (int16)(f_temp*10000);
        SendFrame.CANData[4] = uIntTemp & 0x0FF;
        SendFrame.CANData[5] = (uIntTemp >> 8)& 0x0FF;
        f_temp =  motorSetVars_M1.Ki_spd;
        uIntTemp = (int16)(f_temp*10000);
        SendFrame.CANData[6] = uIntTemp & 0x0FF;
        SendFrame.CANData[7] = (uIntTemp >> 8)& 0x0FF;

        CAN_sendMessage(myCAN0_BASE, 17, 8, SendFrame.CANData);
    }
    else if(num == 18)       //0x4196
    {
        uIntTemp = 0;       //pump_Q
        SendFrame.CANData[0] = uIntTemp & 0x0FF;
        SendFrame.CANData[1] = (uIntTemp >> 8)& 0x0FF;
        SendFrame.CANData[2] = boot_ver;  //BOOT VER;
        uIntTemp = 0;       //pump_H
        SendFrame.CANData[3] = uIntTemp & 0x0FF;
        SendFrame.CANData[4] = (uIntTemp >> 8)& 0x0FF;
        uIntTemp = 0;       //THETA
        SendFrame.CANData[5] = uIntTemp & 0x0FF;
        SendFrame.CANData[6] = (uIntTemp >> 8)& 0x0FF;
        uIntTemp = motorVars_M1.motorState<<2;
        SendFrame.CANData[7] = uIntTemp + Temp_IGBT.hvilFlg + (u16_PreRelaySta.bit.preRelayOn<<7) + \
                               (u16_PreRelaySta.bit.pfcCtrlOn<<1);	//bit0:HVIL; bit7:prerelay; bit1:PFC; bit2-bit6:motorsta*/
        CAN_sendMessage(myCAN0_BASE, 18, 8, SendFrame.CANData);
    }
    else if(num == 19)       //0x4197
    {
        SendFrame.CANData[0] = boot_RevID;
        SendFrame.CANData[1] = (boot_RevID>>8)&0x0FF;
        SendFrame.CANData[2] = boot_SendID;
        SendFrame.CANData[3] = (boot_SendID>>8)&0x0FF;
        SendFrame.CANData[4] = boot_Year;
        SendFrame.CANData[5] = boot_Month;
        SendFrame.CANData[6] = boot_Day;
        SendFrame.CANData[7] = boot_Baud;

        CAN_sendMessage(myCAN0_BASE, 19, 8, SendFrame.CANData);
    }
    //���ư���Ϣ
    else if(num == 20)       //0x4289
    {
        f_temp = pwmDuTy;
        f_temp = f_temp*10;     //0.1
        Int_temp = (int16)f_temp;
        SendFrame.CANData[0] = Int_temp & 0x0FF;

        uIntTemp = GPIO_readPin(Relay1_IO);
        uIntTemp2 = GPIO_readPin(Relay2_IO);
        SendFrame.CANData[1] = u16_DI1_sta + (u16_DI2_sta<<1) + (u16_DI3_sta<<2) + (uIntTemp<<3) + (uIntTemp2<<4) ;

        if(PCBA_TYPE==driverES_PCBA){
            f_temp = Temp_IGBT.igbtTemp*10;
        }else{
            f_temp = temperature*10;    //aiDeal[0];
        }
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[4] = uIntTemp & 0x0FF;
        SendFrame.CANData[5] = (uIntTemp >> 8)& 0x0FF;

        f_temp = tempeMediumEx*10;  //aiDeal[1];
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[2] = uIntTemp & 0x0FF;
        SendFrame.CANData[3] = (uIntTemp >> 8)& 0x0FF;

        f_temp = aiDeal[2];
        f_temp = f_temp*0.03546;    //*10
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[6] = uIntTemp & 0x0FF;
        SendFrame.CANData[7] = (uIntTemp >> 8)& 0x0FF;

        CAN_sendMessage(myCAN0_BASE, 20, 8, SendFrame.CANData);
    }
    else if(num == 21)       //0x4290
    {
        f_temp = aiDeal[3];
        f_temp = f_temp*0.05372;    //*10
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[0] = uIntTemp & 0x0FF;
        SendFrame.CANData[1] = (uIntTemp >> 8)& 0x0FF;

        Int_temp = sys_param.headSensor;      //0.1m
        SendFrame.CANData[2] = Int_temp & 0x0FF;
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;

        if(period>0.01){
            f_temp = 1000000000;
            f_temp = f_temp/period;     //0.1Hz
            uIntTemp = (Uint16)f_temp;      //PWM����Ƶ��
        }else{
            uIntTemp = 0;
        }
        SendFrame.CANData[4] = uIntTemp & 0x0FF;
        SendFrame.CANData[5] = (uIntTemp >> 8)& 0x0FF;

        f_temp = EPwm6Regs.CMPA.bit.CMPA;        //pwm���ռ�ձ�,0.01%
        f_temp = f_temp/EPwm6Regs.TBPRD*10000;
        if(f_temp>10000){
            f_temp = 10000;
        }else{
            f_temp = 10000-f_temp;
        }
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[6] = uIntTemp & 0x0FF;
        SendFrame.CANData[7] = (uIntTemp >> 8)& 0x0FF;

        CAN_sendMessage(myCAN0_BASE, 21, 8, SendFrame.CANData);
    }
    else if(num == 22)       //0x4291
    {
        f_temp = EPwm6Regs.TBPRD;                //pwm���Ƶ��
        f_temp = 1/(f_temp/100000000*32)*100;    //0.01Hz
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[0] = uIntTemp & 0x0FF;
        SendFrame.CANData[1] = (uIntTemp >> 8)& 0x0FF;

        f_temp = pwmDuTy;
        f_temp = f_temp*10;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[2] = Int_temp & 0x0FF;
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;

        SendFrame.CANData[4] = boot_ver;
        SendFrame.CANData[5] = HW_VER_NUMBER;
        SendFrame.CANData[6] = SW_VER_NUMBER;
        SendFrame.CANData[7] = 0;

        CAN_sendMessage(myCAN0_BASE, 22, 8, SendFrame.CANData);
    }
    else if(num == 23)       //0x4292
    {
        f_temp = motorVars_M1.adcData.offset_I_ad.value[0];//motorVars_M1.adcData.I_A.value[0];                //IA������
        f_temp = f_temp;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[0] = Int_temp & 0x0FF;
        SendFrame.CANData[1] = (Int_temp >> 8)& 0x0FF;

        f_temp = motorVars_M1.adcData.offset_I_ad.value[1];//motorVars_M1.adcData.I_A.value[1];                //IB������
        Int_temp = (int16)f_temp;
        SendFrame.CANData[2] = Int_temp & 0x0FF;
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;

        f_temp = motorVars_M1.adcData.offset_I_ad.value[2];//motorVars_M1.adcData.I_A.value[2];                //IC������
        Int_temp = (int16)f_temp;
        SendFrame.CANData[4] = Int_temp & 0x0FF;
        SendFrame.CANData[5] = (Int_temp >> 8)& 0x0FF;

        f_temp = motorVars_M1.adcData.offset_V_sf.value[0]*10;//motorVars_M1.adcData.V_V.value[0];                //UA������
        Int_temp = (int16)f_temp;
        SendFrame.CANData[6] = Int_temp & 0x0FF;
        SendFrame.CANData[7] = (Int_temp >> 8)& 0x0FF;
        CAN_sendMessage(myCAN0_BASE, 23, 8, SendFrame.CANData);
    }
    else if(num == 24)       //0x4293
    {
        f_temp = motorVars_M1.adcData.offset_V_sf.value[1]*10;//motorVars_M1.adcData.V_V.value[1];                //UB������
        f_temp = f_temp;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[0] = Int_temp & 0x0FF;
        SendFrame.CANData[1] = (Int_temp >> 8)& 0x0FF;

        f_temp = motorVars_M1.adcData.offset_V_sf.value[2]*10;//motorVars_M1.adcData.V_V.value[2];                //UV������
        Int_temp = (int16)f_temp;
        SendFrame.CANData[2] = Int_temp & 0x0FF;
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;

        f_temp = motorVars_M1.adcData.I_A.value[0];                //A�����
        Int_temp = (int16)(f_temp*10);
        SendFrame.CANData[4] = Int_temp & 0x0FF;
        SendFrame.CANData[5] = (Int_temp >> 8)& 0x0FF;

        f_temp = motorVars_M1.adcData.I_A.value[1];                //B�����
        Int_temp = (int16)(f_temp*10);
        SendFrame.CANData[6] = Int_temp & 0x0FF;
        SendFrame.CANData[7] = (Int_temp >> 8)& 0x0FF;
        CAN_sendMessage(myCAN0_BASE, 24, 8, SendFrame.CANData);
    }
    else if(num == 25)       //0x4294
    {
        f_temp = motorVars_M1.adcData.I_A.value[2];                //C�����
        Int_temp = (int16)(f_temp*10);
        SendFrame.CANData[0] = Int_temp & 0x0FF;
        SendFrame.CANData[1] = (Int_temp >> 8)& 0x0FF;

        f_temp = motorVars_M1.adcData.V_V.value[0];         //U���ѹ
        Int_temp = (int16)(f_temp*10);
        SendFrame.CANData[2] = Int_temp & 0x0FF;
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;

        f_temp = motorVars_M1.adcData.V_V.value[1];         //V���ѹ
        Int_temp = (int16)(f_temp*10);
        SendFrame.CANData[4] = Int_temp & 0x0FF;
        SendFrame.CANData[5] = (Int_temp >> 8)& 0x0FF;

        f_temp = motorVars_M1.adcData.V_V.value[2];         //W���ѹ
        Int_temp = (int16)(f_temp*10);
        SendFrame.CANData[6] = Int_temp & 0x0FF;
        SendFrame.CANData[7] = (Int_temp >> 8)& 0x0FF;
        CAN_sendMessage(myCAN0_BASE, 25, 8, SendFrame.CANData);
    }
    else if(num == 26)       //0x4295
    {
        f_temp = idata_test1;                               //��������1���з��ţ�
        Int_temp = (int16)(f_temp);
        SendFrame.CANData[0] = Int_temp & 0x0FF;
        SendFrame.CANData[1] = (Int_temp >> 8)& 0x0FF;

        f_temp = idata_test2;                               //��������2���з��ţ�
        Int_temp = (int16)(f_temp);
        SendFrame.CANData[2] = Int_temp & 0x0FF;
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;

        f_temp =  (u_fault_sta.all>>16); //u16_pressCmd;//(u_fault_sta.all>>16);                              //��������1���޷��ţ�
        uIntTemp = (Uint16)(f_temp);
        SendFrame.CANData[4] = uIntTemp & 0x0FF;
        SendFrame.CANData[5] = (uIntTemp >> 8)& 0x0FF;

        f_temp = u16_press;//udata_test2;                              //��������2���޷��ţ�
        uIntTemp = (Uint16)(f_temp);
        SendFrame.CANData[6] = uIntTemp & 0x0FF;
        SendFrame.CANData[7] = (uIntTemp >> 8)& 0x0FF;
        CAN_sendMessage(myCAN0_BASE, 26, 8, SendFrame.CANData);
    }
}
#else
void SysCanSendData(Uint16 num)
{
    Uint16 uIntTemp,uIntTemp2;
    long    Int_temp;
    float   f_temp;

    if(num == 11)       //0x4289
    {
        f_temp = 0;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[0] = Int_temp & 0x0FF;

        uIntTemp = GPIO_readPin(Relay1_IO);
        uIntTemp2 = GPIO_readPin(Relay2_IO);
        SendFrame.CANData[1] = u16_DI1_sta + (u16_DI2_sta<<1) + (u16_DI3_sta<<2) + (uIntTemp<<3) + (uIntTemp2<<4) ;

        f_temp = temperature*10;    //aiDeal[0];
        uIntTemp = (int16)f_temp;
        SendFrame.CANData[2] = uIntTemp & 0x0FF;
        SendFrame.CANData[3] = (uIntTemp >> 8)& 0x0FF;

        f_temp = tempeMediumEx*10;  //aiDeal[1];
        uIntTemp = (int16)f_temp;
        SendFrame.CANData[4] = uIntTemp & 0x0FF;
        SendFrame.CANData[5] = (uIntTemp >> 8)& 0x0FF;

        //f_temp = aiDeal[2];
        //f_temp = f_temp*0.03546;    //*10
        f_temp = u_speed_vi[2];
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[6] = uIntTemp & 0x0FF;
        SendFrame.CANData[7] = (uIntTemp >> 8)& 0x0FF;

        CAN_sendMessage(myCAN0_BASE, 11, 8, SendFrame.CANData);
    }
    else if(num == 12)       //0x4290
    {
        //f_temp = aiDeal[3];
        //f_temp = f_temp*0.05372;    //*10
        f_temp = u_speed_vi[3];
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[0] = uIntTemp & 0x0FF;
        SendFrame.CANData[1] = (uIntTemp >> 8)& 0x0FF;

        Int_temp = sys_param.headSensor;      //0.1m
        SendFrame.CANData[2] = Int_temp & 0x0FF;
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;

        if(period>0.01){
            f_temp = 1000000000;
            f_temp = f_temp/period;     //0.1Hz
            uIntTemp = (Uint16)f_temp;      //PWM����Ƶ��
        }else{
            uIntTemp = 0;
        }
        SendFrame.CANData[4] = uIntTemp & 0x0FF;
        SendFrame.CANData[5] = (uIntTemp >> 8)& 0x0FF;

        f_temp = EPwm4Regs.CMPA.bit.CMPA;        //pwm���ռ�ձ�,0.01%
        f_temp = f_temp/EPwm4Regs.TBPRD*10000;
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[6] = uIntTemp & 0x0FF;
        SendFrame.CANData[7] = (uIntTemp >> 8)& 0x0FF;

        CAN_sendMessage(myCAN0_BASE, 12, 8, SendFrame.CANData);
    }
    else if(num == 13)       //0x4291
    {
        f_temp = EPwm4Regs.TBPRD;                //pwm���Ƶ��
        f_temp = 1/(f_temp/100000000*32)*100;    //0.01Hz
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[0] = uIntTemp & 0x0FF;
        SendFrame.CANData[1] = (uIntTemp >> 8)& 0x0FF;

        f_temp = pwmDuTy;
        f_temp = f_temp*10;
        Int_temp = (int16)f_temp;
        SendFrame.CANData[2] = Int_temp & 0x0FF;
        SendFrame.CANData[3] = (Int_temp >> 8)& 0x0FF;

        SendFrame.CANData[4] = boot_ver;
        SendFrame.CANData[5] = HW_VER_NUMBER;
        SendFrame.CANData[6] = SW_VER_NUMBER;
        SendFrame.CANData[7] = 0;

        CAN_sendMessage(myCAN0_BASE, 13, 8, SendFrame.CANData);
    }
}
#endif


//���մ���
void  Mot_Receive_From_Evcu(void)   //200us
{
    unsigned int i;
    if( (CAN_readMessage(myCAN0_BASE, 1, rxMsgData)) && (J1939_Module.flag_rece1 == 0) )
     {
        for(i=0;i<8;i++){
            ReceiveFrame.CANData[i] = rxMsgData[i];
        }
        J1939_Module.flag_rece1 = 1;
     }
     if( (CAN_readMessage(myCAN0_BASE, 2, rxMsgData)) && (J1939_Module.flag_rece2 == 0) )
     {
        for(i=0;i<8;i++){
            ReceiveFrame1.CANData[i] = rxMsgData[i];
        }
        J1939_Module.flag_rece2 = 1;
     }
}


void Evcu_Receive_Process(void) 	//2ms os
{
	float f_temp;
	static Uint16 bitFalutClr=0;
	Uint16 FalutClrFlg=0;

    if(J1939_Module.flag_rece2 == 1)
    {
        debug_cmd.debugEn = ReceiveFrame1.CANData[0] & 0x01;
        debug_cmd.Relay1En = (ReceiveFrame1.CANData[0]>>1) & 0x01;
        debug_cmd.Relay2En = (ReceiveFrame1.CANData[0]>>2) & 0x01;
        debug_cmd.PWMoutValue = ReceiveFrame1.CANData[1];
    	J1939_Module.flag_rece2 = 0;
    }
    /*motorVars_M1.flagEnableForceAngle = 1;
    motorVars_M1.flagEnableRsRecalc = 0;
    motorVars_M1.flagEnableFWC = 1;
    motorVars_M1.flagEnableSpeedCtrl = 1;*/

    //�ϵ�û����ʾ��ʱ��3s��ȫ������
#if    HMI_CONTROL_EN==0
    if(CANtest_flg==0){
        u_speed_can = 1000;
        u_enable_HandC = 1;     //ǿ������
        u_sci_enable.bit.can_enable = 1;
    }
#elif  HMI_CONTROL_EN==1    //��ǿ�ƶ���

#elif  HMI_CONTROL_EN==2    //03-30EC�԰����
    sciErrTime++;
    if((sciErrTime>1500)&&(CANtest_flg==0)){
        sciErrTime = 1500;      //3s
        u_speed_can = 1000;
        u_sci_enable.bit.can_enable = 1;
        u_enable_HandC = 1;     //ǿ������
    }
#else
#endif

    if(J1939_Module.flag_rece1 == 1)
    {
        debug_cmd.index=ReceiveFrame.CANData[0];
        debug_cmd.value=ReceiveFrame.CANData[0] + (ReceiveFrame.CANData[1] <<8);

        //motorVars_M1.Flag_enableUserParams = (debug_cmd.value ) & 0x01;
        //motorVars_M1.flagEnableOffsetCalc = (debug_cmd.value >> 4) & 0x01;
        //motorVars_M1.flagEnableMotorIdentify = (debug_cmd.value >> 5) & 0x01;

        motorVars_M1.flagEnableForceAngle = (debug_cmd.value >> 1) & 0x01;
        motorVars_M1.flagEnableRsRecalc = (debug_cmd.value >> 2) & 0x01;
        motorVars_M1.flagEnableFWC = (debug_cmd.value >> 3) & 0x01;
        motorVars_M1.flagEnableSpeedCtrl = (debug_cmd.value >> 7) & 0x01;
        //vcu_speedDirCmd = -1;

        //�������
        FalutClrFlg = (debug_cmd.value >> 5) & 0x01;
        if(motorVars_M1.faultMtrNow.all !=0 ){
            if( (FalutClrFlg==0) && (bitFalutClr==0) ){
                bitFalutClr = 1;
            }else if((FalutClrFlg==1) && (bitFalutClr==1)){
                motorVars_M1.flagClearFaults = 1;
                bitFalutClr = 0;
            }
        }else{
            bitFalutClr = 0;
        }

        //�ٶȻ�����
        f_temp = ReceiveFrame.CANData[2] + (ReceiveFrame.CANData[3]<<8);
        //f_temp = f_temp*0.016666 * USER_MOTOR1_NUM_POLE_PAIRS;   //speed to freq; //userParams_M1.motor_numPolePairs;
    	if((debug_cmd.value >> 6) & 0x01){
    		//vcu_speedCmd = -f_temp;
    		vcu_speedDirCmd = -1;
    	}else{
    		//vcu_speedCmd = f_temp;
    		vcu_speedDirCmd = 1;
    	}
    	vcu_speedCmd = f_temp;

    	//�ٽǶȼ���
        f_temp = f_temp*0.0001;
        if(f_temp < -0.5){
            f_theta_delta = -0.5;
        }else if(f_temp > 0.5){
            f_theta_delta = 0.5;
        }

    	//����������
    	if(motorVars_M1.flagEnableSpeedCtrl==0){
			f_temp = ReceiveFrame.CANData[4] + (ReceiveFrame.CANData[5]<<8);
			f_temp = f_temp*0.1;
		    id_ref_can= -f_temp;

		    f_temp = ReceiveFrame.CANData[6] + (ReceiveFrame.CANData[7]<<8);
            f_temp = f_temp*0.1;
		    if((debug_cmd.value >> 6) & 0x01){
		        iq_ref_can = -f_temp;
		    }else{
		        iq_ref_can = f_temp;
		    }
    	}else{
    	}

    	u_motor_ctrl.bit.enableCAN  = (debug_cmd.value >> 8) & 0x01;
    	//motorVars_M1.flagEnableRunAndIdentify=u_motor_ctrl.bit.run_enable;
    	//motorVars_M1.speedRef_Hz=vcu_speedCmd;
    	//debug
    	if(((debug_cmd.value >> 9) & 0x01) == 0x01){
            u_speed_can = fabsf(vcu_speedCmd);
            u_sci_enable.bit.can_enable = u_motor_ctrl.bit.enableCAN ;
            u_enable_HandC = u_motor_ctrl.bit.enableCAN;
            CANtest_flg=1;
    	}else{
    	    CANtest_flg=0;
    	}
        //��ѹ������
        if((debug_cmd.value >> 4) & 0x01){
            debug_cmd.resol_zero_adj=1;
            f_temp = ReceiveFrame.CANData[4] + (ReceiveFrame.CANData[5]<<8);
            f_temp = f_temp*0.1;
            vd_ref_can= f_temp;

            f_temp = ReceiveFrame.CANData[6] + (ReceiveFrame.CANData[7]<<8);
            f_temp = f_temp*0.1;
            vq_ref_can= f_temp;
        }else{
            debug_cmd.resol_zero_adj=0;
        }

        J1939_Module.flag_rece1 = 0;
    }
}

#endif

#endif


