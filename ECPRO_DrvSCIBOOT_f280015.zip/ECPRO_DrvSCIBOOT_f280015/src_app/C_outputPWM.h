

#ifndef SRC_APP_C_OUTPUTPWM_H_
#define SRC_APP_C_OUTPUTPWM_H_

#include "f280015x_device.h"

#define    PWMOUT_MODE_NUM      1   //0:MegaS;  1:25-40;

#if XTAL_PLL_FREQ==0 || XTAL_PLL_FREQ==2    //120Mhz
    #define     AO_PWM_PERIOD       50000        //���PWM����,120000000/75/32
#else
    #define     AO_PWM_PERIOD       41666        //���PWM����,100000000/75/32
#endif

#if PWMOUT_MODE_NUM==0
    #define     AO_PWM_PWR_MAX    1200    //W 1500
    #define     AO_PWM_Q_MAX      20.0    //L/MIN
    #define     AO_PWM_H_MAX      20.0    //m
    #define     AO_PWM_SPEED_MAX  3500    //rpm
#else
    #define     AO_PWM_PWR_MAX    1200    //W 1500
    #define     AO_PWM_Q_MAX      20.0    //L/MIN
    #define     AO_PWM_H_MAX      20.0    //m
    #define     AO_PWM_SPEED_MAX  3500    //rpm
#endif

typedef enum
{
    PWR_OUT_STA,
    Q_OUT_STA,
    H_OUT_STA,
    SPEED_OUT_STA
} PWM_OUT_MODE;

#ifdef  SRC_APP_OUTPUTPWM_C_
    #define SRC_APP_OUTPUTPWM
#else
    #define SRC_APP_OUTPUTPWM  extern
#endif


SRC_APP_OUTPUTPWM void outPwm(void);
SRC_APP_OUTPUTPWM void outPwmInit(void);
SRC_APP_OUTPUTPWM uint16_t pwmOutMode;

#endif /* SRC_APP_C_OUTPUTPWM_H_ */
