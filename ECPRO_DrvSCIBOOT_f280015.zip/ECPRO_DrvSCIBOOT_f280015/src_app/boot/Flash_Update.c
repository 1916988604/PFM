
#ifndef CAN_UPDATA_C
#define CAN_UPDATA_C

#include "app_include.h"
#include "Flash_Update.h"

extern volatile MOTOR_Handle motorHandle_M1;

/****************************************************************************************
** �ļ�����:  Cana_Process.c
** ��������:  CAN����
****************************************************************************************/
void Cana_Process(void)
{
    if(CAN_readMessage(myCAN0_BASE, 30, rxMsgData))                /*���յ�����*/
    {
#if controller==0
        if((rxMsgData[0] == 17) && (rxMsgData[1] == 1) && (rxMsgData[2] == 7) && \
           (rxMsgData[3] == 17) && (rxMsgData[4] == 0) && (rxMsgData[5] == 42) && \
           (rxMsgData[6] == 255) && (rxMsgData[7] == 0))
#elif controller==1
        if((rxMsgData[0] == 18) && (rxMsgData[1] == 1) && (rxMsgData[2] == 7) && \
           (rxMsgData[3] == 17) && (rxMsgData[4] == 0) && (rxMsgData[5] == 43) && \
           (rxMsgData[6] == 255) && (rxMsgData[7] == 0))
#elif controller==2
        if((rxMsgData[0] == 19) && (rxMsgData[1] == 1) && (rxMsgData[2] == 7) && \
           (rxMsgData[3] == 17) && (rxMsgData[4] == 0) && (rxMsgData[5] == 44) && \
           (rxMsgData[6] == 255) && (rxMsgData[7] == 0))
#elif controller==3
        if((rxMsgData[0] == 20) && (rxMsgData[1] == 1) && (rxMsgData[2] == 7) && \
           (rxMsgData[3] == 17) && (rxMsgData[4] == 0) && (rxMsgData[5] == 45) && \
           (rxMsgData[6] == 255) && (rxMsgData[7] == 0))
#elif controller==3
        if((rxMsgData[0] == 21) && (rxMsgData[1] == 1) && (rxMsgData[2] == 7) && \
           (rxMsgData[3] == 17) && (rxMsgData[4] == 0) && (rxMsgData[5] == 46) && \
           (rxMsgData[6] == 255) && (rxMsgData[7] == 0)
#else
        if((rxMsgData[0] == 22) && (rxMsgData[1] == 1) && (rxMsgData[2] == 7) && \
           (rxMsgData[3] == 17) && (rxMsgData[4] == 0) && (rxMsgData[5] == 47) && \
           (rxMsgData[6] == 255) && (rxMsgData[7] == 0))
#endif
          {
              //RAM������������CMD�ļ��������䶨�壬����λʱֱ����0�ˣ���0������оƬ��ʼ��������
              (*(uint8 *)0x8000) = 0x38;
              (*(uint8 *)0x8001) = 0xEC;
              (*(uint8 *)0x8002) = 0x55;
              (*(uint8 *)0x8003) = 0xAA;
              (*(uint8 *)0x8004) = 0x33;
              (*(uint8 *)0x8005) = 0x66;
              MOTOR_EN_DISBLE_CTRL;
              DINT;
              // disable the PWM
              HAL_disablePWM(motorHandle_M1->halMtrHandle);
              SysCtl_enableWatchdog();
                while (1)
                {
                   asm(" nop");
                }
          }
    }
}

uint16 CanA_BusoffFlg(void)
{
    return((HWREGH(CANA_BASE + CAN_O_CTL) & CAN_CTL_INIT) ? 1u : 0u);
}

void CanA_Restart(void)
{
    HWREGH(CANA_BASE + CAN_O_CTL) &= ~(CAN_CTL_INIT | CAN_CTL_CCE);
}


#endif
