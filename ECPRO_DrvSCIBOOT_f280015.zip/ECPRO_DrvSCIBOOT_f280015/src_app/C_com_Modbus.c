
//��ʾ�壨����������ư壨�ӻ�����ͨѶ
//����C_RS485Comm�߼�


#ifndef SRC_APP_COM_MODBUS_C_
#define SRC_APP_COM_MODBUS_C_

#define     sci_numeber_Mod      2       //0:scia�� 1:scib; 2:scic
#define     DEBUGHMI_SCI_EN    1    //0:������ 1:debugHMIģʽ

#include "app_include.h"

extern const unsigned int dspBaudRegData[13][3];
volatile struct SCI_REGS *SciRegs;

enum COMM_STATUS commStatus;

// MODBUSЭ��
#define RTUslaveAddress rcvFrame[0]      // RTU֡�Ĵӻ���ַ
#define RTUcmd          rcvFrame[1]      // RTU֡��������
#define RTUhighAddr     rcvFrame[2]      // RTU֡�ĵ�ַ���ֽ�
#define RTUlowAddr      rcvFrame[3]      // RTU֡�ĵ�ַ���ֽ�
#define RTUhighData     rcvFrame[4]      // RTU֡�����ݸ��ֽ�
#define RTUlowData      rcvFrame[5]      // RTU֡�����ݵ��ֽ�
#define RTUlowCrc       rcvFrame[6]      // RTU֡��CRCУ����ֽ�
#define RTUhighCrc      rcvFrame[7]      // RTU֡��CRCУ����ֽ�

Uint16 test0x06_0x10;   //0:0x10; 1:0x06
Uint16 test0x06_address;
extern uint16_t lv_data;
extern uint16_t ov_data;
extern unsigned int leakErr_time;
extern unsigned int leakErr_5stime;

void UpdateSciFormat(void)
{
    //baudrate_sci = 5;
    //mas_sla_sel_sci = SLAVE;
    /*if(e485Mode==1){
        mas_sla_sel_sci = 0;
    }else{
        mas_sla_sel_sci = 1;
    }
    sys_param.Address485;*/

    if(mas_sla_sel_sci != mas_sla_sel){
        mas_sla_sel = mas_sla_sel_sci;
        if(mas_sla_sel == MASTER){
            EALLOW;
            //SCI����Ϊ����ģʽ
            SET_RTS_T;
            SciRegs->SCICTL1.all = 0x0022;  // ����
            SciRegs->SCICTL2.all = 0x00C1;  // ���������ж�
            EDIS;
        }else{
            EALLOW;
            SET_RTS_R;
            SciRegs->SCICTL1.all = 0x0021;  // ����
            SciRegs->SCICTL2.all = 0x0002;  // ���������ж�
            EDIS;
        }
        if(mas_sla_sel == MASTER){
             commRcvData.delay = 120;      //60ms
             commStatus = SCI_SEND_DATA_PREPARE;        // ��Ϊ����״̬
        }else{
             commRcvData.delay = 2;      //1ms
             commStatus = SCI_RECEIVE_DATA;        // ��Ϊ����״̬
         }
    }
    if(baudrate_sci>9){
        baudrate_sci = 9;
    }
    if(baudrate_sci != baudrate){
        baudrate = baudrate_sci;
        EALLOW;
        SciRegs->SCIHBAUD.all = dspBaudRegData[baudrate][1];
        SciRegs->SCILBAUD.all = dspBaudRegData[baudrate][2];
        commRcvData.frameSpaceTime = (Uint16)(385.0*2.0/dspBaudRegData[baudrate][0])+1;   // 3.5 char time=3.5*(1+8+2)/baud
        EDIS;
    }
}


void f_rs485_ComInit()
{
    Uint16 i;
    static Uint16 firstSet=0;

    test0x06_0x10=0;
    test0x06_address=4000;

    if(firstSet==0){
        baudrate_sci = 5;
        mas_sla_sel_sci = SLAVE;
        mas_sla_sel = SLAVE;        //���ӻ����ñ���
        baudrate = 5;       //9600bit/s     //���������ñ���
        firstSet=1;
    }
    for(i=0;i<RTU_WRITE_DATANUM;i++){
        rcvFrameMore[i] = 0;
    }

#if sci_numeber_Mod==0
    SciRegs = &SciaRegs;
#elif sci_numeber_Mod==1
    SciRegs = &ScibRegs;
#else
    SciRegs = &ScicRegs;
#endif

    EALLOW;
    SciRegs->SCICTL1.all = 0;       //SCIϵͳ��λʱ,�ָ���ʼ״̬
    SciRegs->SCICCR.all = 0x0007;   // 1ֹͣλ������żУ��λ����LOOPBACKģʽ��idleѡ��8λ�ַ�
    SciRegs->SCIPRI.bit.FREESOFT = 1;       //����������ʱ��SCI��������
    SciRegs->SCIHBAUD.all = dspBaudRegData[baudrate][1];//2;   //50000000/((0x28a+1)*8) = 50000000/((650+1)*8) = 50000000/5208 = 9600
    SciRegs->SCILBAUD.all = dspBaudRegData[baudrate][2];//0x8A;

    if(mas_sla_sel == MASTER){
        //SCI����Ϊ����ģʽ
        SET_RTS_T;
        SciRegs->SCICTL1.all = 0x0022;  // ����
        SciRegs->SCICTL2.all = 0x00C1;  // ���������ж�
    }else{
        SET_RTS_R;
        SciRegs->SCICTL1.all = 0x0021;  // ����
        SciRegs->SCICTL2.all = 0x0002;  // ���������ж�
    }

#if    MCU_PAKAGE==0    //48pin,scib
        /*GpioCtrlRegs.GPADIR.bit.GPIO12 = 1; //OUTPUT
        GpioCtrlRegs.GPADIR.bit.GPIO13 = 0; //INPUT
        GpioCtrlRegs.GPAPUD.bit.GPIO12 = 0; //0:ENABLE PULLUP;  1:DISABLE PULLUP
        GpioCtrlRegs.GPAPUD.bit.GPIO13 = 0;
        GpioCtrlRegs.GPAQSEL1.bit.GPIO12 = 0;
        GpioCtrlRegs.GPAQSEL1.bit.GPIO13 = 0;
        GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 2;
        GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 2;
        GpioCtrlRegs.GPAGMUX1.bit.GPIO12 = 1;
        GpioCtrlRegs.GPAGMUX1.bit.GPIO13 = 1;

        GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 0;
        GpioCtrlRegs.GPAQSEL2.bit.GPIO28 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO28 = 0;
        GpioDataRegs.GPADAT.bit.GPIO28 = 0;   //DE: 0--receiver;1--transmit
        GpioCtrlRegs.GPADIR.bit.GPIO28 = 1;   //output

        PieVectTable.SCIB_TX_INT =  &SCI_TXD_isr;
        PieVectTable.SCIB_RX_INT =  &SCI_RXD_isr;

        PieCtrlRegs.PIEIER9.bit.INTx3 = 1;
        PieCtrlRegs.PIEIER9.bit.INTx4 = 1;
        IER |= M_INT9;                  //  Enable interrupts:*/

        PieVectTable.SCIC_TX_INT =  &SCI_TXD_isr;
        PieVectTable.SCIC_RX_INT =  &SCI_RXD_isr;

        IER |= M_INT8;                  //  Enable interrupts:
        PieCtrlRegs.PIEIER8.bit.INTx5 = 1;
        PieCtrlRegs.PIEIER8.bit.INTx6 = 1;

#else   //80PIN
    #if sci_numeber_Mod==0 //scia
        GpioCtrlRegs.GPAPUD.bit.GPIO16 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO17 = 0;
        GpioCtrlRegs.GPAQSEL2.bit.GPIO16 = 0;
        GpioCtrlRegs.GPAQSEL2.bit.GPIO17 = 0;
        GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 2;
        GpioCtrlRegs.GPAMUX2.bit.GPIO17 = 2;
        GpioCtrlRegs.GPAGMUX2.bit.GPIO16 = 1;
        GpioCtrlRegs.GPAGMUX2.bit.GPIO17 = 1;

        // ͨѶ����ʹ���жϣ���ʼ��
        PieVectTable.SCIA_TX_INT =  &SCI_TXD_isr;
        PieVectTable.SCIA_RX_INT =  &SCI_RXD_isr;

        PieCtrlRegs.PIEIER9.bit.INTx1 = 1;
        PieCtrlRegs.PIEIER9.bit.INTx2 = 1;
        IER |= M_INT9;                  //  Enable interrupts:
    #elif sci_numeber_Mod==1
        //Scib
        GpioCtrlRegs.GPADIR.bit.GPIO14 = 1;
        GpioCtrlRegs.GPADIR.bit.GPIO15 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO14 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO15 = 0;
        GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = 0;
        GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = 0;
        GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 2;    //SCITXA
        GpioCtrlRegs.GPAMUX1.bit.GPIO15 = 2;    //SCIRXA
        GpioCtrlRegs.GPAGMUX1.bit.GPIO14 = 0;
        GpioCtrlRegs.GPAGMUX1.bit.GPIO15 = 0;

        PieVectTable.SCIB_TX_INT =  &SCI_TXD_isr;
        PieVectTable.SCIB_RX_INT =  &SCI_RXD_isr;

        PieCtrlRegs.PIEIER9.bit.INTx3 = 1;
        PieCtrlRegs.PIEIER9.bit.INTx4 = 1;
        IER |= M_INT9;                  //  Enable interrupts:
    #else
        //Scic
        GpioCtrlRegs.GPBPUD.bit.GPIO42 = 0;
        GpioCtrlRegs.GPBPUD.bit.GPIO43 = 0;
        GpioCtrlRegs.GPBQSEL1.bit.GPIO42 = 0;
        GpioCtrlRegs.GPBQSEL1.bit.GPIO43 = 0;
        GpioCtrlRegs.GPBMUX1.bit.GPIO42 = 3;    //SCITXA
        GpioCtrlRegs.GPBMUX1.bit.GPIO43 = 3;    //SCIRXA
        GpioCtrlRegs.GPBGMUX1.bit.GPIO42 = 1;
        GpioCtrlRegs.GPBGMUX1.bit.GPIO43 = 1;

        PieVectTable.SCIC_TX_INT =  &SCI_TXD_isr;
        PieVectTable.SCIC_RX_INT =  &SCI_RXD_isr;

        IER |= M_INT8;                  //  Enable interrupts:
        PieCtrlRegs.PIEIER8.bit.INTx5 = 1;
        PieCtrlRegs.PIEIER8.bit.INTx6 = 1;
    #endif
#endif

    EDIS;
    commRcvData.rcvFlag = 0;
    commRcvData.rcvNum = 0;
    commRcvData.slaveAddr = 0;
    commRcvData.slaveDddr = 0;
    commRcvData.commAddr = 0;
    commRcvData.commCmd = 0;
    commRcvData.rcvDataJuageFlag = 0;
    commRcvData.moreWriteNum = 0;
    commRcvData.rcvNumMax = 8;      // ��ʼ�����ճ��ȣ�ʵ�ʳ������ж��ж�
    commRcvData.frameSpaceTime = (Uint16)(385.0*2.0/dspBaudRegData[baudrate][0])+1;   // 3.5 char time=3.5*(1+8+2)/baud
    //commRcvData.frameSpaceTime = 385 * 2 / 96+ 1;        // 3.5 char time=3.5*(1+8+2)/baud
   if(mas_sla_sel == MASTER){
        commRcvData.delay = 2;      //1ms
        commStatus = SCI_SEND_DATA_PREPARE;        // ��Ϊ����״̬
   }else{
        commRcvData.delay = 2;      //1ms
        commStatus = SCI_RECEIVE_DATA;        // ��Ϊ����״̬
    }
}



void CommWrite(void)
{
    Uint16 temp;
    //����ʱ��0x10�������ݴ��
    temp = sci_motor_spdCmd;        //0x4000
    sendFrame[7] = temp>>8;
    sendFrame[8] = temp&0x0ff;
    temp = sci_motor_GearCmd;       //0x4001
    sendFrame[9] = temp>>8;
    sendFrame[10] = temp&0x0ff;
    temp = 0x10;
    sendFrame[11] = temp>>8;
    sendFrame[12] = temp&0x0ff;
    temp = 0x20;
    sendFrame[13] = temp>>8;
    sendFrame[14] = temp&0x0ff;
    temp = 0x30;
    sendFrame[15] = temp>>8;
    sendFrame[16] = temp&0x0ff;
    temp = 0x40;
    sendFrame[17] = temp>>8;
    sendFrame[18] = temp&0x0ff;
    temp = 0x50;
    sendFrame[19] = temp>>8;
    sendFrame[20] = temp&0x0ff;
    temp = 0x60;
    sendFrame[21] = temp>>8;
    sendFrame[22] = temp&0x0ff;
    temp = 0x70;
    sendFrame[23] = temp>>8;
    sendFrame[24] = temp&0x0ff;
    temp = 0x80;
    sendFrame[25] = temp>>8;
    sendFrame[26] = temp&0x0ff;
    temp = 0x90;
    sendFrame[27] = temp>>8;
    sendFrame[28] = temp&0x0ff;
    temp = 0x91;
    sendFrame[29] = temp>>8;
    sendFrame[30] = temp&0x0ff;
    temp = 0x92;
    sendFrame[31] = temp>>8;
    sendFrame[32] = temp&0x0ff;
    temp = 0x93;
    sendFrame[33] = temp>>8;
    sendFrame[34] = temp&0x0ff;
    temp = 0x94;
    sendFrame[35] = temp>>8;
    sendFrame[36] = temp&0x0ff;
    temp = 0x95;
    sendFrame[37] = temp>>8;
    sendFrame[38] = temp&0x0ff;
    temp = 0x96;
    sendFrame[39] = temp>>8;
    sendFrame[40] = temp&0x0ff;
    temp = 0x97;
    sendFrame[41] = temp>>8;
    sendFrame[42] = temp&0x0ff;
    temp = 0x98;
    sendFrame[43] = temp>>8;
    sendFrame[44] = temp&0x0ff;
    temp = 0x99;
    sendFrame[45] = temp>>8;
    sendFrame[46] = temp&0x0ff;
    temp = 0x9a;
    sendFrame[47] = temp>>8;
    sendFrame[48] = temp&0x0ff;
    temp = 0x9b;
    sendFrame[49] = temp>>8;
    sendFrame[50] = temp&0x0ff;
    temp = 0x9c;
    sendFrame[51] = temp>>8;
    sendFrame[52] = temp&0x0ff;
    temp = 0x9d;
    sendFrame[53] = temp>>8;
    sendFrame[54] = temp&0x0ff;
    temp = 0x9e;
    sendFrame[55] = temp>>8;
    sendFrame[56] = temp&0x0ff;
    temp = 0x9f;
    sendFrame[57] = temp>>8;
    sendFrame[58] = temp&0x0ff;
    temp = 0xa0;
    sendFrame[59] = temp>>8;
    sendFrame[60] = temp&0x0ff;
    temp = 0xa1;
    sendFrame[61] = temp>>8;
    sendFrame[62] = temp&0x0ff;
    temp = 0xa2;
    sendFrame[63] = temp>>8;
    sendFrame[64] = temp&0x0ff;
    temp = 0xa3;
    sendFrame[65] = temp>>8;
    sendFrame[66] = temp&0x0ff;
    temp = 0xa4;
    sendFrame[67] = temp>>8;
    sendFrame[68] = temp&0x0ff;
}

/************************************************************************
//�ӻ�ʱ�����������ȡ�����ݣ�rcvFrameMore[0]--0x5000
****************************************************************************/
void CommWriteBack(void)
{
    Uint16  uIntTemp;
    float   f_temp;
#if    DEBUGHMI_SCI_EN==1
    u_motor_ctrl.bit.enableCAN = rcvFrameMore[1] & 0x01;     //����ʹ��;

    //sys_param.errRstEn = rcvFrameMore[1] & 0x01;
    motorVars_M1.flagEnableForceAngle = (rcvFrameMore[6] >> 1) & 0x01;
    motorVars_M1.flagEnableRsRecalc = (rcvFrameMore[6] >> 2) & 0x01;
    motorVars_M1.flagEnableFWC = (rcvFrameMore[6] >> 3) & 0x01;
    motorVars_M1.flagEnableSpeedCtrl = (rcvFrameMore[6] >> 7) & 0x01;
    uIntTemp = rcvFrameMore[0];
    //f_temp = f_temp*0.016666 * USER_MOTOR1_NUM_POLE_PAIRS;   //speed to freq; //userParams_M1.motor_numPolePairs;
    if((rcvFrameMore[6] >> 6) & 0x01){
        vcu_speedDirCmd = -1;
    }else{
        vcu_speedDirCmd = 1;
    }
    vcu_speedCmd = uIntTemp;

    if(motorVars_M1.flagEnableSpeedCtrl==0){
         f_temp = rcvFrameMore[4];
         f_temp = f_temp*0.1;
         id_ref_can= -f_temp;

         f_temp = rcvFrameMore[5];
         f_temp = f_temp*0.1;
         if(vcu_speedDirCmd==1){
             iq_ref_can = -f_temp;
         }else{
             iq_ref_can = f_temp;
         }
     }else{
     }
    if(((rcvFrameMore[6] >> 11) & 0x03) == 0x01){
        u_speed_can = vcu_speedCmd;
        u_sci_enable.bit.can_enable = u_motor_ctrl.bit.enableCAN ;
        u_enable_HandC = u_motor_ctrl.bit.enableCAN;
        CANtest_flg=1;
    }else{
        CANtest_flg=0;
    }

    debug_cmd.debugEn = (rcvFrameMore[6]>>8) & 0x01;
    debug_cmd.Relay1En = (rcvFrameMore[6]>>9) & 0x01;
    debug_cmd.Relay2En = (rcvFrameMore[6]>>10) & 0x01;

#else
    u_speed_e485 = rcvFrameMore[0];
    u_sci_enable.bit.e485_enable = rcvFrameMore[1] & 0x01;
    u_sci_enable.bit.e485_errRst = (rcvFrameMore[1]>>1) & 0x01;
#endif
}

//�ӻ�ʱ��0x03�������ݴ��
void CommRead(void)
{
    Uint16  uIntTemp;
    long    Int_temp;
    float   f_temp;
    static float   isSCIBak=0;

#if    DEBUGHMI_SCI_EN==1
    sci_motor_spd = (int16)motorSpd;
    f_temp = motorVars_M1.adcData.VdcBus_V;
    sci_motor_udcVol =(Uint16)(f_temp);
    f_temp = Temp_IGBT.V_LN_Lpf;       //�ߵ�ѹ
    sci_motor_gridVol = (Uint16)(f_temp);
    sci_motor_igbtT = (int16)(Temp_IGBT.igbtTemp*10);

    sci_motor_fault = u_fault_sta.all;
    if(u_fault_sta.all != 0){
        sci_motor_runFlg=3;
    }else if(motorVars_M1.flagEnableRunAndIdentify){
        sci_motor_runFlg=1;
    }else{
        sci_motor_runFlg=0;
    }
    sci_motor_power = (Uint16)(motorPwr_f*10);
    sci_motor_Hauto = HD_HEAD_INIT;
    sci_motor_CHmax = HD_HEAD_MAX;
    sci_motor_CHmin = HD_HEAD_MIN;

    sci_motor_ntcT = (int)(s16_temper_medium*10);
    sci_motor_lift = u16_press/10;
#else
    sci_motor_ntcT = (int)(temperature*10);
    commReadData[10]=sci_motor_ntcT;
    sci_motor_ntcT = (int)(tempeMediumEx*10);
    commReadData[11]=sci_motor_ntcT;
#endif
    commReadData[0]=sci_motor_spd;      //0x5000
    commReadData[1]=sci_motor_udcVol;
    commReadData[2]=sci_motor_gridVol;
    commReadData[3]=sci_motor_igbtT;
    commReadData[4]=sci_motor_fault;
    commReadData[5]=sci_motor_runFlg + (modeNightFlg<<2) + (sci_motor_pwrLmtFlg<<3) + (sys_param.mode<<7);
    commReadData[6]=sci_motor_flow;  //��е��������
    commReadData[7]=sci_motor_lift;
    commReadData[8]=sci_motor_power;
    commReadData[9]=sci_motor_Hauto;//sci_motor_heat;
    commReadData[10]=sci_motor_ntcT;
    sci_motor_ntcT = (int)(tempeMediumEx*10);
    commReadData[11]=sci_motor_ntcT;
    commReadData[12]=sci_motor_Hmax;//u_speed_can;//
    commReadData[13]=sci_motor_Hmin;//iq_ref_can;//debug_cmd.debugEn +(debug_cmd.Relay1En<<1)+(debug_cmd.Relay2En<<2)+(CANtest_flg<<3);//
    commReadData[14]=sci_motor_CHmax;
    commReadData[15]=sci_motor_CHmin;
    commReadData[16]=PUMP_VER_NUMBER;
    commReadData[17]=SW_VER_NUMBER;
    f_temp = motorVars_M1.Vs_V;//motorSetVars_M1.overModulation;
    f_temp = f_temp/motorVars_M1.adcData.VdcBus_V;
    Int_temp = (int16)(f_temp*1000);
    commReadData[18]=Int_temp;
    f_temp = id_ref_f;
    f_temp = f_temp*100;
    Int_temp = (int16)f_temp;
    commReadData[19]=Int_temp;
    f_temp = iq_ref_f;
    f_temp = f_temp*100;
    Int_temp = (int16)f_temp;
    commReadData[20]=Int_temp;
    f_temp = id_fbk_f;
    f_temp = f_temp*100;
    Int_temp = (int16)f_temp;
    commReadData[21]=Int_temp;
    f_temp = iq_fbk_f;
    f_temp = f_temp*100;
    Int_temp = (int16)f_temp;
    commReadData[22]=Int_temp;
    f_temp = vd_fbk_f;
    Int_temp = (int16)(f_temp*10);
    commReadData[23]=Int_temp;
    f_temp = vq_fbk_f;
    Int_temp = (int16)(f_temp*10);
    commReadData[24]=Int_temp;
    f_temp = motorSetVars_M1.Kp_spd;
    uIntTemp = (int16)(f_temp*10000);
    commReadData[25]=uIntTemp;
    f_temp =  motorSetVars_M1.Ki_spd;
    uIntTemp = (int16)(f_temp*10000);
    commReadData[26]=uIntTemp;
    f_temp = motorSetVars_M1.Kp_Id;
    uIntTemp = (int16)(f_temp*10000);
    commReadData[27]=uIntTemp;
    f_temp = motorSetVars_M1.Ki_Id;
    uIntTemp = (int16)(f_temp*10000);
    commReadData[28]=uIntTemp;
    f_temp = motorSetVars_M1.Kp_Iq;
    f_temp = leakErr_time;// й¶������
    f_temp = f_temp/10000;
    uIntTemp = (int16)(f_temp*10000);
    commReadData[29]=uIntTemp;
    f_temp = motorSetVars_M1.Ki_Iq;
    f_temp = leakErr_5stime;
    f_temp = f_temp/10000;
    uIntTemp = (int16)(f_temp*10000);
    commReadData[30]=uIntTemp;
    uIntTemp = ((Uint16)(motorSetVars_M1.Rs_Ohm *50))&0x0FF + ((((Uint16)(motorSetVars_M1.RsOnLine_Ohm * 50))&0x0FF)*256);
    commReadData[31]=uIntTemp;
    uIntTemp = ((Uint16)(motorSetVars_M1.Rr_Ohm *50))&0x0FF + ((((Uint16)(motorSetVars_M1.flux_Wb * 50))&0x0FF)*256);
    commReadData[32]=uIntTemp;
    uIntTemp = ((Uint16)(motorSetVars_M1.Ls_d_H  * 10000))&0x0FF + ((((Uint16)(motorSetVars_M1.Ls_q_H * 10000))&0x0FF)*256);
    commReadData[33]=uIntTemp;
    uIntTemp = userParams_M1.motor_numPolePairs+(motorVars_M1.trajState<<8) + (motorVars_M1.estState<<12);
    commReadData[34]=uIntTemp;
    f_temp = motorVars_M1.Is_A;
    f_temp = f_temp*100;
    f_temp = fabsf(isSCIBak*0.9) + fabsf(f_temp*(0.1));
    isSCIBak = f_temp;
    Int_temp = (int16)f_temp;
    commReadData[35]=Int_temp;
    commReadData[36]=lv_data;
    commReadData[37]=ov_data;
    commReadData[38]=(Uint16)(powerLmt.Max);
    commReadData[39]=boot_ver;
    commReadData[40]=u_fault_sta.all>>16;
    commReadData[41]=u16_display_ver;   //

    f_temp = motorVars_M1.adcData.offset_V_sf.value[0]*10;
    Int_temp = (int16)f_temp;
    commReadData[42]=Int_temp;
    f_temp = motorVars_M1.adcData.offset_V_sf.value[1]*10;
    Int_temp = (int16)f_temp;
    commReadData[43]=Int_temp;
    f_temp = motorVars_M1.adcData.offset_V_sf.value[2]*10;
    Int_temp = (int16)f_temp;
    commReadData[44]=Int_temp;
    f_temp = motorVars_M1.adcData.offset_I_ad.value[0];
    Int_temp = (int16)f_temp;
    commReadData[45]=Int_temp;
    f_temp = motorVars_M1.adcData.offset_I_ad.value[1];
    Int_temp = (int16)f_temp;
    commReadData[46]=Int_temp;
    f_temp = motorVars_M1.adcData.offset_I_ad.value[2];
    Int_temp = (int16)f_temp;
    commReadData[47]=Int_temp;
    f_temp = motorVars_M1.adcData.V_V.value[0];
    Int_temp = (int16)(f_temp*10);
    commReadData[48]=Int_temp;
    f_temp = motorVars_M1.adcData.V_V.value[1];
    Int_temp = (int16)(f_temp*10);
    commReadData[49]=Int_temp;
    f_temp = motorVars_M1.adcData.V_V.value[2];
    Int_temp = (int16)(f_temp*10);
    commReadData[50]=Int_temp;
    f_temp = motorVars_M1.adcData.I_A.value[0];
    Int_temp = (int16)(f_temp*10);
    commReadData[51]=Int_temp;
    f_temp = motorVars_M1.adcData.I_A.value[1];
    Int_temp = (int16)(f_temp*10);
    commReadData[52]=Int_temp;
    f_temp = motorVars_M1.adcData.I_A.value[2];
    Int_temp = (int16)(f_temp*10);
    commReadData[53]=Int_temp;
    commReadData[54]=0;

}


//====================================================================
// ���ݽ��պ���Ϣ����
//====================================================================
void ModbusRcvDataDeal(void)
{

    if(mas_sla_sel == MASTER){
        if(RTUcmd == SCI_CMD_READ){
            commRcvData.slaveAddr = RTUslaveAddress;                // �ӻ���ַ
            commRcvData.commCmd = RTUcmd;                           // ͨѶ����
            commRcvData.commAddr = RTU_READ_ADDRESS; // ������ַ
            commRcvData.commData = rcvFrame[2] ; // ��������
            commRcvData.crcRcv = (rcvFrame[commRcvData.commData+4] <<8)+rcvFrame[commRcvData.commData+3]; // ��������;     // CRCУ��ֵ
            commRcvData.crcSize = commRcvData.commData + 3;                                // CRCУ�鳤��
            commRcvData.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����
        }else{
            commRcvData.slaveAddr = RTUslaveAddress;                // �ӻ���ַ
            commRcvData.commCmd = RTUcmd;                           // ͨѶ����
            commRcvData.commAddr = (RTUhighAddr << 8) + RTUlowAddr; // ������ַ
            commRcvData.commData = (RTUhighData << 8) + RTUlowData; // ��������
            commRcvData.crcRcv = (RTUhighCrc << 8) + RTUlowCrc;     // CRCУ��ֵ
            commRcvData.crcSize = 6;                                // CRCУ�鳤��
            commRcvData.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����
        }
    }else{
        if(RTUcmd == SCI_CMD_WRITE_MORE){
            commRcvData.slaveAddr = RTUslaveAddress;                // �ӻ���ַ
            commRcvData.commCmd = RTUcmd;                           // ͨѶ����
            commRcvData.commAddr = (RTUhighAddr << 8) + RTUlowAddr; // ������ʼ��ַ
            commRcvData.commData = (RTUhighData << 8) + RTUlowData; // �����Ĵ���������

            commRcvData.moreWriteNum = rcvFrame[6];                 // �ֽ���

            commRcvData.crcSize = commRcvData.moreWriteNum + 7; // CRCУ�鳤��
            commRcvData.crcRcv = (rcvFrame[commRcvData.crcSize+1] << 8) + rcvFrame[commRcvData.crcSize];     // CRCУ��ֵ
            commRcvData.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����
        }else{
            commRcvData.slaveAddr = RTUslaveAddress;                // �ӻ���ַ
            commRcvData.commCmd = RTUcmd;                           // ͨѶ����
            commRcvData.commAddr = (RTUhighAddr << 8) + RTUlowAddr; // ������ַ
            commRcvData.commData = (RTUhighData << 8) + RTUlowData; // ��������
            commRcvData.crcRcv = (RTUhighCrc << 8) + RTUlowCrc;     // CRCУ��ֵ
            commRcvData.crcSize = 6;                                // CRCУ�鳤��
            commRcvData.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����
        }
    }

#if 0
#if    test_sendFlg_Mod==0
    if(RTUcmd == SCI_CMD_READ)
#else
        if(RTUcmd == SCI_CMD_WRITE_MORE)
#endif
    {
#if    test_sendFlg_Mod==0
            commRcvData.slaveAddr = RTUslaveAddress;                // �ӻ���ַ
            commRcvData.commCmd = RTUcmd;                           // ͨѶ����
            commRcvData.commAddr = RTU_READ_ADDRESS; // ������ַ
            commRcvData.commData = rcvFrame[2] ; // ��������
            commRcvData.crcRcv = (rcvFrame[commRcvData.commData+4] <<8)+rcvFrame[commRcvData.commData+3]; // ��������;     // CRCУ��ֵ
            commRcvData.crcSize = commRcvData.commData + 3;                                // CRCУ�鳤��
            commRcvData.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����

#else
        commRcvData.slaveAddr = RTUslaveAddress;                // �ӻ���ַ
        commRcvData.commCmd = RTUcmd;                           // ͨѶ����
        commRcvData.commAddr = (RTUhighAddr << 8) + RTUlowAddr; // ������ʼ��ַ
        commRcvData.commData = (RTUhighData << 8) + RTUlowData; // �����Ĵ���������

        commRcvData.moreWriteNum = rcvFrame[6];                 // �ֽ���

        commRcvData.crcSize = commRcvData.moreWriteNum + 7; // CRCУ�鳤��
        commRcvData.crcRcv = (rcvFrame[commRcvData.crcSize+1] << 8) + rcvFrame[commRcvData.crcSize];     // CRCУ��ֵ
        commRcvData.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����
#endif
    }
    else
    {
        commRcvData.slaveAddr = RTUslaveAddress;                // �ӻ���ַ
        commRcvData.commCmd = RTUcmd;                           // ͨѶ����
        commRcvData.commAddr = (RTUhighAddr << 8) + RTUlowAddr; // ������ַ
        commRcvData.commData = (RTUhighData << 8) + RTUlowData; // ��������
        commRcvData.crcRcv = (RTUhighCrc << 8) + RTUlowCrc;     // CRCУ��ֵ
        commRcvData.crcSize = 6;                                // CRCУ�鳤��
        commRcvData.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����
    }
#endif
}

//=====================================================================
// ͨѶ���յ����ݴ�������
//=====================================================================
void CommRcvDataDeal(void)
{
    Uint16 writeErr=0,readErr=0;
    Uint16 i,j;
    long u32_temp;
    Uint16 comCrc=0;

    // ��ͬЭ��Ľ���������Ϣ����
    // �������������ַ�����ݵ���Ϣ
    ModbusRcvDataDeal();
    // ��SCI��־
    sciFlag.all = 0;

    comCrc = CrcValueByteCalc(rcvFrame, commRcvData.crcSize);
    // CRCУ��
    if (commRcvData.crcRcv != comCrc)  // CRCУ������ж�
    {
        sciFlag.bit.crcChkErr = 1;                      // ��λ��CRCErr��send
        commRcvData.rcvCrcErrCounter++;                 // ��¼CRCУ���������
    }
     // �㲥ģʽ
    else if (!commRcvData.slaveAddr)
    {
        // �㲥д����
        if ((SCI_CMD_WRITE == commRcvData.commCmd)
          || (SCI_CMD_WRITE_MORE == commRcvData.commCmd)
           )
        {
            // ��д��־
            sciFlag.bit.write = 1;
        }
        else
        {
            sciFlag.bit.cmdErr = 1;                                                 // �������
        }
    }
    else if (commRcvData.slaveAddr == SCI_SLAVE_ADDRESS) // ������ַ�ж�
    {
        if (SCI_CMD_READ == commRcvData.commCmd)       // ���������
        {
            sciFlag.bit.read = 1;                           // ��λ��read��send
        }
        else if ((SCI_CMD_WRITE == commRcvData.commCmd)
                || (SCI_CMD_WRITE_MORE == commRcvData.commCmd))      // д�������
        {
            sciFlag.bit.write = 1;
        }
        else
        {
            sciFlag.bit.cmdErr = 1;                                                 // �������
        }
    }


    if(mas_sla_sel == MASTER){
        if (sciFlag.bit.read){
            if(commRcvData.commData > (RTU_READ_DATANUM*2)){
                readErr = COMM_ERR_ADDR;
            }else{
                j =0;
                for(i=0;i<(commRcvData.commData>>1);i++)
                {
                    rcvFrameMore[j] = (rcvFrame[3+i*2]<<8) + rcvFrame[4+i*2];       //������ȡ�ӻ����͵�����
                    j++;
                }
            }

            if (readErr){
                sciFlag.bit.paraOver = 1;
            }
        }

        if (sciFlag.bit.write){
            if((SCI_CMD_WRITE == commRcvData.commCmd)){
                if(commRcvData.commAddr < RTU_WRITE_ADDRESS){
                    writeErr = COMM_ERR_ADDR;
                }else if(commRcvData.commAddr > (RTU_WRITE_ADDRESS+RTU_WRITE_DATANUM-1)){
                    writeErr = COMM_ERR_ADDR;
                }
            }else{
                u32_temp = commRcvData.commAddr + commRcvData.commData-1;
                if(commRcvData.commData > RTU_WRITE_DATANUM){
                    writeErr = COMM_ERR_ADDR;
                }else if(commRcvData.commAddr < RTU_WRITE_ADDRESS){
                    writeErr = COMM_ERR_ADDR;
                }else if(u32_temp > (RTU_WRITE_ADDRESS+RTU_WRITE_DATANUM-1)){
                    writeErr = COMM_ERR_ADDR;
                }
            }
            if (writeErr){
               sciFlag.bit.paraOver = 1;
            }
        }
    }else{      //�ӻ�
        if (sciFlag.bit.read)
        {
            u32_temp = commRcvData.commAddr + commRcvData.commData-1;
            if(commRcvData.commData > RTU_READ_DATANUM){
                readErr = COMM_ERR_ADDR;
            }else if(commRcvData.commAddr < RTU_READ_ADDRESS){
                readErr = COMM_ERR_ADDR;
            }else if(u32_temp>(RTU_READ_ADDRESS+RTU_READ_DATANUM-1)){
                readErr = COMM_ERR_ADDR;
            }else{
                CommRead();
            }
            if (readErr){
                sciFlag.bit.paraOver = 1;
            }
        }
        // д���ݴ���
        if (sciFlag.bit.write)
        {
            if(SCI_CMD_WRITE_MORE == commRcvData.commCmd)
            {
                u32_temp = commRcvData.commAddr + commRcvData.commData-1;
                if(((commRcvData.commData*2) != commRcvData.moreWriteNum)
                    ||(commRcvData.commData > RTU_WRITE_DATANUM))
                {
                    writeErr = COMM_ERR_ADDR;
                }else if(commRcvData.commAddr < RTU_WRITE_ADDRESS){
                    writeErr = COMM_ERR_ADDR;
                }else if(u32_temp > (RTU_WRITE_ADDRESS + RTU_WRITE_DATANUM - 1) ){
                    writeErr = COMM_ERR_ADDR;
                }
                else
                {
                    j = commRcvData.commAddr;
                    j = j - RTU_WRITE_ADDRESS;
                    if(j > (RTU_WRITE_DATANUM - 1)){
                        writeErr = COMM_ERR_ADDR;
                    }else{
                        for(i=0;i<commRcvData.moreWriteNum;i++)
                        {
                            rcvFrameMore[j] = (rcvFrame[7+i]<<8) + rcvFrame[8+i];
                            i++;
                            j++;
                        }
                    }
                }
            }else if(SCI_CMD_WRITE == commRcvData.commCmd){
                j = commRcvData.commAddr;
                j = j - RTU_WRITE_ADDRESS;
                if(j > (RTU_WRITE_DATANUM - 1)){
                   writeErr = COMM_ERR_ADDR;
                }else{
                    rcvFrameMore[j] = (rcvFrame[4]<<8) + rcvFrame[5];
                }
            }
            else
            {
                writeErr = COMM_ERR_ADDR;
            }
            // дʧ��
            if (writeErr)
            {
                // ��ʾдʧ�ܹ���
                sciFlag.bit.paraOver = 1;
            }else{
                CommWriteBack();
            }
        }
    }
}


interrupt void SCI_RXD_isr(void)
{
    // ���ݽ���֡ͷ�ж�
    Uint16 tmp;
    Uint16 tmp1;
    tmp = SciRegs->SCIRXBUF.all;
    tmp1 = ModbusStartDeal(tmp);
    if (tmp1)
    {
        // Ϊ�����Ľ�������  0-��Ч   1-�㲥��ַ    2-������ַ
        if (commRcvData.rcvFlag)
        {
            // ��֡ͷͨѶ���ݽ���
            CommDataReRcv(tmp);
        }
    }

    commTicker = 0;                     // �н������ݣ����¼�ʱ
#if sci_numeber_Mod==2
    PieCtrlRegs.PIEACK.bit.ACK8 = 1;    // Issue PIE ACK
#else
    PieCtrlRegs.PIEACK.bit.ACK9 = 1;    // Issue PIE ACK
#endif
}

interrupt void SCI_TXD_isr(void)
{
    // ͨѶ��������
     // ����һ֡����û�����
   if (commSendData.sendNum< commSendData.sendNumMax)
   {
       SciRegs->SCITXBUF.all = sendFrame[commSendData.sendNum++];
   }
    // ����һ֡����ȫ�����
   else if (commSendData.sendNum >= commSendData.sendNumMax)
   {
        // ��־�����������
       commStatus = SCI_SEND_OK;
       commSendTicker = 0;
   }
   commTicker = 0;                     // ����һ���ַ���ɣ����¼�ʱ
#if sci_numeber_Mod==2
    PieCtrlRegs.PIEACK.bit.ACK8 = 1;    // Issue PIE ACK
#else
    PieCtrlRegs.PIEACK.bit.ACK9 = 1;    // Issue PIE ACK
#endif
}

//====================================================================
// MODBUS֡ͷ�ж�
// ����: tmp-����֡����
// ����: 0-֡ͷ�жϹ�����
//       1-����Ҫ֡ͷ�жϣ�ֱ�Ӵ洢��������
//===================================================================
Uint16 ModbusStartDeal(Uint16 tmp)
{
    if (commTicker >= 4000)                                     // 2sʱ��
    {
        commRcvData.rcvDataJuageFlag = 0;                       // ��ʱ��û�����꣬֡ͷ�жϸ�λ
    }

    if ((commTicker > commRcvData.frameSpaceTime))              // ����3.5���ַ�ʱ�䣬�µ�һ֡�Ŀ�ʼ
    {
        RTUslaveAddress = tmp;
        // �㲥ģʽ
        if (RTUslaveAddress == 0)
        {
            commRcvData.rcvNum = 1;
            commRcvData.rcvFlag = 1;                           // ���յ�֡�ĵ�һ���ֽڣ����ǹ㲥ģʽ
        }
        else if (RTUslaveAddress == SCI_SLAVE_ADDRESS)
        {
            commRcvData.rcvNum = 1;
            commRcvData.rcvFlag = 2;
        }
        /****��������*********************************************/
        else if (RTUslaveAddress == TM_ID)
        {
            commRcvData.rcvNum = 1;
            commRcvData.rcvFlag = 2;
        }
        /***************************************************/
        else                                                   // ������ַ
        {
            commRcvData.rcvFlag = 0;                        // ��ַ����Ӧ�����ݲ�����
        }

        return 0;
    }

    return 1;
}

void CommDataReRcv(Uint16 tmp)
{
    if (commRcvData.rcvNum < commRcvData.rcvNumMax)  // ����һ֡���ݻ�û�����
    {
        rcvFrame[commRcvData.rcvNum] = tmp;
    }
    commRcvData.rcvNum++;

    if((rcvFrame[1] ==SCI_CMD_READ)
        ||(rcvFrame[1] ==SCI_CMD_WRITE)
        ||(rcvFrame[1] ==SCI_CMD_WRITE_MORE))
    {
        commRcvData.dpOrModbus = 2; //  2:modbus
        commRcvData.rcvNumMax = 8;
        // 01 10 f0 08 00 02 04
        if(mas_sla_sel == MASTER){
            //����
            //01 03 04 00 00 00 00 CRCL CRCH
            if((rcvFrame[1] ==SCI_CMD_READ)&&(commRcvData.rcvNum>=8))
            {
                commRcvData.rcvNumMax = rcvFrame[2] + 5;
            }
        }else{
            //�ӻ�
            if((rcvFrame[1] ==SCI_CMD_WRITE_MORE)&&(commRcvData.rcvNum>=8))
            {
                commRcvData.rcvNumMax = rcvFrame[6] + 9;
            }
        }
    }
/**************************************************************************/
    else if((rcvFrame[0] ==TM_ID)&&(rcvFrame[1] ==0x01)){      //��������
        commRcvData.dpOrModbus = 2; //  2:modbus
        commRcvData.rcvNumMax = 8;
        if((rcvFrame[1] ==0x01) && (rcvFrame[2] ==0x07) && (rcvFrame[3] ==0x11) && \
           (rcvFrame[4] ==0x00) && (rcvFrame[6] ==0xff) && (rcvFrame[7] ==0x00) && \
           (rcvFrame[5] == (42+TM_ID-17)))
        {
            //RAM������������CMD�ļ��������䶨�壬����λʱֱ����0�ˣ���0������оƬ��ʼ��������
            (*(uint8 *)0x8000) = 0x38;
            (*(uint8 *)0x8001) = 0xEC;
            (*(uint8 *)0x8002) = 0x55;
            (*(uint8 *)0x8003) = 0xAA;
            (*(uint8 *)0x8004) = 0x33;
            (*(uint8 *)0x8005) = 0x66;
            MOTOR_EN_DISBLE_CTRL;
            DINT;
            // disable the PWM
            HAL_disablePWM(motorHandle_M1->halMtrHandle);
            SysCtl_enableWatchdog();
              while (1)
              {
                 asm(" nop");
              }
        }
    }
/**************************************************************************/
    if (commRcvData.rcvNum == commRcvData.rcvNumMax)  //���ո�������
    {
        commStatus = SCI_RCVFIN_WAIT;   //��־���ս����ȴ�
    }
}


void CommSendDataDeal(void)
{
    Uint16 temp;
    static Uint16 wr_cnt_flg_Mod=0;
    Uint16 crcSend;
    Uint16 sendNum;
    Uint16 j,i;
    Uint16 readDataStartIndex;

    if(mas_sla_sel == MASTER){
        sendFrame[0] = SCI_SLAVE_ADDRESS;
        if((sciFlag.bit.paraOver==0)&&(sciFlag.bit.cmdErr==0)&&(sciFlag.bit.crcChkErr==0)){
            //wr_cnt_flg_Mod++;
        }
        wr_cnt_flg_Mod++;
        if (wr_cnt_flg_Mod==1)             //100
        {
            sendFrame[1] = 0x03;
            temp = RTU_READ_ADDRESS;
            sendFrame[2] = temp>>8;
            sendFrame[3] = temp&0x0ff;
            temp = RTU_READ_DATANUM;
            sendFrame[4] = temp>>8;
            sendFrame[5] = temp&0x0ff;
            commSendData.sendNumMax = 8;  // �������ݳ���
        }else{
            if(test0x06_0x10 == 0){
                if (wr_cnt_flg_Mod==2)
                {
                    sendFrame[1] = 0x10;
                    temp = RTU_WRITE_ADDRESS;
                    sendFrame[2] = temp>>8;
                    sendFrame[3] = temp&0x0ff;
                    temp = RTU_WRITE_DATANUM;
                    sendFrame[4] = temp>>8;
                    sendFrame[5] = temp&0x0ff;
                    temp = RTU_WRITE_DATANUM*2;
                    sendFrame[6] = temp;

                    CommWrite();    //���ݴ��

                    wr_cnt_flg_Mod=0;
                    commSendData.sendNumMax = RTU_WRITE_DATANUM*2+9;  // �������ݳ���
                }
            }else{
                if (wr_cnt_flg_Mod==2){
                    sendFrame[1] = 0x06;
                    temp = test0x06_address;
                    sendFrame[2] = temp>>8;
                    sendFrame[3] = temp&0x0ff;
                    temp = 0x3476;
                    sendFrame[4] = temp>>8;
                    sendFrame[5] = temp&0x0ff;

                    wr_cnt_flg_Mod=0;
                    commSendData.sendNumMax = 8;  // �������ݳ���
                }
            }
        }

    }else{


        sendFrame[0] = rcvFrame[0];
        sendFrame[1] = rcvFrame[1];
        commSendData.sendNumMax = 8;  // �������ݳ���

        if(sciFlag.bit.cmdErr==1){
            sendFrame[1] =  rcvFrame[1] + 0x80;
            sendFrame[2] =  0x01;
            commSendData.sendNumMax = 5;  // �������ݳ���
        }else if(sciFlag.bit.paraOver){
            sendFrame[1] =  rcvFrame[1] + 0x80;
            sendFrame[2] =  0x02;
            commSendData.sendNumMax = 5;  // �������ݳ���
        }else if(sciFlag.bit.write==1){
            sendFrame[2] = RTUhighAddr;
            sendFrame[3] = RTUlowAddr;
            sendFrame[4] = RTUhighData;
            sendFrame[5] = RTUlowData;
        }else if(sciFlag.bit.read==1){
            sendNum = commRcvData.commData << 1;
            sendFrame[2] = sendNum;
            commSendData.sendNumMax = sendNum + 5;
            readDataStartIndex = 3;

            j = commRcvData.commAddr;
            j = j - RTU_READ_ADDRESS;
            for(i = 0;i<commRcvData.commData; i++){
                sendFrame[(i << 1) + readDataStartIndex] = commReadData[i+j] >> 8;
                sendFrame[(i << 1) + readDataStartIndex + 1] = commReadData[i+j] & 0x00ff;
            }
        }
    }

    // ׼��CRCУ������
    crcSend = CrcValueByteCalc(sendFrame, commSendData.sendNumMax - 2);
    sendFrame[commSendData.sendNumMax - 2] = crcSend & 0x00ff;    // CRC��λ��ǰ
    sendFrame[commSendData.sendNumMax - 1] = crcSend >> 8;
}

//2ms����
void SciDeal(void)
{
    UpdateSciFormat();      //���²����ʼ����ӻ�ѡ������
    if((SciRegs->SCIRXST.all)&0x80)    // ͨѶ����
    {
        f_rs485_ComInit();   // ��ʼ��SCI�Ĵ���
    }else if(commTicker>4000){
        commTicker = 0;
        if(mas_sla_sel == MASTER){
            commStatus = SCI_SEND_DATA_PREPARE;        // ��Ϊ����״̬

            SET_RTS_T;
            SciRegs->SCICTL1.all = 0x0022;  // ����
            SciRegs->SCICTL2.all = 0x00C1;  // ���������ж�
        }else{
            commStatus = SCI_RECEIVE_DATA;        // ��Ϊ����״̬
            SET_RTS_R;
            SciRegs->SCICTL1.all = 0x0021;  // ����
            SciRegs->SCICTL2.all = 0x0002;  // ���������ж�
        }
    }else{
        // ͨѶ���̴���
        commStatusDeal();
    }
}

void commStatusDeal(void)
{
    Uint16 i;

    switch (commStatus)
    {
        // ��������
        case SCI_RECEIVE_DATA:
            if(mas_sla_sel == MASTER){
                commSendTicker++;
                if(commRcvData.rcvNumMax>80){
                    i = 80;
                }else{
                    i = commRcvData.rcvNumMax;
                }
                if((commSendTicker>200)&&(commSendTicker>((Uint32)600L*i/(dspBaudRegData[baudrate][0]*10) + 1))){
                    commStatus = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                    SET_RTS_T;           // RTS��Ϊ����
                    SciRegs->SCICTL1.all = 0x0022;  // ����
                    SciRegs->SCICTL2.all = 0x00C1;  // ���������ж�
                }
            }else{
                SET_RTS_R;  // RTS��Ϊ����
            }
            break;

        case SCI_RCVFIN_WAIT:
            if (commTicker < commRcvData.frameSpaceTime)  //С��֡���
            {
                if (commRcvData.rcvNum > commRcvData.rcvNumMax)  //���ո�������
                {
                    commRcvData.rcvDataJuageFlag = 0;
                    commRcvData.rcvFlag = 0;

                    //�ô���Ϣ֡������, ά�ֽ���״̬

                    if(mas_sla_sel == MASTER){
                        commStatus = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                        SET_RTS_T;           // RTS��Ϊ����
                        SciRegs->SCICTL1.all = 0x0022;  // ����
                        SciRegs->SCICTL2.all = 0x00C1;  // ���������ж�
                    }else{
                        commStatus = SCI_RECEIVE_DATA;
                    }
                }
                break;
            }
            else if (commRcvData.rcvNum == commRcvData.rcvNumMax)  //δ���յ��µ�����
            {
                commRcvData.rcvDataJuageFlag = 0;
                if (commRcvData.rcvFlag == 2)  //������ַ�ŷ���
                {
                    SciRegs->SCICTL1.all = 0x0004;
                    SciRegs->SCICTL2.all = 0x00C0;
                }
                commRcvData.rcvFlag = 0;

                commStatus = SCI_RECEIVE_OK;   //��־�����������
            }
            else                  //��ֹ�쳣״̬
            {
                commRcvData.rcvDataJuageFlag = 0;
                commRcvData.rcvFlag = 0;

                //�ô���Ϣ֡������, ά�ֽ���״̬
                if(mas_sla_sel == MASTER){
                    commStatus = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                    SET_RTS_T;           // RTS��Ϊ����
                    SciRegs->SCICTL1.all = 0x0022;  // ����
                    SciRegs->SCICTL2.all = 0x00C1;  // ���������ж�
                }else{
                    commStatus = SCI_RECEIVE_DATA;
                }
                break;
            }

        case SCI_RECEIVE_OK:
            if(mas_sla_sel == MASTER){
                commSendTicker++;
                if(commSendTicker>200){
                        CommRcvDataDeal();
                        commStatus = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                        SET_RTS_T;           // RTS��Ϊ����
                        SciRegs->SCICTL1.all = 0x0022;  // ����
                        SciRegs->SCICTL2.all = 0x00C1;  // ���������ж�
                }
                break;
            }else{
                CommRcvDataDeal();
                // ��������
                if ((commRcvData.slaveAddr)              // �ǹ㲥
                && ((!sciFlag.bit.crcChkErr)         // CRCУ��ɹ���ΪPROFIBUSЭ��
                ))
                {
                    CommSendDataDeal();                 // ��������׼��
                    commStatus = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                }
                else                                    // �㲥��DSP��Ӧ֮�󲻷��ͣ���������
                {
                    commStatus = SCI_RECEIVE_DATA;
                    SET_RTS_R;  // RTS = RS485_R;       // RTS��Ϊ����
                    SciRegs->SCICTL1.all = 0x0021;  // ����
                    SciRegs->SCICTL2.all = 0x00C2;  // ���������ж�
                    break;
                 }
            }
        // ��������׼��
        case SCI_SEND_DATA_PREPARE:
            if(mas_sla_sel == MASTER){
                CommSendDataDeal();                 // ��������׼��
            }
            if ((commTicker >= commRcvData.delay)               // Ӧ���ӳ�
                && (commTicker > commRcvData.frameSpaceTime))   // MODBUSΪ3.5���ַ�ʱ��
            {
                SET_RTS_T;           // RTS��Ϊ����
                SciRegs->SCICTL1.all = 0x0022;  // ����
                SciRegs->SCICTL2.all = 0x00C1;  // ���������ж�

                commStatus = SCI_SEND_DATA;
                commSendData.sendNum = 1;               // ��ǰ�������ݸ�����Ϊ1
                SciRegs->SCITXBUF.all = sendFrame[0];     // ��ʼ����,���͵�һ������
                commSendTicker = 0;
            }
            break;

        // ��������
        case SCI_SEND_DATA:
            commSendTicker++;
            // ��ʱ�����ݷ��Ͳ��ɹ�(1.5��)
            if (commSendTicker >= ((Uint32)600L*commSendData.sendNumMax/(dspBaudRegData[baudrate][0]*10) + 1))       //*2ms
            {
                commStatus = SCI_SEND_OK;
            }
            else
            {
                break;
            }

        // ��������OK
        case SCI_SEND_OK:
            commSendTicker++;
            if(commSendTicker>1){
                if(SciRegs->SCICTL2.all & 0x0001)// Transmitter empty flag, �����������
                {
                    commStatus = SCI_RECEIVE_DATA;  // ������Ϻ���Ϊ����״̬
                    SET_RTS_R;  // RTS��Ϊ����
                    SciRegs->SCICTL1.all = 0x0021;  // ����
                    SciRegs->SCICTL2.all = 0x00C2;  // ���������ж�
                    commSendTicker = 0;
                }
            }
            break;

        default:
            break;
    }
}


#endif /* SRC_APP_COM_HANDC_C_ */
