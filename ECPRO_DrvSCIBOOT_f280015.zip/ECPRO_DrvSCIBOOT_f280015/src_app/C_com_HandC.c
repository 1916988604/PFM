
//��ʾ�壨����������ư壨�ӻ�����ͨѶ
//����C_RS485Comm�߼�


#ifndef SRC_APP_COM_HANDC_C_
#define SRC_APP_COM_HANDC_C_

#define     test_sendFlg          1       //0:������ 1:�ӻ�
#define     sci_numeber_HtoC      0       //0:scia�� 1:scib; 2:scic

#include "app_include.h"

extern const unsigned int dspBaudRegData[13][3];
volatile struct SCI_REGS *SciHtoCRegs;

enum COMM_STATUS commStatusHtoC;

// MODBUSЭ��
#define RTUslaveAddressHtoC rcvFrameHtoC[0]      // RTU֡�Ĵӻ���ַ
#define RTUcmdHtoC          rcvFrameHtoC[1]      // RTU֡��������
#define RTUhighAddrHtoC     rcvFrameHtoC[2]      // RTU֡�ĵ�ַ���ֽ�
#define RTUlowAddrHtoC      rcvFrameHtoC[3]      // RTU֡�ĵ�ַ���ֽ�
#define RTUhighDataHtoC     rcvFrameHtoC[4]      // RTU֡�����ݸ��ֽ�
#define RTUlowDataHtoC      rcvFrameHtoC[5]      // RTU֡�����ݵ��ֽ�
#define RTUlowCrcHtoC       rcvFrameHtoC[6]      // RTU֡��CRCУ����ֽ�
#define RTUhighCrcHtoC      rcvFrameHtoC[7]      // RTU֡��CRCУ����ֽ�


void f_rs485_HtoC_ComInit()
{
    Uint16 i;

    baudrateHtoC = 5;       //9600bit/s
    for(i=0;i<RTU_WRITE_DATANUM_HtoC;i++){
        rcvFrameMoreHtoC[i] = 0;
    }

#if sci_numeber_HtoC==0
    SciHtoCRegs = &SciaRegs;
#elif sci_numeber_HtoC==1
    SciHtoCRegs = &ScibRegs;
#else
    SciHtoCRegs = &ScicRegs;
#endif

    EALLOW;
    SciHtoCRegs->SCICTL1.all = 0;       //SCIϵͳ��λʱ,�ָ���ʼ״̬
    SciHtoCRegs->SCICCR.all = 0x0007;   // 1ֹͣλ������żУ��λ����LOOPBACKģʽ��idleѡ��8λ�ַ�
    SciHtoCRegs->SCIPRI.bit.FREESOFT = 1;       //����������ʱ��SCI��������
    SciHtoCRegs->SCIHBAUD.all = dspBaudRegData[baudrateHtoC][1];//2;   //50000000/((0x28a+1)*8) = 50000000/((650+1)*8) = 50000000/5208 = 9600
    SciHtoCRegs->SCILBAUD.all = dspBaudRegData[baudrateHtoC][2];//0x8A;

#if   test_sendFlg==0
    //SCI����Ϊ����ģʽ
    SET_RTS_T_HtoC;
    SciHtoCRegs->SCICTL1.all = 0x0022;  // ����
    SciHtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
#else
    SET_RTS_R_HtoC;
    SciHtoCRegs->SCICTL1.all = 0x0021;  // ����
    SciHtoCRegs->SCICTL2.all = 0x0002;  // ���������ж�
#endif

#if    MCU_PAKAGE==0    //48pin,scia
        GpioCtrlRegs.GPAPUD.bit.GPIO0 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO1 = 0;
        GpioCtrlRegs.GPAQSEL1.bit.GPIO0 = 0;
        GpioCtrlRegs.GPAQSEL1.bit.GPIO1 = 0;
        GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1;
        GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 1;
        GpioCtrlRegs.GPAGMUX1.bit.GPIO0 = 1;
        GpioCtrlRegs.GPAGMUX1.bit.GPIO1 = 1;

        // ͨѶ����ʹ���жϣ���ʼ��
        PieVectTable.SCIA_TX_INT =  &SCI_HtoC_TXD_isr;
        PieVectTable.SCIA_RX_INT =  &SCI_HtoC_RXD_isr;

        PieCtrlRegs.PIEIER9.bit.INTx1 = 1;
        PieCtrlRegs.PIEIER9.bit.INTx2 = 1;
        IER |= M_INT9;                  //  Enable interrupts:
#else   //80PIN
    #if sci_numeber_HtoC==0 //scia
        GpioCtrlRegs.GPAPUD.bit.GPIO16 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO17 = 0;
        GpioCtrlRegs.GPAQSEL2.bit.GPIO16 = 0;
        GpioCtrlRegs.GPAQSEL2.bit.GPIO17 = 0;
        GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 2;
        GpioCtrlRegs.GPAMUX2.bit.GPIO17 = 2;
        GpioCtrlRegs.GPAGMUX2.bit.GPIO16 = 1;
        GpioCtrlRegs.GPAGMUX2.bit.GPIO17 = 1;

        // ͨѶ����ʹ���жϣ���ʼ��
        PieVectTable.SCIA_TX_INT =  &SCI_HtoC_TXD_isr;
        PieVectTable.SCIA_RX_INT =  &SCI_HtoC_RXD_isr;

        PieCtrlRegs.PIEIER9.bit.INTx1 = 1;
        PieCtrlRegs.PIEIER9.bit.INTx2 = 1;
        IER |= M_INT9;                  //  Enable interrupts:
    #elif sci_numeber_HtoC==1
        //Scib
        GpioCtrlRegs.GPADIR.bit.GPIO14 = 1;
        GpioCtrlRegs.GPADIR.bit.GPIO15 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO14 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO15 = 0;
        GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = 0;
        GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = 0;
        GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 2;    //SCITXA
        GpioCtrlRegs.GPAMUX1.bit.GPIO15 = 2;    //SCIRXA
        GpioCtrlRegs.GPAGMUX1.bit.GPIO14 = 0;
        GpioCtrlRegs.GPAGMUX1.bit.GPIO15 = 0;

        PieVectTable.SCIB_TX_INT =  &SCI_HtoC_TXD_isr;
        PieVectTable.SCIB_RX_INT =  &SCI_HtoC_RXD_isr;

        PieCtrlRegs.PIEIER9.bit.INTx3 = 1;
        PieCtrlRegs.PIEIER9.bit.INTx4 = 1;
        IER |= M_INT9;                  //  Enable interrupts:
    #else
        //Scic
        GpioCtrlRegs.GPBPUD.bit.GPIO42 = 0;
        GpioCtrlRegs.GPBPUD.bit.GPIO43 = 0;
        GpioCtrlRegs.GPBQSEL1.bit.GPIO42 = 0;
        GpioCtrlRegs.GPBQSEL1.bit.GPIO43 = 0;
        GpioCtrlRegs.GPBMUX1.bit.GPIO42 = 3;    //SCITXA
        GpioCtrlRegs.GPBMUX1.bit.GPIO43 = 3;    //SCIRXA
        GpioCtrlRegs.GPBGMUX1.bit.GPIO42 = 1;
        GpioCtrlRegs.GPBGMUX1.bit.GPIO43 = 1;

        PieVectTable.SCIC_TX_INT =  &SCI_HtoC_TXD_isr;
        PieVectTable.SCIC_RX_INT =  &SCI_HtoC_RXD_isr;

        IER |= M_INT8;                  //  Enable interrupts:
        PieCtrlRegs.PIEIER8.bit.INTx5 = 1;
        PieCtrlRegs.PIEIER8.bit.INTx6 = 1;
    #endif
#endif

    EDIS;
    commRcvDataHtoC.rcvFlag = 0;
    commRcvDataHtoC.rcvNum = 0;
    commRcvDataHtoC.slaveAddr = 0;
    commRcvDataHtoC.slaveDddr = 0;
    commRcvDataHtoC.commAddr = 0;
    commRcvDataHtoC.commCmd = 0;
    commRcvDataHtoC.rcvDataJuageFlag = 0;
    commRcvDataHtoC.moreWriteNum = 0;
    commRcvDataHtoC.rcvNumMax = 8;      // ��ʼ�����ճ��ȣ�ʵ�ʳ������ж��ж�
    commRcvDataHtoC.frameSpaceTime = (Uint16)(385.0*2.0/dspBaudRegData[baudrateHtoC][0])+1;   // 3.5 char time=3.5*(1+8+2)/baud
    //commRcvDataHtoC.frameSpaceTime = 385 * 2 / 96+ 1;        // 3.5 char time=3.5*(1+8+2)/baud
#if   test_sendFlg==0
    commRcvDataHtoC.delay = 120;      //60ms
    commStatusHtoC = SCI_SEND_DATA_PREPARE;        // ��Ϊ����״̬
#else
    commRcvDataHtoC.delay = 2;      //1ms
    commStatusHtoC = SCI_RECEIVE_DATA;        // ��Ϊ����״̬
#endif
}

/**************************�ӻ�**************************************************/
//�ӻ���ȡ������д0x10����
void CommWriteBackHtoC(void)
{
    u_speed_HandC = rcvFrameMoreHtoC[0];    //rcvFrameMoreHtoC[0]--0x4000
    u_enable_HandC = rcvFrameMoreHtoC[1] & 0x01;
    u_ctrl_logic.bit.night_ctrlMode = (rcvFrameMoreHtoC[1]>>3) & 0x01;
    sys_param.liquidLimtEn = (rcvFrameMoreHtoC[1]>>4) & 0x01;
    sys_param.mode = (rcvFrameMoreHtoC[1]>>8) & 0x01F;

    //e485Mode = (rcvFrameMoreHtoC[1]>>4) & 0x01;

    relay1OutMode = rcvFrameMoreHtoC[2] & 0x03;
    relay2OutMode = (rcvFrameMoreHtoC[2]>>2) & 0x03;
    ai1InMode = (rcvFrameMoreHtoC[2]>>4) & 0x03;
    ai2InMode = (rcvFrameMoreHtoC[2]>>6) & 0x03;
    pwmOutMode = (rcvFrameMoreHtoC[2]>>8) & 0x03;
    pwmInMode = (rcvFrameMoreHtoC[2]>>14) & 0x03;

    u_ctrl_logic.bit.ai2_ctrlDir = (rcvFrameMoreHtoC[2]>>10) & 0x03;
    u_ctrl_logic.bit.ai3_ctrlDir = (rcvFrameMoreHtoC[2]>>12) & 0x03;
    sys_param.liquidLimtMax = rcvFrameMoreHtoC[3];
    sys_param.TempMax = rcvFrameMoreHtoC[4];

    sys_param.errRstEn = rcvFrameMoreHtoC[5] & 0x01;
    tempSoruceSel = (rcvFrameMoreHtoC[5]>>2) & 0x01;
    sysSoruceSel = (rcvFrameMoreHtoC[5]>>3) & 0x01;
    u_DpumpMode_HtoC = (rcvFrameMoreHtoC[5]>>5) & 0x03;
    sysSci_mode.varInit = (rcvFrameMoreHtoC[5]>>15) & 0x01;

    sys_param.Address485 = rcvFrameMoreHtoC[10];
    sys_param.AddressCan = rcvFrameMoreHtoC[11];
    sys_param.AddressLIN = rcvFrameMoreHtoC[12];
}

//�ӻ��ظ������Ķ�0x03����
void CommReadHtoC(void)
{
    //�ӻ�ʱ��0x03�������ݴ��
    commReadDataHtoC[0]=sci_motor_spd;      //0x5000
    commReadDataHtoC[1]=sci_motor_udcVol;   //0x5001
    //commReadDataHtoC[2]=sci_motor_idc;
    commReadDataHtoC[2]=sci_motor_gridVol;
    commReadDataHtoC[3]=sci_motor_igbtT;
    //commReadDataHtoC[5]=sci_motor_ntcT;
    commReadDataHtoC[4]=sci_motor_fault;
    commReadDataHtoC[5]=sci_motor_runFlg + (modeNightFlg<<2) + (sci_motor_pwrLmtFlg<<3) + (sys_param.mode<<7);
    commReadDataHtoC[6]=sci_motor_flow;
    commReadDataHtoC[7]=sci_motor_lift;
    commReadDataHtoC[8]=sci_motor_power;
    commReadDataHtoC[9]=sci_motor_Hauto;
    sci_motor_ntcT = (int)temperature;
    commReadDataHtoC[10]=sci_motor_ntcT;
    sci_motor_ntcT = (int)tempeMediumEx;
    commReadDataHtoC[11]=sci_motor_ntcT;
    commReadDataHtoC[12]=sci_motor_Hmax;
    commReadDataHtoC[13]=sci_motor_Hmin;
    commReadDataHtoC[14]=sci_motor_CHmax;
    commReadDataHtoC[15]=sci_motor_CHmin;
    commReadDataHtoC[16]=PUMP_VER_NUMBER;
    commReadDataHtoC[17]=0;
    commReadDataHtoC[18]=0;
    commReadDataHtoC[19]=7;
    commReadDataHtoC[20]=8;
    commReadDataHtoC[21]=9;
    commReadDataHtoC[22]=0;
    commReadDataHtoC[23]=0;
    commReadDataHtoC[24]=0;
    commReadDataHtoC[25]=0;
    commReadDataHtoC[26]=0;
    commReadDataHtoC[27]=0;
    commReadDataHtoC[28]=28;
    commReadDataHtoC[29]=0;
    commReadDataHtoC[30]=0;
    commReadDataHtoC[31]=0;
    commReadDataHtoC[32]=0;
    commReadDataHtoC[33]=33;
    commReadDataHtoC[34]=0;
    commReadDataHtoC[35]=0;
    commReadDataHtoC[36]=0;
    commReadDataHtoC[37]=0;
    commReadDataHtoC[38]=38;
    commReadDataHtoC[39]=39;
}

//**************************************����***************************************/
void CommWriteHtoC(void)
{
    Uint16 temp;
    //����ʱ��0x10�������ݴ��
    temp = 0;        //0x4000
    sendFrameHtoC[7] = temp>>8;
    sendFrameHtoC[8] = temp&0x0ff;
    temp = 0;       //0x4001
    sendFrameHtoC[9] = temp>>8;
    sendFrameHtoC[10] = temp&0x0ff;
    temp = 0x10;
    sendFrameHtoC[11] = temp>>8;
    sendFrameHtoC[12] = temp&0x0ff;
    temp = 0x20;
    sendFrameHtoC[13] = temp>>8;
    sendFrameHtoC[14] = temp&0x0ff;
    temp = 0x30;
    sendFrameHtoC[15] = temp>>8;
    sendFrameHtoC[16] = temp&0x0ff;
    temp = 0x40;
    sendFrameHtoC[17] = temp>>8;
    sendFrameHtoC[18] = temp&0x0ff;
    temp = 0x50;
    sendFrameHtoC[19] = temp>>8;
    sendFrameHtoC[20] = temp&0x0ff;
    temp = 0x60;
    sendFrameHtoC[21] = temp>>8;
    sendFrameHtoC[22] = temp&0x0ff;
    temp = 0x70;
    sendFrameHtoC[23] = temp>>8;
    sendFrameHtoC[24] = temp&0x0ff;
    temp = 0x80;
    sendFrameHtoC[25] = temp>>8;
    sendFrameHtoC[26] = temp&0x0ff;
    temp = 0x90;
    sendFrameHtoC[27] = temp>>8;
    sendFrameHtoC[28] = temp&0x0ff;
    temp = 0x91;
    sendFrameHtoC[29] = temp>>8;
    sendFrameHtoC[30] = temp&0x0ff;
    temp = 0x92;
    sendFrameHtoC[31] = temp>>8;
    sendFrameHtoC[32] = temp&0x0ff;
    temp = 0x93;
    sendFrameHtoC[33] = temp>>8;
    sendFrameHtoC[34] = temp&0x0ff;
    temp = 0x94;
    sendFrameHtoC[35] = temp>>8;
    sendFrameHtoC[36] = temp&0x0ff;
    temp = 0x95;
    sendFrameHtoC[37] = temp>>8;
    sendFrameHtoC[38] = temp&0x0ff;
    temp = 0x96;
    sendFrameHtoC[39] = temp>>8;
    sendFrameHtoC[40] = temp&0x0ff;
    temp = 0x97;
    sendFrameHtoC[41] = temp>>8;
    sendFrameHtoC[42] = temp&0x0ff;
    temp = 0x98;
    sendFrameHtoC[43] = temp>>8;
    sendFrameHtoC[44] = temp&0x0ff;
    temp = 0x99;
    sendFrameHtoC[45] = temp>>8;
    sendFrameHtoC[46] = temp&0x0ff;
    temp = 0x9a;
    sendFrameHtoC[47] = temp>>8;
    sendFrameHtoC[48] = temp&0x0ff;
    temp = 0x9b;
    sendFrameHtoC[49] = temp>>8;
    sendFrameHtoC[50] = temp&0x0ff;
    temp = 0x9c;
    sendFrameHtoC[51] = temp>>8;
    sendFrameHtoC[52] = temp&0x0ff;
    temp = 0x9d;
    sendFrameHtoC[53] = temp>>8;
    sendFrameHtoC[54] = temp&0x0ff;
    temp = 0x9e;
    sendFrameHtoC[55] = temp>>8;
    sendFrameHtoC[56] = temp&0x0ff;
    temp = 0x9f;
    sendFrameHtoC[57] = temp>>8;
    sendFrameHtoC[58] = temp&0x0ff;
    temp = 0xa0;
    sendFrameHtoC[59] = temp>>8;
    sendFrameHtoC[60] = temp&0x0ff;
    temp = 0xa1;
    sendFrameHtoC[61] = temp>>8;
    sendFrameHtoC[62] = temp&0x0ff;
    temp = 0xa2;
    sendFrameHtoC[63] = temp>>8;
    sendFrameHtoC[64] = temp&0x0ff;
    temp = 0xa3;
    sendFrameHtoC[65] = temp>>8;
    sendFrameHtoC[66] = temp&0x0ff;
    temp = 0xa4;
    sendFrameHtoC[67] = temp>>8;
    sendFrameHtoC[68] = temp&0x0ff;
}


//====================================================================
// ���ݽ��պ���Ϣ����
//====================================================================
void ModbusRcvDataDealHtoC(void)
{
#if    test_sendFlg==0
    if(RTUcmdHtoC == SCI_CMD_READ)
#else
        if(RTUcmdHtoC == SCI_CMD_WRITE_MORE)
#endif
    {
#if    test_sendFlg==0
            commRcvDataHtoC.slaveAddr = RTUslaveAddressHtoC;                // �ӻ���ַ
            commRcvDataHtoC.commCmd = RTUcmdHtoC;                           // ͨѶ����
            commRcvDataHtoC.commAddr = RTU_READ_ADDRESS_HtoC; // ������ַ
            commRcvDataHtoC.commData = rcvFrameHtoC[2] ; // ��������
            commRcvDataHtoC.crcRcv = (rcvFrameHtoC[commRcvDataHtoC.commData+4] <<8)+rcvFrameHtoC[commRcvDataHtoC.commData+3]; // ��������;     // CRCУ��ֵ
            commRcvDataHtoC.crcSize = commRcvDataHtoC.commData + 3;                                // CRCУ�鳤��
            commRcvDataHtoC.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����

#else
        commRcvDataHtoC.slaveAddr = RTUslaveAddressHtoC;                // �ӻ���ַ
        commRcvDataHtoC.commCmd = RTUcmdHtoC;                           // ͨѶ����
        commRcvDataHtoC.commAddr = (RTUhighAddrHtoC << 8) + RTUlowAddrHtoC; // ������ʼ��ַ
        commRcvDataHtoC.commData = (RTUhighDataHtoC << 8) + RTUlowDataHtoC; // �����Ĵ���������

        commRcvDataHtoC.moreWriteNum = rcvFrameHtoC[6];                 // �ֽ���

        commRcvDataHtoC.crcSize = commRcvDataHtoC.moreWriteNum + 7; // CRCУ�鳤��
        commRcvDataHtoC.crcRcv = (rcvFrameHtoC[commRcvDataHtoC.crcSize+1] << 8) + rcvFrameHtoC[commRcvDataHtoC.crcSize];     // CRCУ��ֵ
        commRcvDataHtoC.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����
#endif
    }
    else
    {
        commRcvDataHtoC.slaveAddr = RTUslaveAddressHtoC;                // �ӻ���ַ
        commRcvDataHtoC.commCmd = RTUcmdHtoC;                           // ͨѶ����
        commRcvDataHtoC.commAddr = (RTUhighAddrHtoC << 8) + RTUlowAddrHtoC; // ������ַ
        commRcvDataHtoC.commData = (RTUhighDataHtoC << 8) + RTUlowDataHtoC; // ��������
        commRcvDataHtoC.crcRcv = (RTUhighCrcHtoC << 8) + RTUlowCrcHtoC;     // CRCУ��ֵ
        commRcvDataHtoC.crcSize = 6;                                // CRCУ�鳤��
        commRcvDataHtoC.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����
    }
}

//=====================================================================
// ͨѶ���յ����ݴ�������
//=====================================================================
void CommRcvDataDealHtoC(void)
{
    Uint16 writeErr=0,readErr=0;
    Uint16 i,j;
    long u32_temp;
    Uint16 comCrcHtoC=0;

    // ��ͬЭ��Ľ���������Ϣ����
    // �������������ַ�����ݵ���Ϣ
    ModbusRcvDataDealHtoC();
    // ��SCI��־
    sciFlagHtoC.all = 0;

    comCrcHtoC = CrcValueByteCalc(rcvFrameHtoC, commRcvDataHtoC.crcSize);
    // CRCУ��
    if (commRcvDataHtoC.crcRcv != comCrcHtoC)  // CRCУ������ж�
    {
        sciFlagHtoC.bit.crcChkErr = 1;                      // ��λ��CRCErr��send
        commRcvDataHtoC.rcvCrcErrCounter++;                 // ��¼CRCУ���������
    }
     // �㲥ģʽ
    else if (!commRcvDataHtoC.slaveAddr)
    {
        // �㲥д����
        if ((SCI_CMD_WRITE == commRcvDataHtoC.commCmd)
          || (SCI_CMD_WRITE_MORE == commRcvDataHtoC.commCmd)
           )
        {
            // ��д��־
            sciFlagHtoC.bit.write = 1;
        }
        else
        {
            sciFlagHtoC.bit.cmdErr = 1;                                                 // �������
        }
    }
    else if (commRcvDataHtoC.slaveAddr == SCI_SLAVE_ADDRESS_HtoC) // ������ַ�ж�
    {
        if (SCI_CMD_READ == commRcvDataHtoC.commCmd)       // ���������
        {
            sciFlagHtoC.bit.read = 1;                           // ��λ��read��send
        }
        else if ((SCI_CMD_WRITE == commRcvDataHtoC.commCmd)
                || (SCI_CMD_WRITE_MORE == commRcvDataHtoC.commCmd))      // д�������
        {
            sciFlagHtoC.bit.write = 1;
        }
        else
        {
            sciFlagHtoC.bit.cmdErr = 1;                                                 // �������
        }
    }

#if    test_sendFlg==0  //��������
    if (sciFlagHtoC.bit.read){
        if(commRcvDataHtoC.commData > (RTU_READ_DATANUM_HtoC*2)){
            readErr = COMM_ERR_ADDR;
        }else{
            j =0;
            for(i=0;i<(commRcvDataHtoC.commData>>1);i++)
            {
                rcvFrameMoreHtoC[j] = (rcvFrameHtoC[3+i*2]<<8) + rcvFrameHtoC[4+i*2];       //������ȡ�ӻ����͵�����
                j++;
            }
        }

        if (readErr){
            sciFlagHtoC.bit.paraOver = 1;
        }
    }

    if (sciFlagHtoC.bit.write){
        if(commRcvDataHtoC.commData != RTU_WRITE_DATANUM_HtoC){
            writeErr = COMM_ERR_ADDR;
        }else if(commRcvDataHtoC.commAddr != RTU_WRITE_ADDRESS_HtoC){
            writeErr = COMM_ERR_ADDR;
        }

        if (writeErr){
           sciFlagHtoC.bit.paraOver = 1;
        }
    }

#endif
#if    test_sendFlg==1  //�ӻ�����
    if (sciFlagHtoC.bit.read)
    {
        u32_temp = commRcvDataHtoC.commAddr + commRcvDataHtoC.commData-1;
        if(commRcvDataHtoC.commData > RTU_READ_DATANUM_HtoC){
            readErr = COMM_ERR_ADDR;
        }else if(commRcvDataHtoC.commAddr < RTU_READ_ADDRESS_HtoC){
            readErr = COMM_ERR_ADDR;
        }else if(u32_temp>(RTU_READ_ADDRESS_HtoC+RTU_READ_DATANUM_HtoC-1)){
            readErr = COMM_ERR_ADDR;
        }else{
            CommReadHtoC();
        }
        if (readErr){
            sciFlagHtoC.bit.paraOver = 1;
        }
    }
    // д���ݴ���
    if (sciFlagHtoC.bit.write)
    {
        if(SCI_CMD_WRITE_MORE == commRcvDataHtoC.commCmd)
        {
            u32_temp = commRcvDataHtoC.commAddr + commRcvDataHtoC.commData-1;
            if(((commRcvDataHtoC.commData*2) != commRcvDataHtoC.moreWriteNum)
                ||(commRcvDataHtoC.commData > RTU_WRITE_DATANUM_HtoC))
            {
                writeErr = COMM_ERR_ADDR;
            }else if(commRcvDataHtoC.commAddr < RTU_WRITE_ADDRESS_HtoC){
                writeErr = COMM_ERR_ADDR;
            }else if(u32_temp > (RTU_WRITE_ADDRESS_HtoC + RTU_WRITE_DATANUM_HtoC - 1) ){
                writeErr = COMM_ERR_ADDR;
            }
            else
            {
                j = commRcvDataHtoC.commAddr;
                j = j - RTU_WRITE_ADDRESS_HtoC;
                if(j > (RTU_WRITE_DATANUM_HtoC - 1)){
                    writeErr = COMM_ERR_ADDR;
                }else{
                    for(i=0;i<commRcvDataHtoC.moreWriteNum;i++)
                    {
                        rcvFrameMoreHtoC[j] = (rcvFrameHtoC[7+i]<<8) + rcvFrameHtoC[8+i];
                        i++;
                        j++;
                    }
                    CommWriteBackHtoC();
                }
            }
        }
        else
        {
            writeErr = COMM_ERR_ADDR;
        }
        // дʧ��
        if (writeErr)
        {
            // ��ʾдʧ�ܹ���
            sciFlagHtoC.bit.paraOver = 1;
        }
    }
#endif
}


interrupt void SCI_HtoC_RXD_isr(void)
{
    // ���ݽ���֡ͷ�ж�
    Uint16 tmp;
    Uint16 tmp1;
    tmp = SciHtoCRegs->SCIRXBUF.all;
    tmp1 = ModbusStartDealHtoC(tmp);
    if (tmp1)
    {
        // Ϊ�����Ľ�������  0-��Ч   1-�㲥��ַ    2-������ַ
        if (commRcvDataHtoC.rcvFlag)
        {
            // ��֡ͷͨѶ���ݽ���
            CommDataReRcvHtoC(tmp);
        }
    }

    commTickerHtoC = 0;                     // �н������ݣ����¼�ʱ
#if sci_numeber_HtoC==2
    PieCtrlRegs.PIEACK.bit.ACK8 = 1;    // Issue PIE ACK
#else
    PieCtrlRegs.PIEACK.bit.ACK9 = 1;    // Issue PIE ACK
#endif
}

interrupt void SCI_HtoC_TXD_isr(void)
{
    // ͨѶ��������
     // ����һ֡����û�����
   if (commSendDataHtoC.sendNum< commSendDataHtoC.sendNumMax)
   {
       SciHtoCRegs->SCITXBUF.all = sendFrameHtoC[commSendDataHtoC.sendNum++];
   }
    // ����һ֡����ȫ�����
   else if (commSendDataHtoC.sendNum >= commSendDataHtoC.sendNumMax)
   {
        // ��־�����������
       commStatusHtoC = SCI_SEND_OK;
   }
   commTickerHtoC = 0;                     // ����һ���ַ���ɣ����¼�ʱ
#if sci_numeber_HtoC==2
    PieCtrlRegs.PIEACK.bit.ACK8 = 1;    // Issue PIE ACK
#else
    PieCtrlRegs.PIEACK.bit.ACK9 = 1;    // Issue PIE ACK
#endif
}

//====================================================================
// MODBUS֡ͷ�ж�
// ����: tmp-����֡����
// ����: 0-֡ͷ�жϹ�����
//       1-����Ҫ֡ͷ�жϣ�ֱ�Ӵ洢��������
//===================================================================
Uint16 ModbusStartDealHtoC(Uint16 tmp)
{
    if (commTickerHtoC >= 4000)                                     // 2sʱ��
    {
        commRcvDataHtoC.rcvDataJuageFlag = 0;                       // ��ʱ��û�����꣬֡ͷ�жϸ�λ
    }

    if ((commTickerHtoC > commRcvDataHtoC.frameSpaceTime))              // ����3.5���ַ�ʱ�䣬�µ�һ֡�Ŀ�ʼ
    {
        RTUslaveAddressHtoC = tmp;
        // �㲥ģʽ
        if (RTUslaveAddressHtoC == 0)
        {
            commRcvDataHtoC.rcvNum = 1;
            commRcvDataHtoC.rcvFlag = 1;                           // ���յ�֡�ĵ�һ���ֽڣ����ǹ㲥ģʽ
        }
        else if (RTUslaveAddressHtoC == SCI_SLAVE_ADDRESS_HtoC)
        {
            commRcvDataHtoC.rcvNum = 1;
            commRcvDataHtoC.rcvFlag = 2;
        }
        else                                                   // ������ַ
        {
            commRcvDataHtoC.rcvFlag = 0;                        // ��ַ����Ӧ�����ݲ�����
        }

        return 0;
    }

    return 1;
}

void CommDataReRcvHtoC(Uint16 tmp)
{
    if (commRcvDataHtoC.rcvNum < commRcvDataHtoC.rcvNumMax)  // ����һ֡���ݻ�û�����
    {
        rcvFrameHtoC[commRcvDataHtoC.rcvNum] = tmp;
    }
    commRcvDataHtoC.rcvNum++;

    if((rcvFrameHtoC[1] ==SCI_CMD_READ)
        ||(rcvFrameHtoC[1] ==SCI_CMD_WRITE)
        ||(rcvFrameHtoC[1] ==SCI_CMD_WRITE_MORE))
    {
        commRcvDataHtoC.dpOrModbus = 2; //  2:modbus
        commRcvDataHtoC.rcvNumMax = 8;
        // 01 10 f0 08 00 02 04
#if   test_sendFlg==0
        //����
        //01 03 04 00 00 00 00 CRCL CRCH
        if((rcvFrameHtoC[1] ==SCI_CMD_READ)&&(commRcvDataHtoC.rcvNum>=8))
        {
            commRcvDataHtoC.rcvNumMax = rcvFrameHtoC[2] + 5;
        }
#else
        //�ӻ�
        if((rcvFrameHtoC[1] ==SCI_CMD_WRITE_MORE)&&(commRcvDataHtoC.rcvNum>=8))
        {
            commRcvDataHtoC.rcvNumMax = rcvFrameHtoC[6] + 9;
        }
#endif
    }
    if (commRcvDataHtoC.rcvNum == commRcvDataHtoC.rcvNumMax)  //���ո�������
    {
        commStatusHtoC = SCI_RCVFIN_WAIT;   //��־���ս����ȴ�
    }
}


void CommSendDataDealHtoC(void)
{
#if   test_sendFlg==1
    Uint16 sendNum;
    Uint16 crcSend;
    Uint16 j,i;
    Uint16 readDataStartIndex;

    sendFrameHtoC[0] = rcvFrameHtoC[0];
    sendFrameHtoC[1] = rcvFrameHtoC[1];
    commSendDataHtoC.sendNumMax = 8;  // �������ݳ���

    if(sciFlagHtoC.bit.cmdErr==1){
        sendFrameHtoC[1] =  rcvFrameHtoC[1] + 0x80;
        sendFrameHtoC[2] =  0x01;
        commSendDataHtoC.sendNumMax = 5;  // �������ݳ���
    }else if(sciFlagHtoC.bit.paraOver){
        sendFrameHtoC[1] =  rcvFrameHtoC[1] + 0x80;
        sendFrameHtoC[2] =  0x02;
        commSendDataHtoC.sendNumMax = 5;  // �������ݳ���
    }else if(sciFlagHtoC.bit.write==1){
        sendFrameHtoC[2] = RTUhighAddrHtoC;
        sendFrameHtoC[3] = RTUlowAddrHtoC;
        sendFrameHtoC[4] = RTUhighDataHtoC;
        sendFrameHtoC[5] = RTUlowDataHtoC;
    }else if(sciFlagHtoC.bit.read==1){
        sendNum = commRcvDataHtoC.commData << 1;
        sendFrameHtoC[2] = sendNum;
        commSendDataHtoC.sendNumMax = sendNum + 5;
        readDataStartIndex = 3;

        j = commRcvDataHtoC.commAddr;
        j = j - RTU_READ_ADDRESS_HtoC;
        for(i = 0;i<commRcvDataHtoC.commData; i++){
            sendFrameHtoC[(i << 1) + readDataStartIndex] = commReadDataHtoC[i+j] >> 8;
            sendFrameHtoC[(i << 1) + readDataStartIndex + 1] = commReadDataHtoC[i+j] & 0x00ff;
        }
    }

#else
    Uint16 temp;
    static Uint16 wr_cnt_flg=0;
    Uint16 crcSend;

    sendFrameHtoC[0] = SCI_SLAVE_ADDRESS_HtoC;
    if((sciFlagHtoC.bit.paraOver==0)&&(sciFlagHtoC.bit.cmdErr==0)&&(sciFlagHtoC.bit.crcChkErr==0)){
        //wr_cnt_flg++;
    }
    wr_cnt_flg++;
    if (wr_cnt_flg==1)             //100
    {
        sendFrameHtoC[1] = 0x03;
        temp = RTU_READ_ADDRESS_HtoC;
        sendFrameHtoC[2] = temp>>8;
        sendFrameHtoC[3] = temp&0x0ff;
        temp = RTU_READ_DATANUM_HtoC;
        sendFrameHtoC[4] = temp>>8;
        sendFrameHtoC[5] = temp&0x0ff;
        commSendDataHtoC.sendNumMax = 8;  // �������ݳ���
    }
    else if (wr_cnt_flg==2)
    {
        sendFrameHtoC[1] = 0x10;
        temp = RTU_WRITE_ADDRESS_HtoC;
        sendFrameHtoC[2] = temp>>8;
        sendFrameHtoC[3] = temp&0x0ff;
        temp = RTU_WRITE_DATANUM_HtoC;
        sendFrameHtoC[4] = temp>>8;
        sendFrameHtoC[5] = temp&0x0ff;
        temp = RTU_WRITE_DATANUM_HtoC*2;
        sendFrameHtoC[6] = temp;

        CommWriteHtoC();    //���ݴ��

        wr_cnt_flg=0;
        commSendDataHtoC.sendNumMax = RTU_WRITE_DATANUM_HtoC*2+9;  // �������ݳ���
    }
#endif
    // ׼��CRCУ������
    crcSend = CrcValueByteCalc(sendFrameHtoC, commSendDataHtoC.sendNumMax - 2);
    sendFrameHtoC[commSendDataHtoC.sendNumMax - 2] = crcSend & 0x00ff;    // CRC��λ��ǰ
    sendFrameHtoC[commSendDataHtoC.sendNumMax - 1] = crcSend >> 8;
}

//2ms����
void SciDeal_HtoC(void)
{
    if((SciHtoCRegs->SCIRXST.all)&0x80)    // ͨѶ����
    {
        f_rs485_HtoC_ComInit();   // ��ʼ��SCI�Ĵ���
    }else if(commTickerHtoC>4000){
        commTickerHtoC = 0;
#if   test_sendFlg==0
        commStatusHtoC = SCI_SEND_DATA_PREPARE;        // ��Ϊ����״̬

        SET_RTS_T_HtoC;
        SciHtoCRegs->SCICTL1.all = 0x0022;  // ����
        SciHtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
#else
        commStatusHtoC = SCI_RECEIVE_DATA;        // ��Ϊ����״̬
        SET_RTS_R_HtoC;
        SciHtoCRegs->SCICTL1.all = 0x0021;  // ����
        SciHtoCRegs->SCICTL2.all = 0x0002;  // ���������ж�
#endif
    }else{
        // ͨѶ���̴���
        commStatusDeal_HtoC();
    }
}

void commStatusDeal_HtoC(void)
{
    switch (commStatusHtoC)
    {
        // ��������
        case SCI_RECEIVE_DATA:
#if    test_sendFlg==0
            commSendTickerHtoC++;
            if(commSendTickerHtoC>200){
                commStatusHtoC = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                SET_RTS_T_HtoC;           // RTS��Ϊ����
                SciHtoCRegs->SCICTL1.all = 0x0022;  // ����
                SciHtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
            }
#else
            SET_RTS_R_HtoC;  // RTS��Ϊ����
#endif
            break;

        case SCI_RCVFIN_WAIT:
            if (commTickerHtoC < commRcvDataHtoC.frameSpaceTime)  //С��֡���
            {
                if (commRcvDataHtoC.rcvNum > commRcvDataHtoC.rcvNumMax)  //���ո�������
                {
                    commRcvDataHtoC.rcvDataJuageFlag = 0;
                    commRcvDataHtoC.rcvFlag = 0;

                    //�ô���Ϣ֡������, ά�ֽ���״̬

#if    test_sendFlg==0
                    commStatusHtoC = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                    SET_RTS_T_HtoC;           // RTS��Ϊ����
                    SciHtoCRegs->SCICTL1.all = 0x0022;  // ����
                    SciHtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
#else
                    commStatusHtoC = SCI_RECEIVE_DATA;
#endif
                }
                break;
            }
            else if (commRcvDataHtoC.rcvNum == commRcvDataHtoC.rcvNumMax)  //δ���յ��µ�����
            {
                commRcvDataHtoC.rcvDataJuageFlag = 0;
                if (commRcvDataHtoC.rcvFlag == 2)  //������ַ�ŷ���
                {
                    SciHtoCRegs->SCICTL1.all = 0x0004;
                    SciHtoCRegs->SCICTL2.all = 0x00C0;
                }
                commRcvDataHtoC.rcvFlag = 0;

                commStatusHtoC = SCI_RECEIVE_OK;   //��־�����������
            }
            else                  //��ֹ�쳣״̬
            {
                commRcvDataHtoC.rcvDataJuageFlag = 0;
                commRcvDataHtoC.rcvFlag = 0;

                //�ô���Ϣ֡������, ά�ֽ���״̬
#if    test_sendFlg==0
                commStatusHtoC = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                SET_RTS_T_HtoC;           // RTS��Ϊ����
                SciHtoCRegs->SCICTL1.all = 0x0022;  // ����
                SciHtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
#else
                commStatusHtoC = SCI_RECEIVE_DATA;
#endif
                break;
            }

        case SCI_RECEIVE_OK:
#if    test_sendFlg==0
            commSendTickerHtoC++;
            if(commSendTickerHtoC>200){
                    CommRcvDataDealHtoC();
                    commStatusHtoC = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                    SET_RTS_T_HtoC;           // RTS��Ϊ����
                    SciHtoCRegs->SCICTL1.all = 0x0022;  // ����
                    SciHtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
            }
            break;
#else
            CommRcvDataDealHtoC();
            // ��������
            if ((commRcvDataHtoC.slaveAddr)              // �ǹ㲥
            && ((!sciFlagHtoC.bit.crcChkErr)         // CRCУ��ɹ���ΪPROFIBUSЭ��
            ))
            {
                CommSendDataDealHtoC();                 // ��������׼��
                commStatusHtoC = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
            }
            else                                    // �㲥��DSP��Ӧ֮�󲻷��ͣ���������
            {
                commStatusHtoC = SCI_RECEIVE_DATA;
                SET_RTS_R_HtoC;  // RTS = RS485_R;       // RTS��Ϊ����
                SciHtoCRegs->SCICTL1.all = 0x0021;  // ����
                SciHtoCRegs->SCICTL2.all = 0x00C2;  // ���������ж�
                break;
             }
#endif
        // ��������׼��
        case SCI_SEND_DATA_PREPARE:
#if    test_sendFlg==0
            CommSendDataDealHtoC();                 // ��������׼��
#else
#endif
            if ((commTickerHtoC >= commRcvDataHtoC.delay)               // Ӧ���ӳ�
                && (commTickerHtoC > commRcvDataHtoC.frameSpaceTime))   // MODBUSΪ3.5���ַ�ʱ��
            {
                SET_RTS_T_HtoC;           // RTS��Ϊ����
                SciHtoCRegs->SCICTL1.all = 0x0022;  // ����
                SciHtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�

                commStatusHtoC = SCI_SEND_DATA;
                commSendDataHtoC.sendNum = 1;               // ��ǰ�������ݸ�����Ϊ1
                SciHtoCRegs->SCITXBUF.all = sendFrameHtoC[0];     // ��ʼ����,���͵�һ������
                commSendTickerHtoC = 0;
            }
            break;

        // ��������
        case SCI_SEND_DATA:
            commSendTickerHtoC++;
            // ��ʱ�����ݷ��Ͳ��ɹ�(1.5��)
            if (commSendTickerHtoC >= ((Uint32)600L*commSendDataHtoC.sendNumMax/(dspBaudRegData[baudrateHtoC][0]*10) + 1))     //*2ms
            {
                commStatusHtoC = SCI_SEND_OK;
            }
            else
            {
                break;
            }

        // ��������OK
        case SCI_SEND_OK:
            if(SciHtoCRegs->SCICTL2.all & 0x0001)// Transmitter empty flag, �����������
            {
                commStatusHtoC = SCI_RECEIVE_DATA;  // ������Ϻ���Ϊ����״̬
                SET_RTS_R_HtoC;  // RTS��Ϊ����
                SciHtoCRegs->SCICTL1.all = 0x0021;  // ����
                SciHtoCRegs->SCICTL2.all = 0x00C2;  // ���������ж�
                commSendTickerHtoC = 0;
            }
            break;

        default:
            break;
    }
}


#endif /* SRC_APP_COM_HANDC_C_ */
