#ifndef	APP_SPEEDRAMP_C_
#define	APP_SPEEDRAMP_C_

#include "app_include.h"

/*************************************************************************************************/
//���������u16_PreRelaySta.bit.preRelayOn�� motorVars_M1.flagEnableRunAndIdentify�� f_speed_gear
//������Դ��������Ԥ���߼�

//�����speed_ramp_cmd��
/*************************************************************************************************/

void speedRamp_init()
{
    speed_ramp_cmd = 0;
    f_speed_gear = 0;
    vcu_speedRampCmd = 0;
}

void LinearRamp(float cmd, float* ref, float upStep, float downStep, float upLimit, float downLimit)
{
//========================================================================================
// Temporary variable definition (execute time: ?? CPUCLK)
//========================================================================================
	float		step	= 0;
	float   temp;
//========================================================================================
// ���������޷� (execute time: ?? CPUCLK)
//========================================================================================
	cmd	= min(cmd, upLimit);
	cmd	= max(cmd, downLimit);
//========================================================================================
// Ramp���򼰲���ȷ�� (execute time: ?? CPUCLK)
//========================================================================================
	temp = (*ref) * cmd;
	if (temp < 0)
	{
		step = downStep;
	}
	else
	{
		step = (fabsf(*ref) < fabsf(cmd)) ? upStep : downStep;
	}
//========================================================================================
// Ramp (execute time: ?? CPUCLK)
//========================================================================================
	if ((*ref) + step < cmd)
	{
		(*ref) += step;
	}
	else if ((*ref) - step > cmd)
	{
		(*ref) -= step;
	}
	else
	{
		(*ref)	= cmd;
	}
	//=====================
	(*ref)	= min((*ref), upLimit);
	(*ref)  = max((*ref), downLimit);
}


void speedRamp()
{
	float upStep,downStep,upLimit,downLimit;
	static unsigned int b_shrap=0;
    static unsigned int u16_shrapCnt=0;
    static unsigned int u16_firstStartCnt=0;

	upLimit = powerLmt.Max;//SPEED_MAX;
	downLimit = -upLimit;
    upStep = UP_STEP_SPEED;         //20;
    downStep = DOWN_STEP_SPEED;     //50;       //50RPM

    if((u16_PreRelaySta.bit.preRelayOn == 1) && (u16_PreRelaySta.bit.pfcCtrlOn == 1)){
        if(u_motor_ctrl.bit.run_enable == 1){
            /*u16_firstStartCnt++;
            if(u16_firstStartCnt>200){
                u16_firstStartCnt=200;
            }else if(u16_firstStartCnt<100){
                vcu_speedRampCmd=1500;
            }*/
            LinearRamp(vcu_speedRampCmd,&f_speed_gear,upStep,downStep, upLimit, downLimit);
            motorVars_M1.flagEnableRunAndIdentify = 1;
        }else{
            f_speed_gear = 0;
            vcu_speedRampCmd = 0;
            //if(fabsf(motorSpd)<3000){
                motorVars_M1.flagEnableRunAndIdentify = u_motor_ctrl.bit.run_enable;
                u16_StopCtrlFlg=0;
                u16_firstStartCnt=0;
            //}
        }
        //��Ƭ����ʱ����1�����ٶ�
        /*if(u_motor_ctrl.bit.run_enable == 1){
            if((1700<(fabsf(motorSpd))<2200)){
                b_shrap=1;
            }
            if(b_shrap==1){
                f_speed_gear=2200;
                u16_shrapCnt++;
                if((u16_shrapCnt>300)){
                    b_shrap=2;
                    u16_shrapCnt=0;
                }
            }
        }else{
            b_shrap=0;
            u16_shrapCnt=0;
        }*/

        motorVars_M1.speedRef_Hz = f_speed_gear*0.016666 * USER_MOTOR1_NUM_POLE_PAIRS*vcu_speedDirCmd;
    }else{
        u16_firstStartCnt=0;
        speed_ramp_cmd = 0;
        vcu_speedRampCmd = 0;
        f_speed_gear = 0;
        motorVars_M1.speedRef_Hz = 0;
        motorVars_M1.flagEnableRunAndIdentify = 0;
    }
}


#endif
