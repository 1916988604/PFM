
#ifndef SRC_APP_TIMERTASK_H_
#define SRC_APP_TIMERTASK_H_

#include "libraries/math/include/math.h"

typedef void (*TIMER_TASK)(void);

typedef struct
{
    TIMER_TASK timer_task;
    uint32_t interval;      // ��λms
}TASK_TYPE;

#ifdef  SRC_APP_TIMERTASK_C_
    #define SRC_APP_TIMERTASK
#else
    #define SRC_APP_TIMERTASK  extern
#endif

SRC_APP_TIMERTASK unsigned long  timeTask_cnt;

SRC_APP_TIMERTASK void timer_task(void);
SRC_APP_TIMERTASK void timer_task_init(void);

SRC_APP_TIMERTASK void ms1_task(void);
SRC_APP_TIMERTASK void ms2_task(void);
SRC_APP_TIMERTASK void ms5_task(void);
SRC_APP_TIMERTASK void ms10_task(void);
SRC_APP_TIMERTASK void ms20_task(void);
SRC_APP_TIMERTASK void ms100_task(void);
SRC_APP_TIMERTASK void ms250_task(void);



#endif /* SRC_APP_TIMERTASK_H_ */
